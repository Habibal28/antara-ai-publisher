<?php
/**
 * Banner features
 *
 * Author: Gian MR - http://www.gianmr.com
 *
 * @since 1.0.0
 * @package wpmedia
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'wpmedia_helper_after_paragraph' ) ) :
	/**
	 * Helper add content after paragprah
	 *
	 * @since 1.0.0
	 * @link http://stackoverflow.com/questions/25888630/place-ads-in-between-text-only-paragraphs
	 * @param string $insertion String Inserting to Posts.
	 * @param int    $paragraph_id Number of paragraph.
	 * @param string $content Content Posts.
	 * @return string
	 */
	function wpmedia_helper_after_paragraph( $insertion, $paragraph_id, $content ) {
		if ( is_singular( array( 'post' ) ) && in_the_loop() ) {
			$closing_p  = '</p>';
			$paragraphs = explode( $closing_p, wptexturize( $content ) );
			$count      = count( $paragraphs );

			foreach ( $paragraphs as $index => $paragraph ) {
				$word_count = count( explode( ' ', $paragraph ) );

				if ( trim( $paragraph ) && $index + 1 === $paragraph_id ) {
					$paragraphs[ $index ] .= $closing_p;
				}
				if ( $index + 1 === $paragraph_id && $count >= 4 ) {
					$paragraphs[ $index ] .= $insertion;
				}
			}
			return implode( '', $paragraphs );
		}
		return $content;
	}
endif; /* endif wpmedia_helper_after_paragraph */

if ( ! function_exists( 'wpmedia_topbanner_verytop' ) ) {
	/**
	 * Adding banner at top after menu via hook
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function wpmedia_topbanner_verytop() {
		$banner = get_theme_mod( 'gmr_adsverytop' );
		if ( ! wpmedia_is_amp() ) {
			if ( isset( $banner ) && ! empty( $banner ) ) {
				echo '<div class="gmr-verytopbanner text-center gmrclose-element">';
				echo '<div class="container">';
				echo '<div class="gmr-parallax">';
				echo '<div class="rellax">';
				echo '<div class="in-rellax">';
				echo '<div class="idt-xclosewrap">';
				$textverytopbanner = get_theme_mod( 'gmr_textadsverytop' );
				if ( $textverytopbanner ) {
					/* sanitize html output */
					echo '<div class="idt-xclosetext">';
					echo esc_html( $textverytopbanner );
					echo '</div>';
				}
				echo '<button class="idt-xclose-top close-modal gmrbtnclose">&times;</button>';
				echo '</div>'; /* End .idt-xclosewrap */
				echo '<div class="idt-rellax-bannerwrap">';
				echo do_shortcode( $banner );
				echo '</div>'; /* End .idt-rellax-bannerwrap */
				echo '</div>'; /* End .in-rellax */
				echo '</div>'; /* End .rellax */
				echo '</div>'; /* End .gmr-parallax */
				echo '</div>'; /* End .container */
				echo '</div>'; /* End .gmr-verytopbanner */
			}
		}
	}
}
add_action( 'wpmedia_topbanner_verytop', 'wpmedia_topbanner_verytop', 10 );

if ( ! function_exists( 'wpmedia_topbanner_aftermenu' ) ) {
	/**
	 * Adding banner at top after menu via hook
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function wpmedia_topbanner_aftermenu() {
		$ampbanner = get_theme_mod( 'gmr_adsaftermenu_amp' );
		$banner    = get_theme_mod( 'gmr_adsaftermenu' );

		if ( wpmedia_is_amp() ) {
			if ( isset( $ampbanner ) && ! empty( $ampbanner ) ) {
				echo '<div class="gmr-topbanner text-center">';
					echo '<div class="container">';
						echo do_shortcode( $ampbanner );
					echo '</div>';
				echo '</div>';
			}
		} else {
			if ( isset( $banner ) && ! empty( $banner ) ) {
				echo '<div class="gmr-topbanner text-center">';
					echo '<div class="container">';
						echo do_shortcode( $banner );
					echo '</div>';
				echo '</div>';
			}
		}
	}
}
add_action( 'wpmedia_topbanner_aftermenu', 'wpmedia_topbanner_aftermenu', 10 );

if ( ! function_exists( 'wpmedia_banner_between_posts' ) ) {
	/**
	 * Adding banner between posts in archive and index post
	 *
	 * @since 1.0.5
	 * @param int $post Post ID.
	 * @return void
	 */
	function wpmedia_banner_between_posts( $post ) {
		global $wp_query;

		$ampbanner = get_theme_mod( 'gmr_adsbetweenpost_amp' );
		$banner    = get_theme_mod( 'gmr_adsbetweenpost' );

		$ampposition = get_theme_mod( 'gmr_adsbetweenpostposition_amp', 'third' );
		$position    = get_theme_mod( 'gmr_adsbetweenpostposition', 'third' );

		if ( wpmedia_is_amp() ) {
			/* Check if we're at the right position and option not empty */
			if ( isset( $ampbanner ) && ! empty( $ampbanner ) ) {
				if ( 'first' === $ampposition ) {
					$numb = 0;
				} elseif ( 'second' === $ampposition ) {
					$numb = 1;
				} elseif ( 'third' === $ampposition ) {
					$numb = 2;
				} elseif ( 'fourth' === $ampposition ) {
					$numb = 3;
				} else {
					$numb = 2;
				}

				if ( intval( $numb ) === $wp_query->current_post ) {
					/* Display the banner */
					echo '<div class="inline-banner post text-center">';
						echo do_shortcode( $ampbanner );
					echo '</div>';
				}
			}
		} else {
			/* Check if we're at the right position and option not empty */
			if ( isset( $banner ) && ! empty( $banner ) ) {
				if ( 'first' === $position ) {
					$numb = 0;
				} elseif ( 'second' === $position ) {
					$numb = 1;
				} elseif ( 'third' === $position ) {
					$numb = 2;
				} elseif ( 'fourth' === $position ) {
					$numb = 3;
				} else {
					$numb = 2;
				}

				if ( intval( $numb ) === $wp_query->current_post ) {
					/* Display the banner */
					echo '<div class="inline-banner post text-center">';
						echo do_shortcode( $banner );
					echo '</div>';
				}
			}
		}
	}
}
add_action( 'wpmedia_banner_between_posts', 'wpmedia_banner_between_posts' );

if ( ! function_exists( 'wpmedia_banner_before_content' ) ) {
	/**
	 * Adding banner at before content via hook
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function wpmedia_banner_before_content() {
		$ampbanner = get_theme_mod( 'gmr_adsbeforecontent_amp' );
		$banner    = get_theme_mod( 'gmr_adsbeforecontent' );

		$position = get_theme_mod( 'gmr_adsbeforecontentposition' );

		if ( wpmedia_is_amp() ) {
			if ( isset( $ampbanner ) && ! empty( $ampbanner ) ) {
				echo '<div class="gmr-banner-beforecontent text-center">';
				echo do_shortcode( $ampbanner );
				echo '</div>';
			}
		} else {
			if ( isset( $banner ) && ! empty( $banner ) ) {
				if ( 'floatleft' === $position ) {
					$class = ' pull-left';
				} elseif ( 'floatright' === $position ) {
					$class = ' pull-right';
				} elseif ( 'center' === $position ) {
					$class = ' text-center';
				} else {
					$class = '';
				}
				echo '<div class="gmr-banner-beforecontent' . esc_html( $class ) . '">';
				echo do_shortcode( $banner );
				echo '</div>';
			}
		}
	}
}
add_action( 'wpmedia_banner_before_content', 'wpmedia_banner_before_content' );

if ( ! function_exists( 'wpmedia_add_banner_inside_content' ) ) :
	/**
	 * Insert content inside content single
	 *
	 * @since 1.0.0
	 * @param string $content Content Posts.
	 * @return string
	 */
	function wpmedia_add_banner_inside_content( $content ) {
		if ( is_singular( array( 'post' ) ) && in_the_loop() ) {
			$ampbanner   = get_theme_mod( 'gmr_adsinsidecontent_amp' );
			$banner      = get_theme_mod( 'gmr_adsinsidecontent' );
			$position    = get_theme_mod( 'gmr_adsinsidecontentposition', 'center' );
			$positionamp = get_theme_mod( 'gmr_adsinsidecontentposition_amp', 'center' );

			$textbeforeinsidebanner = get_theme_mod( 'gmr_textadsinsedecontent' );
			$textafterinsidebanner  = get_theme_mod( 'gmr_textadsafterinsedecontent' );

			$textbefore = '';
			if ( $textbeforeinsidebanner ) {
				$textbefore = '<div class="idt-textinsidepost">' . esc_html( $textbeforeinsidebanner ) . '</div>';
			}

			$textafter = '';
			if ( $textafterinsidebanner ) {
				$textafter = '<div class="idt-textinsidepost">' . esc_html( $textafterinsidebanner ) . '</div>';
			}

			if ( wpmedia_is_amp() ) {
				if ( isset( $ampbanner ) && ! empty( $ampbanner ) ) {
					if ( 'center' === $positionamp ) {
						$class = ' text-center';
					} elseif ( 'parallax' === $positionamp ) {
						$class = ' gmr-parallax';
					} elseif ( 'sticky' === $positionamp ) {
						$class = ' gmr-parallax pos-stickywrap';
					} else {
						$class = '';
					}
					if ( 'parallax' === $positionamp ) {
						$ad_code = $textbefore . '<div class="gmr-banner-insidecontent' . esc_html( $class ) . '"><div class="rellax"><div class="in-rellax">' . do_shortcode( $ampbanner ) . '</div></div></div>' . $textafter;
					} elseif ( 'sticky' === $positionamp ) {
						$ad_code = $textbefore . '<div class="gmr-banner-insidecontent' . esc_html( $class ) . '"><div class="pos-sticky">' . do_shortcode( $ampbanner ) . '</div></div>' . $textafter;
					} else {
						$ad_code = $textbefore . '<div class="gmr-banner-insidecontent' . esc_html( $class ) . '">' . do_shortcode( $ampbanner ) . '</div>' . $textafter;
					}
					if ( is_singular( array( 'post' ) ) && in_the_loop() ) {
						return wpmedia_helper_after_paragraph( $ad_code, 2, $content );
					}
				}
			} else {
				if ( isset( $banner ) && ! empty( $banner ) ) {
					if ( 'right' === $position ) {
						$class = ' text-right';
					} elseif ( 'center' === $position ) {
						$class = ' text-center';
					} elseif ( 'parallax' === $position ) {
						$class = ' gmr-parallax';
					} elseif ( 'sticky' === $position ) {
						$class = ' gmr-parallax pos-stickywrap';
					} else {
						$class = '';
					}
					if ( 'parallax' === $position ) {
						$ad_code = $textbefore . '<div class="gmr-banner-insidecontent' . esc_html( $class ) . '"><div class="rellax"><div class="in-rellax">' . do_shortcode( $banner ) . '</div></div></div>' . $textafter;
					} elseif ( 'sticky' === $position ) {
						$ad_code = $textbefore . '<div class="gmr-banner-insidecontent' . esc_html( $class ) . '"><div class="pos-sticky">' . do_shortcode( $banner ) . '</div></div>' . $textafter;
					} else {
						$ad_code = $textbefore . '<div class="gmr-banner-insidecontent' . esc_html( $class ) . '">' . do_shortcode( $banner ) . '</div>' . $textafter;
					}
					if ( is_singular( array( 'post' ) ) && in_the_loop() ) {
						return wpmedia_helper_after_paragraph( $ad_code, 2, $content );
					}
				}
			}
		}
		return $content;
	}
endif;
add_filter( 'the_content', 'wpmedia_add_banner_inside_content' );

if ( ! function_exists( 'wpmedia_banner_after_content' ) ) {
	/**
	 * Adding banner at before content via hook
	 *
	 * @since 1.0.0
	 * @return string
	 */
	function wpmedia_banner_after_content() {
		$ampbanner = get_theme_mod( 'gmr_adsaftercontent_amp' );
		$banner    = get_theme_mod( 'gmr_adsaftercontent' );

		$position = get_theme_mod( 'gmr_adsaftercontentposition' );

		$ads = '';
		if ( wpmedia_is_amp() ) {
			if ( isset( $ampbanner ) && ! empty( $ampbanner ) ) {
				$ads .= '<div class="gmr-banner-aftercontent text-center">';
				$ads .= do_shortcode( $ampbanner );
				$ads .= '</div>';
			}
		} else {
			if ( isset( $banner ) && ! empty( $banner ) ) {
				if ( 'right' === $position ) {
					$class = ' text-right';
				} elseif ( 'center' === $position ) {
					$class = ' text-center';
				} else {
					$class = '';
				}
				$ads .= '<div class="gmr-banner-aftercontent' . esc_html( $class ) . '">';
				$ads .= do_shortcode( $banner );
				$ads .= '</div>';
			}
		}
		return $ads;
	}
}

if ( ! function_exists( 'wpmedia_add_banner_after_content' ) ) :
	/**
	 * Insert content after box content single
	 *
	 * @since 1.0.0
	 * @param string $content Content Posts.
	 * @return string
	 */
	function wpmedia_add_banner_after_content( $content ) {
		if ( is_singular( array( 'post' ) ) && in_the_loop() ) {
			$content = $content . wpmedia_banner_after_content();
		}
		return $content;
	}
endif; /* endif wpmedia_add_banner_after_content */
add_filter( 'the_content', 'wpmedia_add_banner_after_content', 30 );

if ( ! function_exists( 'wpmedia_banner_stickyright_content' ) ) {
	/**
	 * Adding banner at before content via hook
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function wpmedia_banner_stickyright_content() {
		$banner = get_theme_mod( 'gmr_adsstickyrightcontent' );
		if ( ! wpmedia_is_amp() ) {
			if ( isset( $banner ) && ! empty( $banner ) ) {
				echo '<div class="gmr-banner-stickyright pos-sticky">';
					echo do_shortcode( $banner );
				echo '</div>';
			}
		}
	}
}
add_action( 'wpmedia_banner_stickyright_content', 'wpmedia_banner_stickyright_content', 10 );

if ( ! function_exists( 'wpmedia_banner_after_relpost' ) ) {
	/**
	 * Adding banner after related posts via hook
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function wpmedia_banner_after_relpost() {
		$ampbanner = get_theme_mod( 'gmr_adsafterrelpost_amp' );
		$banner    = get_theme_mod( 'gmr_adsafterrelpost' );

		$position = get_theme_mod( 'gmr_adsafterrelpostposition' );

		if ( wpmedia_is_amp() ) {
			if ( isset( $ampbanner ) && ! empty( $ampbanner ) ) {
				echo '<div class="gmr-banner-afterrelpost clearfix">';
					echo do_shortcode( $ampbanner );
				echo '</div>';
			}
		} else {
			if ( isset( $banner ) && ! empty( $banner ) ) {
				if ( 'right' === $position ) {
					$class = ' text-right';
				} elseif ( 'center' === $position ) {
					$class = ' text-center';
				} else {
					$class = '';
				}
				echo '<div class="gmr-banner-afterrelpost clearfix' . esc_html( $class ) . '">';
					echo do_shortcode( $banner );
				echo '</div>';
			}
		}
	}
}
add_action( 'wpmedia_banner_after_relpost', 'wpmedia_banner_after_relpost', 10 );

if ( ! function_exists( 'wpmedia_floating_banner_left' ) ) {
	/**
	 * Adding banner at top via hook
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function wpmedia_floating_banner_left() {
		$banner = get_theme_mod( 'gmr_adsfloatleft' );

		if ( ! wpmedia_is_amp() ) {
			if ( isset( $banner ) && ! empty( $banner ) ) {
				echo '<div class="gmr-floatbanner gmr-floatbanner-left gmrclose-element">';
				echo '<button class="gmrbtnclose" title="' . esc_html__( 'close', 'wpmedia' ) . '">&times;</button>';
				echo do_shortcode( $banner );
				echo '</div>';
			}
		}
	}
}
add_action( 'wpmedia_floating_banner_left', 'wpmedia_floating_banner_left', 10 );

if ( ! function_exists( 'wpmedia_floating_banner_right' ) ) {
	/**
	 * Adding banner at top via hook
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function wpmedia_floating_banner_right() {
		$banner = get_theme_mod( 'gmr_adsfloatright' );

		if ( ! wpmedia_is_amp() ) {
			if ( isset( $banner ) && ! empty( $banner ) ) {
				echo '<div class="gmr-floatbanner gmr-floatbanner-right gmrclose-element">';
					echo '<button class="gmrbtnclose" title="' . esc_html__( 'close', 'wpmedia' ) . '">&times;</button>';
					echo do_shortcode( $banner );
				echo '</div>';
			}
		}
	}
}
add_action( 'wpmedia_floating_banner_right', 'wpmedia_floating_banner_right', 10 );

if ( ! function_exists( 'wpmedia_floating_banner_footer' ) ) {
	/**
	 * Adding floating banner
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function wpmedia_floating_banner_footer() {
		$banner = get_theme_mod( 'gmr_adsfloatbottom' );

		if ( ! wpmedia_is_amp() ) {
			if ( isset( $banner ) && ! empty( $banner ) ) {
				echo '<div class="gmr-floatbanner gmr-floatbanner-footer gmrclose-element">';
					echo '<div class="container">';
					echo '<button class="gmrbtnclose" title="' . esc_html__( 'close', 'wpmedia' ) . '">&times;</button>';
					echo do_shortcode( $banner );
					echo '</div>';
				echo '</div>';
			}
		}
	}
}
add_action( 'wpmedia_floating_banner_footer', 'wpmedia_floating_banner_footer', 20 );

if ( ! function_exists( 'wpmedia_footerbanner' ) ) {
	/**
	 * Adding banner at top via hook
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function wpmedia_footerbanner() {
		$ampbanner = get_theme_mod( 'gmr_adsfooter_amp' );
		$banner    = get_theme_mod( 'gmr_adsfooter' );
		if ( wpmedia_is_amp() ) {
			if ( isset( $ampbanner ) && ! empty( $ampbanner ) ) {
				echo '<div class="gmr-footerbanner text-center">';
					echo '<div class="container">';
						echo do_shortcode( $ampbanner );
					echo '</div>';
				echo '</div>';
			}
		} else {
			if ( isset( $banner ) && ! empty( $banner ) ) {
				echo '<div class="gmr-footerbanner text-center">';
					echo '<div class="container">';
						echo do_shortcode( $banner );
					echo '</div>';
				echo '</div>';
			}
		}
	}
}
add_action( 'wpmedia_footerbanner', 'wpmedia_footerbanner', 10 );

if ( ! function_exists( 'wpmedia_popup_banner' ) ) {

	/**
	 * Adding popup banner
	 *
	 * @since 1.0.5
	 * @return void
	 */
	function wpmedia_popup_banner() {
		$banner = get_theme_mod( 'gmr_adspopup' );

		if ( ! wpmedia_is_amp() ) {
			if ( isset( $banner ) && ! empty( $banner ) ) {
				echo '<div id="gmr-popupwrap" class="gmr-bannerpopup gmrclose-element">';
					echo '<div class="gmr-modalbg close-modal"></div>';
					echo '<div class="gmr-in-popup clearfix">';
					echo '<button class="idt-xclose close-modal gmrbtnclose">&times;</button>';
					echo do_shortcode( $banner );
					echo '</div>';
				echo '</div>';
			}
		}
	}
}
add_action( 'wpmedia_popup_banner', 'wpmedia_popup_banner', 20 );
