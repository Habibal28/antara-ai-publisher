<?php
/**
 * Importer plugin filter.
 *
 * @link https://wordpress.org/plugins/one-click-demo-import/
 *
 * @package Wpmedia
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'wpmedia_ocdi_import_files' ) ) :
	/**
	 * Set one click import demo data. Plugin require is. https://wordpress.org/plugins/one-click-demo-import/
	 *
	 * @since v.1.0.0
	 * @link https://wordpress.org/plugins/one-click-demo-import/faq/
	 *
	 * @return array
	 */
	function wpmedia_ocdi_import_files() {
		$arr = array(
			array(
				'import_file_name'             => 'Demo Import',
				'local_import_file'            => trailingslashit( get_template_directory() ) . 'inc/importer/demo-content.xml',
				'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'inc/importer/widgets.json',
				'local_import_customizer_file' => trailingslashit( get_template_directory() ) . 'inc/importer/customizer.dat',
				'import_notice'                => __( 'Import demo from https://preview.bostheme.com/wpmedia/.', 'wpmedia' ),
			),
		);
		return $arr;
	}
endif;
add_filter( 'ocdi/import_files', 'wpmedia_ocdi_import_files' );

if ( ! function_exists( 'wpmedia_ocdi_before_import_import' ) ) :
	/**
	 * Filter before import content. https://ocdi.com/advanced-integration-guide/
	 *
	 * @since v.1.0.0
	 * @param array $selected_import selection importer data.
	 */
	function wpmedia_ocdi_before_import_import( $selected_import ) {

		// Find and delete the WP default 'Sample Page'.
		$default_page = get_page_by_title( 'Sample Page' );
		if ( ! empty( $default_page ) ) {
			wp_delete_post( $default_page->ID, $bypass_trash = true );
		}

		// Find and delete the WP default 'Hello world!' post.
		$default_post = get_posts( array( 'title' => 'Hello World!' ) );
		if ( ! empty( $default_post ) ) {
			wp_delete_post( $default_post[0]->ID, $bypass_trash = true );
		}

		/* Remove all widget active from sidebar */
		$null = null;
		update_option( 'sidebars_widgets', $null );
	}
endif;
add_action( 'ocdi/before_content_import', 'wpmedia_ocdi_before_import_import' );

if ( ! function_exists( 'wpmedia_ocdi_after_import' ) ) :
	/**
	 * Set action after import demo data. Plugin require is. https://wordpress.org/plugins/one-click-demo-import/
	 *
	 * @since v.1.0.0
	 * @link https://wordpress.org/plugins/one-click-demo-import/faq/
	 * @param array $selected_import selection importer data.
	 *
	 * @return void
	 */
	function wpmedia_ocdi_after_import( $selected_import ) {
		/* Menus to Import and assign - you can remove or add as many as you want */
		$primary     = get_term_by( 'name', 'Top menus', 'nav_menu' );
		$secondary   = get_term_by( 'name', 'Second Menu', 'nav_menu' );
		$side_menu   = get_term_by( 'name', 'Side Menu', 'nav_menu' );
		$footer_menu = get_term_by( 'name', 'Footer menu', 'nav_menu' );

		set_theme_mod(
			'nav_menu_locations',
			array(
				'menu-1' => $primary->term_id,
				'menu-2' => $secondary->term_id,
				'menu-3' => $side_menu->term_id,
				'menu-4' => $footer_menu->term_id,
			)
		);

		if ( class_exists( 'Menu_Icons', false ) ) {
			$defaults = array(
				'global' => array(
					'icon_types' => array( 'image' ),
				),
			);

			update_option( 'menu-icons', $defaults );
		}
	}
endif;
add_action( 'ocdi/after_import', 'wpmedia_ocdi_after_import' );

if ( ! function_exists( 'wpmedia_ocdi_register_plugins' ) ) :
	/**
	 * Set action after import demo data. Plugin require is. https://wordpress.org/plugins/one-click-demo-import/
	 *
	 * @since v.1.0.0
	 * @link https://wordpress.org/plugins/one-click-demo-import/faq/
	 * @param array $plugins Plugin array.
	 *
	 * @return array
	 */
	function wpmedia_ocdi_register_plugins( $plugins ) {
		$theme_plugins = array(
			array(
				'name'     => 'Wpmedia Core', /* The plugin name. */
				'slug'     => 'wpmedia-core', /* The plugin slug (typically the folder name). */
				'source'   => 'https://www.dropbox.com/s/woorf30exlsa53b/wpmedia-core.zip?dl=1', /* The plugin source. */
				'required' => true, /* If false, the plugin is only 'recommended' instead of required. */
			),
			array(
				'name'        => 'Post Views',
				'slug'        => 'post-views-counter',
				'required'    => false,
				'preselected' => true,
			),
			array(
				'name'        => 'Menu Icons',
				'slug'        => 'menu-icons',
				'required'    => false,
				'preselected' => true,
			),
			array(
				'name'     => 'AMP',
				'slug'     => 'amp',
				'required' => false,
			),
			array(
				'name'     => 'Subtitle',
				'slug'     => 'kia-subtitle',
				'required' => false,
			),
		);

		return array_merge( $plugins, $theme_plugins );
	}
endif;
add_filter( 'ocdi/register_plugins', 'wpmedia_ocdi_register_plugins' );

if ( ! function_exists( 'wpmedia_change_time_of_single_ajax_call' ) ) :
	/**
	 * Change ajax call timeout
	 *
	 * @link https://github.com/awesomemotive/one-click-demo-import/blob/master/docs/import-problems.md.
	 */
	function wpmedia_change_time_of_single_ajax_call() {
		return 60;
	}
endif;
add_action( 'ocdi/time_for_one_ajax_call', 'wpmedia_change_time_of_single_ajax_call' );

// disable generation of smaller images (thumbnails) during the content import.
add_filter( 'ocdi/regenerate_thumbnails_in_content_import', '__return_false' );

// disable the branding notice.
add_filter( 'ocdi/disable_pt_branding', '__return_true' );
