<?php
/**
 * Custom homepage category content.
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package wpmedia
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'wpmedia_display_modulehome' ) ) :
	/**
	 * This function for display module in homepage
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function wpmedia_display_modulehome() {
		global $post;
		$cat = get_theme_mod( 'gmr_category-module-home', 0 );

		$query_args = array(
			'post_type'              => 'post',
			'cat'                    => $cat,
			'orderby'                => 'date',
			'order'                  => 'desc',
			'showposts'              => 4,
			'post_status'            => 'publish',
			'ignore_sticky_posts'    => true,
			// make it fast withour update term cache and cache results.
			// https://kinsta.com/blog/wp-query/.
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'cache_results'          => false,
			'no_found_rows'          => true,
			'fields'                 => 'ids',
		);

		$jsonslider = array(
			'type'          => 'slide',
			'rewind'        => true,
			'pagination'    => false,
			'arrows'        => false,
			'pauseOnFocus'  => false,
			'autoplay'      => true,
			'reducedMotion' => array(
				'autoplay' => true,
				'speed'    => 100,
				'interval' => 3000,
			),
		);

		$datajson = wp_json_encode( $jsonslider );

		$rp = new WP_Query( apply_filters( 'wpmedia_modulehome_posts_args', $query_args ) );

		if ( $rp->have_posts() ) {
			echo '<div class="idtslider-wrap" data-idtslidethumb="haschild" data-idtslide="modhome">';
			echo '<div class="idtslider-modhome splide clearfix" data-splide="' . esc_attr( $datajson ) . '">';
			echo '<div class="splide__track">';
			echo '<div class="splide__list" dir="ltr">';
			while ( $rp->have_posts() ) :
				$rp->the_post();
				?>
				<div class="splide__slide">
					<?php
					if ( has_post_thumbnail() ) {
						?>
						<a class="post-thumbnail" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
							<?php
								the_post_thumbnail(
									'large',
									array(
										'alt'     => the_title_attribute(
											array(
												'echo' => false,
											)
										),
										'loading' => false,
									)
								);
								wpmedia_postformat_thumbnails();
							?>
						</a>
						<div class="idt-infomainslide">
							<?php wpmedia_category(); ?>
							<?php the_title( '<h3><a href="' . esc_url( get_permalink() ) . '" title="' . the_title_attribute( array( 'echo' => false ) ) . '" rel="bookmark">', '</a></h3>' ); ?>
							<?php
							echo '<div class="gmr-meta-topic">';
							echo '<span class="meta-content">';
							wpmedia_posted_on();
							echo '</span>';
							echo '</div>';
							?>
						</div>
						<?php
					}
					?>
				</div>
				<?php
			endwhile;
			wp_reset_postdata();
			echo '</div>';
			echo '</div>';
			echo '</div>';

			$jsonchildslider = array(
				'perPage'       => 4,
				'pagination'    => false,
				'arrows'        => false,
				'rewind'        => true,
				'isNavigation'  => true,
				'pauseOnFocus'  => false,
				'autoplay'      => true,
				'reducedMotion' => array(
					'autoplay' => true,
					'speed'    => 100,
					'interval' => 3000,
				),
			);

			$jsonchildslider = wp_json_encode( $jsonchildslider );

			echo '<div class="idtsliderthumb-modhome idtsplide splide clearfix" data-splide="' . esc_attr( $jsonchildslider ) . '">';
			echo '<div class="splide__track" dir="ltr">';
			echo '<div class="splide__list">';
			while ( $rp->have_posts() ) :
				$rp->the_post();
				?>
				<div class="splide__slide">
					<?php
					if ( has_post_thumbnail() ) {
						?>
						<div class="post-thumbnail">
							<?php
								the_post_thumbnail(
									'medium_large',
									array(
										'alt' => the_title_attribute(
											array(
												'echo' => false,
											)
										),
									)
								);
								wpmedia_postformat_thumbnails();
							?>
						</div>
						<?php
						the_title( '<div class="title-slider heading-text"><a href="' . esc_url( get_permalink() ) . '" title="' . the_title_attribute( array( 'echo' => false ) ) . '" rel="bookmark">', '</a></div>' );
					}
					?>
				</div>
				<?php
			endwhile;
			wp_reset_postdata();
			echo '</div>';
			echo '</div>';
			echo '</div>';
			echo '</div>';
		}
	}
endif; /* endif wpmedia_display_modulehome */
add_action( 'wpmedia_display_modulehome', 'wpmedia_display_modulehome', 50 );

if ( ! function_exists( 'wpmedia_get_attachment_gallery' ) ) :
	/**
	 * Display Gallery base attachment post
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function wpmedia_get_attachment_gallery() {
		global $post, $attachment;

		if ( is_attachment() ) {
			$args = array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'post_parent'    => intval( $post->post_parent ),
				'post_mime_type' => 'image',
				'posts_per_page' => -1, // phpcs:ignore
			);
		} else {
			$args = array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'post_parent'    => intval( $post->ID ),
				'posts_per_page' => -1, // phpcs:ignore
				'post_mime_type' => 'image',
				'exclude'        => get_post_thumbnail_id( $post->ID ),
			);
		}
		$images = get_posts( $args );

		$jsonslider = array(
			'type'          => 'slide',
			'rewind'        => true,
			'perPage'       => 3,
			'pagination'    => false,
			'arrows'        => true,
			'autoplay'      => true,
			'gap'           => 16,
			'breakpoints'   => array(
				'1200' => array(
					'perPage' => 3,
				),
				'781'  => array(
					'perPage' => 3,
				),
				'500'  => array(
					'perPage' => 2,
				),
			),
			'reducedMotion' => array(
				'autoplay' => true,
				'speed'    => 100,
				'interval' => 3000,
			),
		);
		$datajson   = wp_json_encode( $jsonslider );

		if ( $images ) {
			if ( wpmedia_is_amp() ) {
				$class = 'wpmedia-list-amp';
			} else {
				$class = 'wpmedia-list-slider gmr-singlegallery';
			}
			echo '<div class="' . esc_html( $class ) . ' idtslider-galpost idtsplide splide clearfix" data-splide="' . esc_attr( $datajson ) . '" data-idtslide="galpost">';
			echo '<div class="splide__arrows">';
			echo '<button class="splide__arrow splide__arrow--prev" aria-label="' . esc_html__( 'Previous', 'wpmedia' ) . '"></button>';
			echo '<button class="splide__arrow splide__arrow--next" aria-label="' . esc_html__( 'Next', 'wpmedia' ) . '"></button>';
			echo '</div>';
			echo '<div class="splide__track">';
			echo '<div class="splide__list">';
			foreach ( $images as $attach ) {
				setup_postdata( $attach );
				$attachment_id  = $attach->ID;
				$img_url        = wp_get_attachment_image_src( $attachment_id, 'medium_large' );
				$desc_img       = get_the_title( $attachment_id );
				$attachment_url = get_attachment_link( $attachment_id );

				if ( $img_url ) {
					echo '<div class="splide__slide">';
					echo '<a class="post-thumbnail" href="' . esc_url( $attachment_url ) . '" title="' . esc_html( $desc_img ) . '"><img src="' . esc_url( $img_url[0] ) . '" width="' . absint( $img_url[1] ) . '" height="' . absint( $img_url[2] ) . '" alt="' . esc_html( $desc_img ) . '" title="' . esc_html( $desc_img ) . '" /></a>';
					echo '</div>';
				}
			}
			wp_reset_postdata();
			echo '</div>';
			echo '</div>';
			echo '</div>';
		}
	}
endif; // endif wpmedia_get_attachment_gallery.
add_action( 'wpmedia_get_attachment_gallery', 'wpmedia_get_attachment_gallery', 20 );

if ( ! function_exists( 'wpmedia_recentpost_marquee' ) ) :
	/**
	 * This function for display slider in homepage
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function wpmedia_recentpost_marquee() {
		global $post;
		$cat = get_theme_mod( 'gmr_category-marque', 0 );

		$query_args = array(
			'post_type'              => 'post',
			'cat'                    => $cat,
			'orderby'                => 'date',
			'order'                  => 'desc',
			'showposts'              => 5,
			'post_status'            => 'publish',
			'ignore_sticky_posts'    => true,
			// make it fast withour update term cache and cache results.
			// https://kinsta.com/blog/wp-query/.
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'cache_results'          => false,
			'no_found_rows'          => true,
			'fields'                 => 'ids',
		);

		$rp = new WP_Query( apply_filters( 'wpmedia_marquee_posts_args', $query_args ) );
		if ( $rp->have_posts() ) {
			while ( $rp->have_posts() ) :
				$rp->the_post();
				?>
				<div class="marquee-content">
					<a class="post-thumbnail" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
						<?php
							the_post_thumbnail(
								'thumbnail',
								array(
									'alt'     => the_title_attribute(
										array(
											'echo' => false,
										)
									),
									'loading' => false,
								)
							);
						?>
					</a>
					<a href="<?php the_permalink(); ?>" class="gmr-recent-marquee" title="<?php the_title(); ?>"><?php the_title(); ?></a>
					</div>
				<?php
			endwhile;
			wp_reset_postdata();
		}
	}
endif; /* endif wpmedia_recentpost_marquee */
add_action( 'wpmedia_recentpost_marquee', 'wpmedia_recentpost_marquee', 50 );
