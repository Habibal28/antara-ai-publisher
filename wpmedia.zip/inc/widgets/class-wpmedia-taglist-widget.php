<?php
/**
 * Widget API: Wpmedia_TagList_Widget class
 *
 * Author: Gian MR - http://www.gianmr.com
 *
 * @package Wpmedia
 * @subpackage Widgets
 * @since 1.0.0
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add Tag List widget.
 *
 * @since 1.0.0
 *
 * @see WP_Widget
 */
class Wpmedia_TagList_Widget extends WP_Widget {
	/**
	 * Sets up a Tag Lists widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'classname'             => 'wpmedia-taglist',
			'description'           => __( 'Display Tags By Count or name. This support category list too...', 'wpmedia' ),
			'show_instance_in_rest' => true,
		);
		parent::__construct( 'wpmedia-taglist', __( 'Popular Tags/Category Widget (Wpmedia)', 'wpmedia' ), $widget_ops );
	}

	/**
	 * Outputs the content for Tag Lists.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for Tag Lists.
	 */
	public function widget( $args, $instance ) {

		// Title.
		$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );
		// Base Id Widget.
		$wpm_widget_id = $this->id_base . '-' . $this->number;
		// Subtitle.
		$subtitle = ( ! empty( $instance['subtitle'] ) ) ? esc_html( $instance['subtitle'] ) : '';

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( $title ) {
			echo '<div class="page-header widget-titlewrap">';
			echo $args['before_title']; // phpcs:ignore
			echo wp_kses_post( $title );
			echo $args['after_title']; // phpcs:ignore
			echo '</div>';
			if ( $subtitle ) {
				echo '<div class="widget-subtitle">' . wp_kses_post( $subtitle ) . '</div>';
			}
		}
		// Minimal Number Post.
		$wpm_number_posts = ( ! empty( $instance['wpm_number_posts'] ) ) ? absint( $instance['wpm_number_posts'] ) : absint( 1 );
		// Minimal Tags.
		$wpm_number_tags = ( ! empty( $instance['wpm_number_tags'] ) ) ? absint( $instance['wpm_number_tags'] ) : absint( 5 );
		// Tag id.
		$wpm_idtag = ( ! empty( $instance['wpm_idtag'] ) ) ? array_map( 'absint', explode( ',', esc_attr( $instance['wpm_idtag'] ) ) ) : array( 0 );
		// Taxonomy.
		$wpm_taxonomy = ( ! empty( $instance['wpm_taxonomy'] ) ) ? wp_strip_all_tags( $instance['wpm_taxonomy'] ) : 'post_tag';
		// Orderby.
		$wpm_orderby = ( ! empty( $instance['wpm_orderby'] ) ) ? wp_strip_all_tags( $instance['wpm_orderby'] ) : 'count';
		// Order.
		$wpm_order = ( ! empty( $instance['wpm_orderby'] ) && 'count' === $instance['wpm_orderby'] ) ? 'DESC' : 'ASC';
		// Style.
		$wpm_style = ( ! empty( $instance['wpm_style'] ) ) ? wp_strip_all_tags( $instance['wpm_style'] ) : wp_strip_all_tags( 'style_1' );
		// Array for get_terms.
		$query_args = array(
			'orderby'      => esc_html( $wpm_orderby ),
			'order'        => esc_html( $wpm_order ),
			'hide_empty'   => true,
			'count'        => true,
			'hierarchical' => false,
			'taxonomy'     => esc_html( $wpm_taxonomy ),
		);

		if ( $wpm_number_tags ) {
			$query_args['number'] = $wpm_number_tags;
		}

		// if 'all tags' was selected ignore other selections of categories.
		if ( in_array( 0, $wpm_idtag, true ) ) {
			$wpm_idtag = array( 0 );
		}
		if ( ! in_array( 0, $wpm_idtag, true ) ) {
			$query_args['include'] = $wpm_idtag;
		}

		$tags = get_tags( $query_args );

		if ( ! is_wp_error( $tags ) && is_array( $tags ) && ! empty( $tags ) ) {
			if ( 'style_2' === $wpm_style ) {
				$classes = ' col-2';
			} elseif ( 'style_3' === $wpm_style ) {
				$classes = ' beforetags';
			} else {
				$classes = '';
			}
			echo '<ul class="wpmedia-tag-lists' . esc_attr( $classes ) . '">';
			foreach ( $tags as $tag ) {
				if ( $tag->count >= $wpm_number_posts ) {
					// Open item.
					echo '<li><a href="' . esc_url( get_term_link( (int) $tag->term_id ) ) . '" title="' . esc_attr( $tag->name ) . '">';
					// Tag name.
					echo esc_attr( $tag->name );
					// Close item.
					echo '</a></li>';
				}
			}
			echo '</ul>';
		} else {
			$notagtext = ( 'category' === $instance['wpm_taxonomy'] ) ? esc_html__( 'No Category', 'wpmedia' ) : esc_html__( 'No Tag', 'wpmedia' );
			echo '<div class="notags">' . esc_html( $notagtext ) . '</div>';
		}
		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Handles updating settings for the current Mailchimp widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            Wpmedia_Mailchimp_form::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Updated settings to save.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		$new_instance = wp_parse_args(
			(array) $new_instance,
			array(
				'title'            => '',
				'subtitle'         => '',
				'wpm_taxonomy'     => 'post_tag',
				'wpm_orderby'      => 'count',
				'wpm_style'        => 'style_1',
				'wpm_number_posts' => 1,
				'wpm_number_tags'  => 5,
				'wpm_idtag'        => '',
			)
		);

		// Title.
		$instance['title'] = sanitize_text_field( $new_instance['title'] );
		// SubTitle.
		$instance['subtitle'] = sanitize_text_field( $new_instance['subtitle'] );
		// Taxonomy.
		$instance['wpm_taxonomy'] = wp_strip_all_tags( $new_instance['wpm_taxonomy'] );
		// Order by.
		$instance['wpm_orderby'] = wp_strip_all_tags( $new_instance['wpm_orderby'] );
		// Style.
		$instance['wpm_style'] = wp_strip_all_tags( $new_instance['wpm_style'] );
		// Number posts.
		$instance['wpm_number_posts'] = absint( $new_instance['wpm_number_posts'] );
		// Number tags.
		$instance['wpm_number_tags'] = absint( $new_instance['wpm_number_tags'] );
		// tag id.
		$instance['wpm_idtag'] = wp_strip_all_tags( $new_instance['wpm_idtag'] );

		return $instance;
	}

	/**
	 * Outputs the settings form for the Mailchimp widget.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$instance = wp_parse_args(
			(array) $instance,
			array(
				'title'            => __( 'Popular Tags', 'wpmedia' ),
				'subtitle'         => '',
				'wpm_taxonomy'     => 'post_tag',
				'wpm_orderby'      => 'count',
				'wpm_style'        => 'style_1',
				'wpm_number_posts' => 1,
				'wpm_number_tags'  => 5,
				'wpm_idtag'        => '',
			)
		);
		// Title.
		$title = sanitize_text_field( $instance['title'] );
		// SubTitle.
		$subtitle = sanitize_text_field( $instance['subtitle'] );
		// Taxonomy.
		$wpm_taxonomy = wp_strip_all_tags( $instance['wpm_taxonomy'] );
		// Order by.
		$wpm_orderby = wp_strip_all_tags( $instance['wpm_orderby'] );
		// Style.
		$wpm_style = wp_strip_all_tags( $instance['wpm_style'] );
		// Number posts.
		$wpm_number_posts = absint( $instance['wpm_number_posts'] );
		// Number tags.
		$wpm_number_tags = absint( $instance['wpm_number_tags'] );
		// tag id.
		$wpm_idtag = wp_strip_all_tags( $instance['wpm_idtag'] );

		?>

		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'wpmedia' ); ?></label>
			<input class="widefat" id="<?php echo esc_html( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_html( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'subtitle' ) ); ?>"><?php esc_html_e( 'Description Title:', 'wpmedia' ); ?></label>
			<textarea class="widefat" rows="3" id="<?php echo esc_html( $this->get_field_id( 'subtitle' ) ); ?>" name="<?php echo esc_html( $this->get_field_name( 'subtitle' ) ); ?>"><?php echo esc_textarea( $instance['subtitle'] ); ?></textarea>
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'wpm_taxonomy' ) ); ?>">
				<?php esc_html_e( 'Taxonomy', 'wpmedia' ); ?>
			</label>
			<select class="widefat" id="<?php echo esc_html( $this->get_field_id( 'wpm_taxonomy', 'wpmedia' ) ); ?>"
				name="<?php echo esc_html( $this->get_field_name( 'wpm_taxonomy' ) ); ?>">
				<option value="category" <?php echo selected( $instance['wpm_taxonomy'], 'category', false ); ?>>
					<?php esc_html_e( 'Categories', 'wpmedia' ); ?>
				</option>
				<option value="post_tag" <?php echo selected( $instance['wpm_taxonomy'], 'post_tag', false ); ?>>
					<?php esc_html_e( 'Tags', 'wpmedia' ); ?>
				</option>
			</select>
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'wpm_orderby' ) ); ?>">
				<?php esc_html_e( 'Order By', 'wpmedia' ); ?>
			</label>
			<select class="widefat" id="<?php echo esc_html( $this->get_field_id( 'wpm_orderby', 'wpmedia' ) ); ?>"
				name="<?php echo esc_html( $this->get_field_name( 'wpm_orderby' ) ); ?>">
				<option value="count" <?php echo selected( $instance['wpm_orderby'], 'count', false ); ?>>
					<?php esc_html_e( 'Count', 'wpmedia' ); ?>
				</option>
				<option value="name" <?php echo selected( $instance['wpm_orderby'], 'name', false ); ?>>
					<?php esc_html_e( 'Name', 'wpmedia' ); ?>
				</option>
			</select>
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'wpm_style' ) ); ?>">
				<?php esc_html_e( 'Style', 'wpmedia' ); ?>
			</label>
			<select class="widefat" id="<?php echo esc_html( $this->get_field_id( 'wpm_style', 'wpmedia' ) ); ?>"
				name="<?php echo esc_html( $this->get_field_name( 'wpm_style' ) ); ?>">
				<option value="style_1" <?php echo selected( $instance['wpm_style'], 'style_1', false ); ?>>
					<?php esc_html_e( 'List 1 column (Default)', 'wpmedia' ); ?>
				</option>
				<option value="style_2" <?php echo selected( $instance['wpm_style'], 'style_2', false ); ?>>
					<?php esc_html_e( 'List 2 columns', 'wpmedia' ); ?>
				</option>
				<option value="style_3" <?php echo selected( $instance['wpm_style'], 'style_3', false ); ?>>
					<?php esc_html_e( 'Add # before title (1 Column)', 'wpmedia' ); ?>
				</option>
			</select>
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'wpm_number_posts' ) ); ?>"><?php esc_html_e( 'Minimal Posts:', 'wpmedia' ); ?></label>
			<input class="widefat" id="<?php echo esc_html( $this->get_field_id( 'wpm_number_posts' ) ); ?>" name="<?php echo esc_html( $this->get_field_name( 'wpm_number_posts' ) ); ?>" type="number" value="<?php echo esc_attr( $wpm_number_posts ); ?>" />
			<br />
			<small><?php esc_html_e( 'Minimal Posts For Displaying Tags or category. For example you want display tag if the tag or category have 6 posts, you can insert 6. Default is 1', 'wpmedia' ); ?></small>
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'wpm_number_tags' ) ); ?>"><?php esc_html_e( 'Number Display:', 'wpmedia' ); ?></label>
			<input class="widefat" id="<?php echo esc_html( $this->get_field_id( 'wpm_number_tags' ) ); ?>" name="<?php echo esc_html( $this->get_field_name( 'wpm_number_tags' ) ); ?>" type="number" value="<?php echo esc_attr( $wpm_number_tags ); ?>" />
			<br />
			<small><?php esc_html_e( 'Number tag or category to displaying in your widget. Default 5, for displaying all tags or category you can insert 0', 'wpmedia' ); ?></small>
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'wpm_idtag' ) ); ?>"><?php esc_html_e( 'Include ID:', 'wpmedia' ); ?></label>
			<input class="widefat" id="<?php echo esc_html( $this->get_field_id( 'wpm_idtag' ) ); ?>" name="<?php echo esc_html( $this->get_field_name( 'wpm_idtag' ) ); ?>" type="text" value="<?php echo esc_attr( $wpm_idtag ); ?>" />
			<br />
			<small><?php esc_html_e( 'You can include exclusive tags/category, just insert ID Tags separate by commas(,). Example: 1,2,3,4. Leave blank if you want display by default tags', 'wpmedia' ); ?></small>
		</p>
		<?php
	}

}

add_action(
	'widgets_init',
	function() {
		register_widget( 'Wpmedia_TagList_Widget' );
	}
);
