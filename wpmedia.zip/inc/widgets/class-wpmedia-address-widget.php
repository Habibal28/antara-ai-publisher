<?php
/**
 * Widget API: Wpmedia_Address_Widget class
 *
 * Author: Gian MR - http://www.gianmr.com
 *
 * @package Wpmedia
 * @subpackage Widgets
 * @since 1.0.0
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add the RPSL widget.
 *
 * @since 1.0.0
 *
 * @see WP_Widget
 */
class Wpmedia_Address_Widget extends WP_Widget {

	/**
	 * Sets up a Recent Posts widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'classname'             => 'wpmedia-address',
			'description'           => __( 'Add your address company.', 'wpmedia' ),
			'show_instance_in_rest' => true,
		);
		parent::__construct( 'wpmedia-addr', __( 'Contact Info (Wpmedia)', 'wpmedia' ), $widget_ops );

		// Add action for admin_register_scripts.
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_register_scripts' ) );

	}

	/**
	 * Enqueue scripts.
	 *
	 * @since 1.0
	 *
	 * @param string $hook_suffix Hook Suffix.
	 */
	public function admin_register_scripts( $hook_suffix ) {
		if ( 'widgets.php' !== $hook_suffix ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_script( 'wpmedia-widget-upload-image-js', get_template_directory_uri() . '/js/admin/widget-upload-image.js', array( 'jquery' ), '1.0.0', true );
	}

	/**
	 * Outputs the content for Recent Posts.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for Recent Posts.
	 */
	public function widget( $args, $instance ) {

		// Title.
		$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );
		// URL.
		$link_title = ( ! empty( $instance['link_title'] ) ) ? esc_url( $instance['link_title'] ) : '';
		// URL Image.
		$title_image = ( ! empty( $instance['title_image'] ) ) ? esc_url( $instance['title_image'] ) : '';
		// Base Id Widget.
		$wpm_widget_id = $this->id_base . '-' . $this->number;
		// Subtitle.
		$subtitle = ( ! empty( $instance['subtitle'] ) ) ? $instance['subtitle'] : '';
		echo $args['before_widget']; // phpcs:ignore
		if ( $title || $title_image ) {
			$titleimage_class = $title_image ? ' widget-titleimg' : '';
			echo '<div class="page-header widget-titlewrap' . esc_attr( $titleimage_class ) . '">';
			echo $args['before_title']; // phpcs:ignore
			if ( $title_image ) {
				if ( ! empty( $link_title ) ) {
					echo '<a href="' . esc_url( $link_title ) . '" title="' . esc_html__( 'View More', 'wpmedia' ) . '">';
				}
				echo '<span class="img-titlebg" style="background-image:url(\'' . esc_url( $title_image ) . '\');"></span>';
				if ( ! empty( $link_title ) ) {
					echo '</a>';
				}
			} else {
				echo wp_kses_post( $title );
			}
			echo $args['after_title']; // phpcs:ignore
			if ( ! empty( $link_title ) && empty( $title_image ) ) {
				echo '<div class="icon-linktitle">';
				echo '<a class="heading-text" href="' . esc_url( $link_title ) . '" title="' . esc_html__( 'View More', 'wpmedia' ) . '"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M19 19H5V5h7V3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z"/></svg></a>';
				echo '</div>';
			}
			echo '</div>';
			if ( $subtitle ) {
				echo '<div class="widget-subtitle">' . wp_kses_post( $subtitle ) . '</div>';
			}
		}
		// Address.
		$wpm_address = ( ! empty( $instance['wpm_address'] ) ) ? $instance['wpm_address'] : '';
		// Phone.
		$wpm_phone = ( ! empty( $instance['wpm_phone'] ) ) ? esc_html( $instance['wpm_phone'] ) : '';
		// Mail.
		$wpm_mail = ( ! empty( $instance['wpm_mail'] ) ) ? esc_html( $instance['wpm_mail'] ) : '';

		if ( $wpm_address || $wpm_phone || $wpm_mail ) {
			echo '<div class="wpmedia-contactinfo">';
			if ( $wpm_address ) {
				echo '<div class="wpmedia-address">';
				echo '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0z" fill="none"/><path d="M12 12c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm6-1.8C18 6.57 15.35 4 12 4s-6 2.57-6 6.2c0 2.34 1.95 5.44 6 9.14 4.05-3.7 6-6.8 6-9.14zM12 2c4.2 0 8 3.22 8 8.2 0 3.32-2.67 7.25-8 11.8-5.33-4.55-8-8.48-8-11.8C4 5.22 7.8 2 12 2z"/></svg>';
				echo '<div class="addr-content">' . wp_kses_post( $wpm_address ) . '</div>';
				echo '</div>';
			}
			if ( $wpm_phone ) {
				echo '<div class="wpmedia-phone">';
				echo '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M6.54 5c.06.89.21 1.76.45 2.59l-1.2 1.2c-.41-1.2-.67-2.47-.76-3.79h1.51m9.86 12.02c.85.24 1.72.39 2.6.45v1.49c-1.32-.09-2.59-.35-3.8-.75l1.2-1.19M7.5 3H4c-.55 0-1 .45-1 1 0 9.39 7.61 17 17 17 .55 0 1-.45 1-1v-3.49c0-.55-.45-1-1-1-1.24 0-2.45-.2-3.57-.57-.1-.04-.21-.05-.31-.05-.26 0-.51.1-.71.29l-2.2 2.2c-2.83-1.45-5.15-3.76-6.59-6.59l2.2-2.2c.28-.28.36-.67.25-1.02C8.7 6.45 8.5 5.25 8.5 4c0-.55-.45-1-1-1z"/></svg>';
				echo '<div class="addr-content">' . wp_kses_post( $wpm_phone ) . '</div>';
				echo '</div>';
			}
			if ( $wpm_mail ) {
				echo '<div class="wpmedia-mail">';
				// Sanitize email.
				$sanitize_email = sanitize_email( $wpm_mail );
				$is_email       = is_email( $sanitize_email );
				// Spam protect email address.
				$protected_email = $is_email ? antispambot( $sanitize_email ) : $sanitize_email;
				echo '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M22 6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6zm-2 0l-8 4.99L4 6h16zm0 12H4V8l8 5 8-5v10z"/></svg>';
				echo '<div class="addr-content"><a href="mailto:' . $protected_email . '" title="' . esc_html__( 'Send Mail', 'wpmedia' ) . '" target="_blank">' . wp_kses_post( $wpm_mail ) . '</a></div>'; //phpcs:ignore
				echo '</div>';
			}
			echo '</div>';
		}

		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Handles updating settings for the current Mailchimp widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            Wpmedia_Mailchimp_form::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Updated settings to save.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		$new_instance = wp_parse_args(
			(array) $new_instance,
			array(
				'title'       => '',
				'link_title'  => '',
				'title_image' => '',
				'subtitle'    => '',
				'wpm_address' => '',
				'wpm_phone'   => '',
				'wpm_mail'    => '',
			)
		);

		// Title.
		$instance['title'] = sanitize_text_field( $new_instance['title'] );
		// Link Title.
		$instance['link_title'] = esc_url_raw( $new_instance['link_title'] );
		// Title Image.
		$instance['title_image'] = esc_url_raw( $new_instance['title_image'] );
		// SubTitle.
		$instance['subtitle'] = sanitize_text_field( $new_instance['subtitle'] );
		// Address.
		$instance['wpm_address'] = sanitize_text_field( $new_instance['wpm_address'] );
		// Phone.
		$instance['wpm_phone'] = wp_strip_all_tags( $new_instance['wpm_phone'] );
		// Mail.
		$instance['wpm_mail'] = sanitize_email( $new_instance['wpm_mail'] );

		return $instance;
	}

	/**
	 * Outputs the settings form for the Mailchimp widget.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$instance = wp_parse_args(
			(array) $instance,
			array(
				'title'       => __( 'Contact Info', 'wpmedia' ),
				'link_title'  => '',
				'title_image' => '',
				'subtitle'    => '',
				'wpm_address' => '',
				'wpm_phone'   => '',
				'wpm_mail'    => '',
			)
		);
		// Title.
		$title = sanitize_text_field( $instance['title'] );
		// Link Title.
		$link_title = esc_url( $instance['link_title'] );
		// Link Title.
		$title_image = esc_url( $instance['title_image'] );
		// SubTitle.
		$subtitle = sanitize_text_field( $instance['subtitle'] );
		// Address.
		$wpm_address = sanitize_text_field( $instance['wpm_address'] );
		// Phone.
		$wpm_phone = wp_strip_all_tags( $instance['wpm_phone'] );
		// Email.
		$wpm_mail = sanitize_email( $instance['wpm_mail'] );

		?>

		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'title' ) ); ?>">
				<?php esc_html_e( 'Title:', 'wpmedia' ); ?>
			</label>
			<input class="widefat" id="<?php echo esc_html( $this->get_field_id( 'title' ) ); ?>"
				name="<?php echo esc_html( $this->get_field_name( 'title' ) ); ?>" type="text"
				value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'link_title' ) ); ?>">
				<?php esc_html_e( 'Link Title:', 'wpmedia' ); ?>
			</label>
			<input class="widefat" id="<?php echo esc_html( $this->get_field_id( 'link_title' ) ); ?>"
				name="<?php echo esc_html( $this->get_field_name( 'link_title' ) ); ?>" type="url"
				value="<?php echo esc_attr( $link_title ); ?>" />
			<br />
			<small><?php esc_html_e( 'Target url for title (example: https://www.domain.com/target), leave blank if you want using title without link.', 'wpmedia' ); ?></small>
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'title_image' ) ); ?>">
				<?php esc_html_e( 'Title Image:', 'wpmedia' ); ?>
			</label><br />
			<span id="<?php echo esc_attr( $this->get_field_id( 'title_image' ) ); ?>-preview">
			<?php if ( ! empty( $title_image ) ) : ?>
				<img src="<?php echo esc_attr( $title_image ); ?>" alt="" style="max-width:200px; height:auto; margin: 0px 0px 5px; display: block;">
			<?php endif; ?>
			</span>
			<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'title_image' ) ); ?>" class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'title_image' ) ); ?>" value="<?php echo esc_attr( $title_image ); ?>" />
			<br />
			<small>
				<?php esc_html_e( 'This options, will replace your title widget with image. Please using image size: height: 32px and maximal width: 300px', 'wpmedia' ); ?>
			</small><br />
			<span>
				<input type="button" value="<?php echo esc_html_e( 'Remove Image', 'wpmedia' ); ?>" class="button idt-media-remove" id="<?php echo esc_attr( $this->get_field_id( 'title_image' ) ); ?>-remove" <?php echo ( '' !== $title_image ) ? '' : 'style="display:none;"'; ?> />
				<input type="button" value="<?php echo esc_html_e( 'Select Image', 'wpmedia' ); ?>" class="button idt-media-upload button-primary" id="<?php echo esc_attr( $this->get_field_id( 'title_image' ) ); ?>-button" />
			</span>
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'subtitle' ) ); ?>">
				<?php esc_html_e( 'Description Title:', 'wpmedia' ); ?>
			</label>
			<textarea class="widefat" rows="3" id="<?php echo esc_html( $this->get_field_id( 'subtitle' ) ); ?>"
				name="<?php echo esc_html( $this->get_field_name( 'subtitle' ) ); ?>"><?php echo esc_textarea( $instance['subtitle'] ); ?></textarea>
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'wpm_address' ) ); ?>">
				<?php esc_html_e( 'Address:', 'wpmedia' ); ?>
			</label>
			<textarea class="widefat" rows="3" id="<?php echo esc_html( $this->get_field_id( 'wpm_address' ) ); ?>"
				name="<?php echo esc_html( $this->get_field_name( 'wpm_address' ) ); ?>"><?php echo esc_textarea( $instance['wpm_address'] ); ?></textarea>
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'wpm_phone' ) ); ?>">
				<?php esc_html_e( 'Phone:', 'wpmedia' ); ?>
			</label>
			<input class="widefat" id="<?php echo esc_html( $this->get_field_id( 'wpm_phone' ) ); ?>"
				name="<?php echo esc_html( $this->get_field_name( 'wpm_phone' ) ); ?>" type="text"
				value="<?php echo esc_attr( $wpm_phone ); ?>" />
			<br />
			<small>
				<?php esc_html_e( 'Insert phone number here...', 'wpmedia' ); ?>
			</small>
		</p>
		<p>
			<label for="<?php echo esc_html( $this->get_field_id( 'wpm_mail' ) ); ?>">
				<?php esc_html_e( 'Email:', 'wpmedia' ); ?>
			</label>
			<input class="widefat" id="<?php echo esc_html( $this->get_field_id( 'wpm_mail' ) ); ?>"
				name="<?php echo esc_html( $this->get_field_name( 'wpm_mail' ) ); ?>" type="text"
				value="<?php echo esc_attr( $wpm_mail ); ?>" />
			<br />
			<small>
				<?php esc_html_e( 'Insert email here...', 'wpmedia' ); ?>
			</small>
		</p>
		<?php
	}
}

add_action(
	'widgets_init',
	function () {
		register_widget( 'Wpmedia_Address_Widget' );
	}
);
