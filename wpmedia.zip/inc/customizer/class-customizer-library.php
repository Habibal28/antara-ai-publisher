<?php
/**
 * Customizer Library
 *
 * @package        Customizer_Library
 * @license        GPL-2.0+
 * @version        1.3.0
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

// Continue if the Customizer_Library isn't already in use.
if ( ! class_exists( 'Customizer_Library' ) ) :

	// Helper functions to output the customizer controls.
	require get_template_directory() . '/inc/customizer/extensions/interface.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound

	// Helper functions for customizer sanitization.
	require get_template_directory() . '/inc/customizer/extensions/sanitization.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound

	// Helper functions to build the inline CSS New From Idtheme.
	require get_template_directory() . '/inc/customizer/extensions/class-idtheme-css-utils.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound

	// Utility functions for the customizer.
	require get_template_directory() . '/inc/customizer/extensions/utilities.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound

	// Customizer preview functions.
	require get_template_directory() . '/inc/customizer/extensions/preview.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound

	// Arbitrary content controls.
	require get_template_directory() . '/inc/customizer/custom-controls/class-customizer-library-content.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound

	// Category dropdown controls.
	require get_template_directory() . '/inc/customizer/custom-controls/class-customizer-library-categories.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound

	// Google Fonts controls.
	require get_template_directory() . '/inc/customizer/custom-controls/class-customizer-library-google-font.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound

	// Gradient Color.
	require get_template_directory() . '/inc/customizer/custom-controls/class-customizer-library-gradient.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound

	/**
	 * Class wrapper with useful methods for interacting with the theme customizer.
	 */
	class Customizer_Library {

		/**
		 * The one instance of Customizer_Library.
		 *
		 * @since 1.0.0.
		 *
		 * @var   Customizer_Library_Styles    The one instance for the singleton.
		 */
		private static $instance;

		/**
		 * The array for storing $options.
		 *
		 * @since 1.0.0.
		 *
		 * @var   array    Holds the options array.
		 */

		public $options = array();

		/**
		 * Instantiate or return the one Customizer_Library instance.
		 *
		 * @since  1.0.0.
		 *
		 * @return Customizer_Library
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Add Options.
		 *
		 * @since  1.0.0.
		 * @param array $options Options.
		 * @return void
		 */
		public function add_options( $options = array() ) {
			$this->options = array_merge( $options, $this->options );
		}

		/**
		 * Get Options.
		 *
		 * @since  1.0.0.
		 * @return string
		 */
		public function get_options() {
			return $this->options;
		}

	}

endif;
