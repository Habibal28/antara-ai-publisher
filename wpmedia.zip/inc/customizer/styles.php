<?php
/**
 * Custom template tags for this theme.
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package wpmedia
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'gmr_library_customizer_build_styles' ) && class_exists( 'Idtheme_Css_Utils' ) ) :
	/**
	 * Process user options to generate CSS needed to implement the choices.
	 *
	 * @since 1.0.0
	 */
	function gmr_library_customizer_build_styles() {

		$class_name = 'Idtheme_Css_Utils';
		$class      = new $class_name();

		// Header Font.
		$setting    = 'gmr_primary-font';
		$font       = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		$headerfont = '';
		if ( $font ) {
			$headerfont = json_decode( $font, true );
			if ( is_array( $headerfont ) ) {
				$class->add_item(
					array(
						'element'    => 'h1,h2,h3,h4,h5,h6,.reltitle,.site-title,.gmr-mainmenu ul > li > a,.gmr-secondmenu-dropdown ul > li > a,.gmr-sidemenu ul li a,.gmr-sidemenu .side-textsocial,.heading-text,.gmr-mobilemenu ul li a,#navigationamp ul li a',
						'properties' => array(
							array(
								'property' => 'font-family',
								'value'    => isset( $headerfont['font'] ) && ! empty( $headerfont['font'] ) ? esc_attr( $headerfont['font'] ) : '',
							),
							array(
								'property' => 'font-weight',
								'value'    => isset( $headerfont['regularweight'] ) && ! empty( $headerfont['regularweight'] ) ? esc_attr( $headerfont['regularweight'] ) : '',
							),
						),
					)
				);
				$class->add_item(
					array(
						'element'    => 'h1 strong,h2 strong,h3 strong,h4 strong,h5 strong,h6 strong',
						'properties' => array(
							array(
								'property' => 'font-weight',
								'value'    => isset( $headerfont['boldweight'] ) && ! empty( $headerfont['boldweight'] ) ? esc_attr( $headerfont['boldweight'] ) : '',
							),
						),
					)
				);
			}
		}

		// Single font size.
		$setting = 'gmr_single_size';
		$mod     = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		$class->add_item(
			array(
				'element'    => '.entry-content-single',
				'properties' => array(
					array(
						'property' => 'font-size',
						'value'    => isset( $mod ) && ! empty( $mod ) ? absint( $mod ) . 'px' : '',
					),
				),
			)
		);

		// Header Background image.
		$url             = has_header_image() ? get_header_image() : get_theme_support( 'custom-header', 'default-image' );
		$setting         = 'gmr_active-headerimage';
		$activeheadimage = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( 0 === $activeheadimage && has_header_image() ) {
			// Header Background Size.
			$setting = 'gmr_headerimage_bgsize';
			$bgsize  = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

			// Header Background Repeat.
			$setting  = 'gmr_headerimage_bgrepeat';
			$bgrepeat = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

			// Header Background Position.
			$setting    = 'gmr_headerimage_bgposition';
			$bgposition = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

			// Header Background Attachment.
			$setting      = 'gmr_headerimage_bgattachment';
			$bgattachment = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

			$class->add_item(
				array(
					'element'    => '.gmr-topnavwrap',
					'properties' => array(
						array(
							'property' => 'background-image',
							'value'    => 'url(' . esc_url( $url ) . ')',
						),
						array(
							'property' => 'background-size',
							'value'    => isset( $bgsize ) && ! empty( $bgsize ) ? wp_filter_nohtml_kses( $bgsize ) : '',
						),
						array(
							'property' => 'background-repeat',
							'value'    => isset( $bgrepeat ) && ! empty( $bgsize ) ? wp_filter_nohtml_kses( $bgrepeat ) : '',
						),
						array(
							'property' => 'background-position',
							'value'    => isset( $bgposition ) && ! empty( $bgposition ) ? wp_filter_nohtml_kses( $bgposition ) : '',
						),
						array(
							'property' => 'background-attachment',
							'value'    => isset( $bgattachment ) && ! empty( $bgattachment ) ? wp_filter_nohtml_kses( $bgattachment ) : '',
						),
					),
				)
			);
		}

		// Body Font.
		$setting = 'gmr_secondary-font';
		$font    = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		$bodyfont        = '';
		$bodyfontfamily  = '';
		$bodyfontreguler = '';
		$bodyfontbold    = '';
		if ( $font ) {
			$bodyfont = json_decode( $font, true );
			if ( is_array( $bodyfont ) ) {
				if ( ! empty( $bodyfont['font'] ) ) {
					$bodyfontfamily  = isset( $bodyfont['font'] ) && ! empty( $bodyfont['font'] ) ? esc_attr( $bodyfont['font'] ) : '';
					$bodyfontreguler = isset( $bodyfont['regularweight'] ) && ! empty( $bodyfont['regularweight'] ) ? esc_attr( $bodyfont['regularweight'] ) : '';
					$bodyfontbold    = isset( $bodyfont['boldweight'] ) && ! empty( $bodyfont['boldweight'] ) ? esc_attr( $bodyfont['boldweight'] ) : '';
				}
			}
		}

		// Mainmenu Color.
		$setting   = 'gmr_mainmenu-bgcolor';
		$menucolor = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		$color                 = '';
		$mainmenubgcolor       = '';
		$mainmenusecondbgcolor = '';
		$mainmenudirection     = '';
		if ( $menucolor ) {
			$color = json_decode( $menucolor, true );

			if ( is_array( $color ) ) {
				$mainmenubgcolor       = isset( $color['color1'] ) && ! empty( $color['color1'] ) ? sanitize_hex_color( $color['color1'] ) : '';
				$mainmenusecondbgcolor = isset( $color['color2'] ) && ! empty( $color['color2'] ) ? sanitize_hex_color( $color['color2'] ) : '';
				$mainmenudirection     = isset( $color['direction'] ) && ! empty( $color['direction'] ) ? intval( $color['direction'] ) . 'deg' : '';
			}
		}

		// Background Color.
		$setting = 'background_color';
		$bgcolor = get_theme_mod( $setting, get_theme_support( 'custom-background', 'default-color' ) );

		// Content Color.
		$setting      = 'gmr_content-color';
		$contentcolor = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		// Content Link Color.
		$setting          = 'gmr_content-linkcolor';
		$contentlinkcolor = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		// Content Link Hover Color.
		$setting               = 'gmr_content-linkhovercolor';
		$contentlinkcolorhover = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		// Content Border Color.
		$setting     = 'gmr_content-bordercolor';
		$bordercolor = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		// Button background Color.
		$setting       = 'gmr_button-bgcolor';
		$buttonbgcolor = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		// Button Color.
		$setting     = 'gmr_button-color';
		$buttoncolor = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		// Header Background Color.
		$setting       = 'gmr_header-bgcolor';
		$headerbgcolor = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		// Topnav Color.
		$setting     = 'gmr_topnav-color';
		$topnavcolor = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		// Topnav Link Color.
		$setting         = 'gmr_topnav-linkcolor';
		$topnavlinkcolor = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		// Topnav Link Hover Color.
		$setting              = 'gmr_topnav-linkhovercolor';
		$topnavlinkcolorhover = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		// Menu text color.
		$setting       = 'gmr_mainmenu-color';
		$menutextcolor = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		// Hover text color.
		$setting            = 'gmr_hovermenu-color';
		$menutextcolorhover = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		// Content Background Color.
		$setting        = 'gmr_content-bgcolor';
		$contentbgcolor = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		// Grey Color - Content.
		$setting          = 'gmr_content-greycolor';
		$contentgreycolor = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		// Grey Background Color - Content.
		$setting            = 'gmr_content-greybgcolor';
		$contentgreybgcolor = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		// Footer Background Color.
		$setting       = 'gmr_footer-bgcolor';
		$footerbgcolor = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		// Footer Font Color.
		$setting     = 'gmr_footer-fontcolor';
		$footercolor = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		// Footer Link Color.
		$setting         = 'gmr_footer-linkcolor';
		$footerlinkcolor = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		// Footer Hover Link Color.
		$setting              = 'gmr_footer-hoverlinkcolor';
		$footerlinkcolorhover = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		$class->add_item(
			array(
				'element'    => 'body',
				'properties' => array(
					array(
						'property' => 'font-family',
						'value'    => isset( $bodyfontfamily ) && ! empty( $bodyfontfamily ) ? esc_attr( $bodyfontfamily ) : '',
					),
					array(
						'property' => '--font-reguler',
						'value'    => isset( $bodyfontreguler ) && ! empty( $bodyfontreguler ) ? esc_attr( $bodyfontreguler ) : '',
					),
					array(
						'property' => '--font-bold',
						'value'    => isset( $bodyfontbold ) && ! empty( $bodyfontbold ) ? esc_attr( $bodyfontbold ) : '',
					),
					array(
						'property' => '--mainmenu-bgcolor',
						'value'    => isset( $mainmenubgcolor ) && ! empty( $mainmenubgcolor ) ? sanitize_hex_color( $mainmenubgcolor ) : '',
					),
					array(
						'property' => '--mainmenu-secondbgcolor',
						'value'    => isset( $mainmenusecondbgcolor ) && ! empty( $mainmenusecondbgcolor ) ? sanitize_hex_color( $mainmenusecondbgcolor ) : '',
					),
					array(
						'property' => '--background-color',
						'value'    => isset( $bgcolor ) && ! empty( $bgcolor ) ? '#' . sanitize_hex_color_no_hash( $bgcolor ) : '',
					),
					array(
						'property' => '--main-color',
						'value'    => isset( $contentcolor ) && ! empty( $contentcolor ) ? sanitize_hex_color( $contentcolor ) : '',
					),
					array(
						'property' => '--widget-title',
						'value'    => isset( $contentcolor ) && ! empty( $contentcolor ) ? sanitize_hex_color( $contentcolor ) : '', // Same with --main-color.
					),
					array(
						'property' => '--link-color-body',
						'value'    => isset( $contentlinkcolor ) && ! empty( $contentlinkcolor ) ? sanitize_hex_color( $contentlinkcolor ) : '',
					),
					array(
						'property' => '--hoverlink-color-body',
						'value'    => isset( $contentlinkcolorhover ) && ! empty( $contentlinkcolorhover ) ? sanitize_hex_color( $contentlinkcolorhover ) : '',
					),
					array(
						'property' => '--border-color',
						'value'    => isset( $bordercolor ) && ! empty( $bordercolor ) ? sanitize_hex_color( $bordercolor ) : '',
					),
					array(
						'property' => '--button-bgcolor',
						'value'    => isset( $buttonbgcolor ) && ! empty( $buttonbgcolor ) ? sanitize_hex_color( $buttonbgcolor ) : '',
					),
					array(
						'property' => '--button-color',
						'value'    => isset( $buttoncolor ) && ! empty( $buttoncolor ) ? sanitize_hex_color( $buttoncolor ) : '',
					),
					array(
						'property' => '--header-bgcolor',
						'value'    => isset( $headerbgcolor ) && ! empty( $headerbgcolor ) ? sanitize_hex_color( $headerbgcolor ) : '',
					),
					array(
						'property' => '--topnav-color',
						'value'    => isset( $topnavcolor ) && ! empty( $topnavcolor ) ? sanitize_hex_color( $topnavcolor ) : '',
					),
					array(
						'property' => '--topnav-link-color',
						'value'    => isset( $topnavlinkcolor ) && ! empty( $topnavlinkcolor ) ? sanitize_hex_color( $topnavlinkcolor ) : '',
					),
					array(
						'property' => '--topnav-linkhover-color',
						'value'    => isset( $topnavlinkcolorhover ) && ! empty( $topnavlinkcolorhover ) ? sanitize_hex_color( $topnavlinkcolorhover ) : '',
					),
					array(
						'property' => '--mainmenu-color',
						'value'    => isset( $menutextcolor ) && ! empty( $menutextcolor ) ? sanitize_hex_color( $menutextcolor ) : '',
					),
					array(
						'property' => '--mainmenu-hovercolor',
						'value'    => isset( $menutextcolorhover ) && ! empty( $menutextcolorhover ) ? sanitize_hex_color( $menutextcolorhover ) : '',
					),
					array(
						'property' => '--content-bgcolor',
						'value'    => isset( $contentbgcolor ) && ! empty( $contentbgcolor ) ? sanitize_hex_color( $contentbgcolor ) : '',
					),
					array(
						'property' => '--content-greycolor',
						'value'    => isset( $contentgreycolor ) && ! empty( $contentgreycolor ) ? sanitize_hex_color( $contentgreycolor ) : '',
					),
					array(
						'property' => '--greybody-bgcolor',
						'value'    => isset( $contentgreybgcolor ) && ! empty( $contentgreybgcolor ) ? sanitize_hex_color( $contentgreybgcolor ) : '',
					),
					array(
						'property' => '--footer-bgcolor',
						'value'    => isset( $footerbgcolor ) && ! empty( $footerbgcolor ) ? sanitize_hex_color( $footerbgcolor ) : '',
					),
					array(
						'property' => '--footer-color',
						'value'    => isset( $footercolor ) && ! empty( $footercolor ) ? sanitize_hex_color( $footercolor ) : '',
					),
					array(
						'property' => '--footer-linkcolor',
						'value'    => isset( $footerlinkcolor ) && ! empty( $footerlinkcolor ) ? sanitize_hex_color( $footerlinkcolor ) : '',
					),
					array(
						'property' => '--footer-hover-linkcolor',
						'value'    => isset( $footerlinkcolorhover ) && ! empty( $footerlinkcolorhover ) ? sanitize_hex_color( $footerlinkcolorhover ) : '',
					),
				),
			)
		);

		// Color scheme.
		$setting     = 'gmr_scheme-color';
		$schemecolor = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		// Second Color scheme.
		$setting           = 'gmr_second-scheme-color';
		$secondschemecolor = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

		$class->add_item(
			array(
				'element'    => 'body,body.dark-theme',
				'properties' => array(
					array(
						'property' => '--scheme-color',
						'value'    => isset( $schemecolor ) && ! empty( $schemecolor ) ? sanitize_hex_color( $schemecolor ) : '',
					),
					array(
						'property' => '--secondscheme-color',
						'value'    => isset( $secondschemecolor ) && ! empty( $secondschemecolor ) ? sanitize_hex_color( $secondschemecolor ) : '',
					),
					array(
						'property' => '--mainmenu-direction',
						'value'    => isset( $color['direction'] ) && ! empty( $color['direction'] ) ? intval( $color['direction'] ) . 'deg' : '',
					),
				),
			)
		);

		if ( class_exists( 'WooCommerce' ) ) {
			// Price.
			$setting = 'gmr_price-color';
			$price   = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

			// Badge.
			$setting = 'gmr_badge-color';
			$badge   = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

			// Badge bg color.
			$setting = 'gmr_badge-bgcolor';
			$badgebg = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

			// Alt button color.
			$setting        = 'gmr_altbutton-color';
			$altbuttoncolor = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

			// Alt button background color.
			$setting          = 'gmr_altbutton-color';
			$altbuttonbgcolor = get_theme_mod( $setting, customizer_library_get_default( $setting ) );

			$class->add_item(
				array(
					'element'    => 'body.woocommerce',
					'properties' => array(
						array(
							'property' => '--price-color',
							'value'    => isset( $price ) && ! empty( $price ) ? sanitize_hex_color( $price ) : '',
						),
						array(
							'property' => '--badge-color',
							'value'    => isset( $badge ) && ! empty( $badge ) ? sanitize_hex_color( $badge ) : '',
						),
						array(
							'property' => '--badge-bgcolor',
							'value'    => isset( $badgebg ) && ! empty( $badgebg ) ? sanitize_hex_color( $badgebg ) : '',
						),
						array(
							'property' => '--altbutton-color',
							'value'    => isset( $altbuttoncolor ) && ! empty( $altbuttoncolor ) ? sanitize_hex_color( $altbuttoncolor ) : '',
						),
						array(
							'property' => '--altbutton-bgcolor',
							'value'    => isset( $altbuttonbgcolor ) && ! empty( $altbuttonbgcolor ) ? sanitize_hex_color( $altbuttonbgcolor ) : '',
						),
					),
				)
			);
		}
		return (string) $class->generate();
	}
endif; // endif gmr_library_customizer_build_styles.

if ( ! function_exists( 'gmr_library_customizer_styles' ) && class_exists( 'Idtheme_Css_Utils' ) ) :
	/**
	 * Generates the style tag and CSS needed for the theme options.
	 *
	 * By using the "Customizer_Library_Styles" filter, different components can print CSS in the header.
	 * It is organized this way to ensure there is only one "style" tag.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function gmr_library_customizer_styles() {

		/**
		 * Load css from customizer
		 * If we're on the customizer then do not cache the results.
		 * Do not forget to remove_theme_mod cache after save customizer Function: bosanova_after_customizer_save() at:
		 *
		 * @link inc/customizer/extensions/utilities.php
		 */
		$css      = '';
		$cachecss = get_theme_mod( 'gmr_cache_dynamiccss', 1 );

		if ( 1 === $cachecss ) {
			if ( is_customize_preview() ) {
				$css = apply_filters( 'idtheme_output_css', gmr_library_customizer_build_styles() );
			} else {
				// Get the theme_mod from the database.
				$css = get_theme_mod( 'cache_css_customizer_styles' );

				// If the theme_mod does not exist, then create it.
				if ( ! isset( $css ) || false === $css || empty( $css ) ) {
					// We'll be adding our actual CSS using a filter.
					$css = apply_filters( 'idtheme_output_css', gmr_library_customizer_build_styles() );
					// Set the theme_mod.
					set_theme_mod( 'cache_css_customizer_styles', wp_strip_all_tags( $css ) . '/* Generate Using Cache */' );
				}
			}
		} else {
			$css = apply_filters( 'idtheme_output_css', gmr_library_customizer_build_styles() );
		}
		if ( isset( $css ) && ! empty( $css ) ) {
			wp_add_inline_style( 'wpmedia-style', $css );
		}
	}
endif; // endif gmr_library_customizer_styles.
add_action( 'wp_enqueue_scripts', 'gmr_library_customizer_styles' );

if ( ! function_exists( 'gmr_remove_customizer_register' ) ) :
	/**
	 * Add postMessage support for site title and description for the Theme Customizer.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
	 */
	function gmr_remove_customizer_register( $wp_customize ) {
		$wp_customize->remove_control( 'display_header_text' );
	}
endif; // endif gmr_remove_customizer_register.
add_action( 'customize_register', 'gmr_remove_customizer_register' );
