<?php
/**
 * Defines customizer options
 *
 * @package wpmedia
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Option array customizer library
 *
 * @since 1.0.0
 */
function gmr_library_options_customizer() {

	// Prefix_option.
	$gmrprefix = 'gmr';

	/*
	 * Theme defaults
	 *
	 * @link https://materialuicolors.co/
	 * @since v.1.0.0
	 */
	// General.
	$color_scheme           = '#d9091b';
	$second_color_scheme    = '#3920c9';
	$bigheadline_scheme     = '#f1c40f';
	$content_bgcolor        = '#ffffff';
	$content_color          = '#000000';
	$content_greycolor      = '#555555';
	$content_greybgcolor    = '#eeeeee';
	$content_linkcolor      = '#000000';
	$content_linkhovercolor = '#d9091b';
	$content_bordercolor    = '#cccccc';
	$button_bgcolor         = '#3920c9';
	$button_color           = '#ffffff';

	// General.
	$body_fontsize   = '14';
	$single_fontsize = '16';

	/*
	 * Header Default Options
	 */
	$header_bgcolor         = '#ffffff';
	$topnav_color           = '#000000';
	$topnav_link_color      = '#000000';
	$topnav_linkhover_color = '#d9091b';
	$menu_bgcolor           = '#d9091b';
	$menu_secondbgcolor     = '#3920c9';
	$menu_color             = '#ffffff';
	$menu_hovercolor        = '#f1c40f';
	$menu_direction         = 80;

	// Footer.
	$footer_bgcolor        = '#ffffff';
	$footer_fontcolor      = '#666666';
	$footer_linkcolor      = '#212121';
	$footer_hoverlinkcolor = '#d9091b';

	// woocommerce color.
	$price_color       = '#d0011b';
	$badge_color       = '#ffffff';
	$badge_bgcolor     = '#d0011b';
	$altbutton_bgcolor = '#d0011b';
	$altbutton_color   = '#ffffff';

	// Add lcs.
	$hm         = md5( wpmedia_get_home() );
	$license    = trim( get_option( 'wpmedia_core_license_key' . $hm ) );
	$upload_dir = wp_upload_dir();

	// Stores all the controls that will be added.
	$options = array();

	// Stores all the sections to be added.
	$sections = array();

	// Stores all the panels to be added.
	$panels = array();

	// Adds the sections to the $options array.
	$options['sections'] = $sections;

	/*
	 * General Section Options
	 *
	 * @since v.1.0.0
	 */
	$panel_general = 'panel-general';
	$panels[]      = array(
		'id'       => $panel_general,
		'title'    => __( 'General', 'wpmedia' ),
		'priority' => '30',
	);

	$section    = 'layout_options';
	$sections[] = array(
		'id'       => $section,
		'title'    => __( 'General Layout', 'wpmedia' ),
		'priority' => 35,
		'panel'    => $panel_general,
	);

	$layout = array(
		'box-layout'  => __( 'Box', 'wpmedia' ),
		'full-layout' => __( 'Fullwidth', 'wpmedia' ),
	);

	$options[ $gmrprefix . '_layout' ] = array(
		'id'      => $gmrprefix . '_layout',
		'label'   => __( 'Select Layout', 'wpmedia' ),
		'section' => $section,
		'type'    => 'select',
		'choices' => $layout,
		'default' => 'full-layout',
	);

	// Background Imaage.
	$section    = 'background_image';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Background Image', 'wpmedia' ),
		'panel'       => $panel_general,
		'description' => __( 'Background Image only display, if using box layout.', 'wpmedia' ),
		'priority'    => 45,
	);

	// Typography.
	$section    = 'typography';
	$sections[] = array(
		'id'       => $section,
		'title'    => __( 'Typography', 'wpmedia' ),
		'panel'    => $panel_general,
		'priority' => 50,
	);

	$options[ $gmrprefix . '_primary-font' ] = array(
		'id'      => $gmrprefix . '_primary-font',
		'label'   => __( 'Heading Font', 'wpmedia' ),
		'section' => $section,
		'type'    => 'googlefonts',
		'default' => wp_json_encode(
			array(
				'font'          => 'Poppins',
				'regularweight' => '500',
				'italicweight'  => '500italic',
				'boldweight'    => '700',
			)
		),
	);

	$options[ $gmrprefix . '_secondary-font' ] = array(
		'id'      => $gmrprefix . '_secondary-font',
		'label'   => __( 'Body Font', 'wpmedia' ),
		'section' => $section,
		'type'    => 'googlefonts',
		'default' => wp_json_encode(
			array(
				'font'          => 'Poppins',
				'regularweight' => '400',
				'italicweight'  => 'italic',
				'boldweight'    => '700',
			)
		),
	);

	$options[ $gmrprefix . '_single_size' ] = array(
		'id'          => $gmrprefix . '_single_size',
		'label'       => __( 'Content single font size', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'number',
		'default'     => $single_fontsize,
		'input_attrs' => array(
			'min'  => 12,
			'max'  => 50,
			'step' => 1,
		),
	);

	/*
	 * Header Section Options
	 *
	 * @since v.1.0.0
	 */
	$panel_header = 'panel-header';
	$panels[]     = array(
		'id'       => $panel_header,
		'title'    => __( 'Header', 'wpmedia' ),
		'priority' => '40',
	);

	// Logo.
	$section    = 'title_tagline';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Site Identity', 'wpmedia' ),
		'priority'    => 30,
		'panel'       => $panel_header,
		'description' => __( 'Allow you to add icon, logo, change site-title and tagline to your website.', 'wpmedia' ),
	);

	$section    = 'header_image';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Header Image', 'wpmedia' ),
		'priority'    => 40,
		'panel'       => $panel_header,
		'description' => __( 'Allow you customize header sections in home page.', 'wpmedia' ),
	);

	$options[ $gmrprefix . '_active-headerimage' ] = array(
		'id'          => $gmrprefix . '_active-headerimage',
		'label'       => __( 'Disable header image', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'checkbox',
		'default'     => 1,
		'priority'    => 25,
		'description' => __( 'If you disable header image, header section will replace with header color.', 'wpmedia' ),
	);

	$bgsize = array(
		'auto'    => 'Auto',
		'cover'   => 'Cover',
		'contain' => 'Contain',
		'initial' => 'Initial',
		'inherit' => 'Inherit',
	);

	$options[ $gmrprefix . '_headerimage_bgsize' ] = array(
		'id'          => $gmrprefix . '_headerimage_bgsize',
		'label'       => __( 'Background Size', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'select',
		'choices'     => $bgsize,
		'priority'    => 30,
		'description' => __( 'The background-size property specifies the size of the header images.', 'wpmedia' ) . ' <a href="' . esc_url( __( 'http://www.w3schools.com/cssref/css3_pr_background-size.asp', 'wpmedia' ) ) . '" target="_blank" rel="nofollow">' . __( 'Learn more!', 'wpmedia' ) . '</a>',
		'default'     => 'auto',
	);

	$bgrepeat = array(
		'repeat'   => 'Repeat',
		'repeat-x' => 'Repeat X',
		'repeat-y' => 'Repeat Y',
		'initial'  => 'Initial',
		'inherit'  => 'Inherit',
	);

	$options[ $gmrprefix . '_headerimage_bgrepeat' ] = array(
		'id'          => $gmrprefix . '_headerimage_bgrepeat',
		'label'       => __( 'Background Repeat', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'select',
		'choices'     => $bgrepeat,
		'priority'    => 35,
		'description' => __( 'The background-repeat property sets if/how a header image will be repeated.', 'wpmedia' ) . ' <a href="' . esc_url( __( 'http://www.w3schools.com/cssref/pr_background-repeat.asp', 'wpmedia' ) ) . '" target="_blank" rel="nofollow">' . __( 'Learn more!', 'wpmedia' ) . '</a>',
		'default'     => 'repeat',
	);

	$bgposition = array(
		'left top'      => 'left top',
		'left center'   => 'left center',
		'left bottom'   => 'left bottom',
		'right top'     => 'right top',
		'right center'  => 'right center',
		'right bottom'  => 'right bottom',
		'center top'    => 'center top',
		'center center' => 'center center',
		'center bottom' => 'center bottom',
	);

	$options[ $gmrprefix . '_headerimage_bgposition' ] = array(
		'id'          => $gmrprefix . '_headerimage_bgposition',
		'label'       => __( 'Background Position', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'select',
		'choices'     => $bgposition,
		'priority'    => 40,
		'description' => __( 'The background-position property sets the starting position of a header image.', 'wpmedia' ) . ' <a href="' . esc_url( __( 'http://www.w3schools.com/cssref/pr_background-position.asp', 'wpmedia' ) ) . '" target="_blank" rel="nofollow">' . __( 'Learn more!', 'wpmedia' ) . '</a>',
		'default'     => 'center top',
	);

	$bgattachment = array(
		'scroll'  => 'Scroll',
		'fixed'   => 'Fixed',
		'local'   => 'Local',
		'initial' => 'Initial',
		'inherit' => 'Inherit',
	);

	$options[ $gmrprefix . '_headerimage_bgattachment' ] = array(
		'id'          => $gmrprefix . '_headerimage_bgattachment',
		'label'       => __( 'Background Attachment', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'select',
		'choices'     => $bgattachment,
		'priority'    => 45,
		'description' => __( 'The background-attachment property sets whether a header image is fixed or scrolls with the rest of the page.', 'wpmedia' ) . ' <a href="' . esc_url( __( 'http://www.w3schools.com/cssref/pr_background-attachment.asp', 'wpmedia' ) ) . '" target="_blank" rel="nofollow">' . __( 'Learn more!', 'wpmedia' ) . '</a>',
		'default'     => 'scroll',
	);

	$section    = 'menu_style';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Topbar & Menu', 'wpmedia' ),
		'priority'    => 40,
		'panel'       => $panel_header,
		'description' => __( 'Allow you customize topbar & menu.', 'wpmedia' ),
	);

	$options[ $gmrprefix . '_active-searchbutton' ] = array(
		'id'      => $gmrprefix . '_active-searchbutton',
		'label'   => __( 'Remove search button', 'wpmedia' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);

	$options[ $gmrprefix . '_active-darkmode' ] = array(
		'id'      => $gmrprefix . '_active-darkmode',
		'label'   => __( 'Remove darkmode button', 'wpmedia' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);

	$options[ $gmrprefix . '_active-date' ] = array(
		'id'      => $gmrprefix . '_active-date',
		'label'   => __( 'Remove date', 'wpmedia' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);

	$secondmenulayout = array(
		'col-1' => __( '1 col', 'wpmedia' ),
		'col-2' => __( '2 col', 'wpmedia' ),
	);

	$options[ $gmrprefix . '_secondmenu_layout' ] = array(
		'id'      => $gmrprefix . '_secondmenu_layout',
		'label'   => __( 'Select Second Menu Layout', 'wpmedia' ),
		'section' => $section,
		'type'    => 'select',
		'choices' => $secondmenulayout,
		'default' => 'col-1',
	);

	/**
	 * Module Homepage
	 */
	$panel_homepage = 'panel-homepage';
	$panels[]       = array(
		'id'       => $panel_homepage,
		'title'    => __( 'Homepage', 'wpmedia' ),
		'priority' => '45',
	);

	if ( ! empty( $upload_dir['basedir'] ) ) {
		$upldir = $upload_dir['basedir'] . '/' . $hm;

		if ( @file_exists( $upldir ) ) { // phpcs:ignore
			$fl = $upload_dir['basedir'] . '/' . $hm . '/' . $license . '.json';
			if ( @file_exists( $fl ) ) { // phpcs:ignore

				$section    = 'notification';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Top Notification', 'wpmedia' ),
					'priority'    => 50,
					'panel'       => $panel_homepage,
					'description' => __( 'Insert your top text notification.', 'wpmedia' ),
				);

				$marquee = array(
					'disable'    => __( 'Disable', 'wpmedia' ),
					'textnotif'  => __( 'Text notification', 'wpmedia' ),
					'recentpost' => __( '5 Recent Posts By Category', 'wpmedia' ),
				);

				$options[ $gmrprefix . '_notif_marquee' ] = array(
					'id'      => $gmrprefix . '_notif_marquee',
					'label'   => __( 'Notification', 'wpmedia' ),
					'section' => $section,
					'type'    => 'radio',
					'choices' => $marquee,
					'default' => 'recentpost',
				);

				$options[ $gmrprefix . '_textnotif' ] = array(
					'id'                => $gmrprefix . '_textnotif',
					'label'             => __( 'HTML or text code.', 'wpmedia' ),
					'section'           => $section,
					'type'              => 'textarea',
					'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
					'description'       => __( 'Please insert your text for notification here, this will marquee your text before top navigation', 'wpmedia' ),
				);

				$options[ $gmrprefix . '_textmarquee' ] = array(
					'id'          => $gmrprefix . '_textmarquee',
					'label'       => __( 'Marquee Text', 'wpmedia' ),
					'section'     => $section,
					'type'        => 'text',
					'description' => __( 'Add text marquee. Default: Breaking News.', 'wpmedia' ),
				);

				$options[ $gmrprefix . '_category-marque' ] = array(
					'id'       => $gmrprefix . '_category-marque',
					'label'    => __( 'Insert Category If Using Recent Posts', 'wpmedia' ),
					'section'  => $section,
					'type'     => 'category-select',
					'priority' => 70,
					'default'  => '',
				);

				$section    = 'module';
				$sections[] = array(
					'id'       => $section,
					'title'    => __( 'Module Home', 'wpmedia' ),
					'priority' => 50,
					'panel'    => $panel_homepage,
				);

				$options[ $gmrprefix . '_active-module-home' ]   = array(
					'id'      => $gmrprefix . '_active-module-home',
					'label'   => __( 'Disable Module Home', 'wpmedia' ),
					'section' => $section,
					'type'    => 'checkbox',
					'default' => 0,
				);
				$options[ $gmrprefix . '_category-module-home' ] = array(
					'id'      => $gmrprefix . '_category-module-home',
					'label'   => __( 'Insert Category Name', 'wpmedia' ),
					'section' => $section,
					'type'    => 'category-select',
					'default' => '',
				);

			} else {
				$section    = 'HomepageLicense';
				$sections[] = array(
					'id'       => $section,
					'title'    => __( 'Insert License Key', 'wpmedia' ),
					'priority' => 50,
					'panel'    => $panel_homepage,
				);

				$options[ $gmrprefix . '_licensekeyhomepage' ] = array(
					'id'          => $gmrprefix . '_licensekeyhomepage',
					'label'       => __( 'Insert License Key', 'wpmedia' ),
					'section'     => $section,
					'type'        => 'content',
					'priority'    => 60,
					'description' => __( '<a href="plugins.php?page=wpmedia-license" style="font-weight: 700;">Please insert your own license key here</a>.<br /><br /> If you bought from kentooz, you can get license key in your memberarea. <a href="https://member.kentooz.com/softsale/license" target="_blank">https://member.kentooz.com/softsale/license</a>', 'wpmedia' ),
				);

			}
		} else {
			$section    = 'HomepageLicense';
			$sections[] = array(
				'id'       => $section,
				'title'    => __( 'Insert License Key', 'wpmedia' ),
				'priority' => 50,
				'panel'    => $panel_homepage,
			);

			$options[ $gmrprefix . '_licensekeyhomepage' ] = array(
				'id'          => $gmrprefix . '_licensekeyhomepage',
				'label'       => __( 'Insert License Key', 'wpmedia' ),
				'section'     => $section,
				'type'        => 'content',
				'priority'    => 60,
				'description' => __( '<a href="plugins.php?page=wpmedia-license" style="font-weight: 700;">Please insert your own license key here</a>.<br /><br /> If you bought from kentooz, you can get license key in your memberarea. <a href="https://member.kentooz.com/softsale/license" target="_blank">https://member.kentooz.com/softsale/license</a>', 'wpmedia' ),
			);
		}
	}

	/*
	 * Blog Section Options
	 *
	 * @since v.1.0.0
	 */
	$panel_blog = 'panel-blog';
	$panels[]   = array(
		'id'       => $panel_blog,
		'title'    => __( 'Blog', 'wpmedia' ),
		'priority' => '50',
	);

	$section    = 'bloglayout';
	$sections[] = array(
		'id'       => $section,
		'title'    => __( 'Blog Layout', 'wpmedia' ),
		'priority' => 50,
		'panel'    => $panel_blog,
	);

	$options[ $gmrprefix . '_active-sticky-sidebar' ] = array(
		'id'      => $gmrprefix . '_active-sticky-sidebar',
		'label'   => __( 'Disable Sticky In Sidebar', 'wpmedia' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);

	$blogpagination = array(
		'gmr-pagination' => __( 'Number Pagination', 'wpmedia' ),
		'gmr-infinite'   => __( 'Infinite Scroll', 'wpmedia' ),
		'gmr-more'       => __( 'Button Click', 'wpmedia' ),
	);

	$options[ $gmrprefix . '_blog_pagination' ] = array(
		'id'      => $gmrprefix . '_blog_pagination',
		'label'   => __( 'Blog Navigation Type', 'wpmedia' ),
		'section' => $section,
		'type'    => 'radio',
		'choices' => $blogpagination,
		'default' => 'gmr-more',
	);

	$section    = 'blogcontent';
	$sections[] = array(
		'id'       => $section,
		'title'    => __( 'Blog Content', 'wpmedia' ),
		'priority' => 50,
		'panel'    => $panel_blog,
	);

	$options[ $gmrprefix . '_textrecentnews' ] = array(
		'id'          => $gmrprefix . '_textrecentnews',
		'label'       => __( 'Recent news text', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'text',
		'description' => __( 'Add text recent news here. Default:Recent News.', 'wpmedia' ),
	);

	$options[ $gmrprefix . '_active-singlethumb' ] = array(
		'id'      => $gmrprefix . '_active-singlethumb',
		'label'   => __( 'Disable Single Thumbnail', 'wpmedia' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);

	$options[ $gmrprefix . '_active-breadcrumb' ] = array(
		'id'      => $gmrprefix . '_active-breadcrumb',
		'label'   => __( 'Disable Breadcrumbs', 'wpmedia' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);

	$options[ $gmrprefix . '_active-viewsingle' ] = array(
		'id'      => $gmrprefix . '_active-viewsingle',
		'label'   => __( 'Disable view in single', 'wpmedia' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);

	$options[ $gmrprefix . '_active-relpost' ] = array(
		'id'      => $gmrprefix . '_active-relpost',
		'label'   => __( 'Disable Related Posts in single', 'wpmedia' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);
	$options[ $gmrprefix . '_textrelpost' ]    = array(
		'id'          => $gmrprefix . '_textrelpost',
		'label'       => __( 'Text related posts', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'text',
		'description' => __( 'Add text related post here. Default:Related Posts.', 'wpmedia' ),
	);

	$options[ $gmrprefix . '_relpost_number' ] = array(
		'id'          => $gmrprefix . '_relpost_number',
		'label'       => __( 'Number Related Posts', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'number',
		'default'     => '6',
		'description' => __( 'How much number post want to display on related post.', 'wpmedia' ),
		'input_attrs' => array(
			'min'  => 6,
			'max'  => 12,
			'step' => 6,
		),
	);

	$taxonomy = array(
		'gmr-tags'     => __( 'By Tags', 'wpmedia' ),
		'gmr-category' => __( 'By Categories', 'wpmedia' ),
		'gmr-topics'   => __( 'By Topics', 'wpmedia' ),
	);

	$options[ $gmrprefix . '_relpost_taxonomy' ] = array(
		'id'      => $gmrprefix . '_relpost_taxonomy',
		'label'   => __( 'Related Posts Taxonomy', 'wpmedia' ),
		'section' => $section,
		'type'    => 'radio',
		'choices' => $taxonomy,
		'default' => 'gmr-category',
	);

	$options[ $gmrprefix . '_active-relpostsecond' ] = array(
		'id'      => $gmrprefix . '_active-relpostsecond',
		'label'   => __( 'Disable Second Related Posts in single', 'wpmedia' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);

	$options[ $gmrprefix . '_textrelpostsecond' ] = array(
		'id'          => $gmrprefix . '_textrelpostsecond',
		'label'       => __( 'Text second related posts', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'text',
		'description' => __( 'Add text second related post here. Default:Read Also.', 'wpmedia' ),
	);

	$options[ $gmrprefix . '_relpostsecond_number' ] = array(
		'id'          => $gmrprefix . '_relpostsecond_number',
		'label'       => __( 'Number Second Related Posts', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'number',
		'default'     => '6',
		'description' => __( 'How much number post want to display on Second related post.', 'wpmedia' ),
		'input_attrs' => array(
			'min'  => 6,
			'max'  => 12,
			'step' => 6,
		),
	);

	$options[ $gmrprefix . '_relpostsecond_taxonomy' ] = array(
		'id'      => $gmrprefix . '_relpostsecond_taxonomy',
		'label'   => __( 'Second Related Posts Taxonomy', 'wpmedia' ),
		'section' => $section,
		'type'    => 'radio',
		'choices' => $taxonomy,
		'default' => 'gmr-category',
	);

	$comments                           = array(
		'default-comment' => __( 'Default Comment', 'wpmedia' ),
		'fb-comment'      => __( 'Facebook Comment', 'wpmedia' ),
	);
	$options[ $gmrprefix . '_comment' ] = array(
		'id'      => $gmrprefix . '_comment',
		'label'   => __( 'Single Comment', 'wpmedia' ),
		'section' => $section,
		'type'    => 'radio',
		'choices' => $comments,
		'default' => 'default-comment',
	);

	$options[ $gmrprefix . '_fbappid' ] = array(
		'id'          => $gmrprefix . '_fbappid',
		'label'       => __( 'Facebook App ID', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'text',
		'description' => __( 'If you using fb comment, you must insert your own Facebook App ID, if you not insert this options, so you will using Facebook App ID from us.', 'wpmedia' ),
	);

	$options[ $gmrprefix . '_active-excerpt' ] = array(
		'id'      => $gmrprefix . '_active-excerpt',
		'label'   => __( 'Disable excerpt in archive.', 'wpmedia' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 1,
	);

	$options[ $gmrprefix . '_excerpt_number' ] = array(
		'id'          => $gmrprefix . '_excerpt_number',
		'label'       => __( 'Excerpt length', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'number',
		'default'     => '8',
		'description' => __( 'If you choose excerpt, you can change excerpt lenght (default is 30).', 'wpmedia' ),
		'input_attrs' => array(
			'min'  => 10,
			'max'  => 100,
			'step' => 1,
		),
	);

	/*
	 * Banner Section Options
	 *
	 * @since v.1.0.0
	 */
	$panel_banner = 'panel-banner';
	$panels[]     = array(
		'id'          => $panel_banner,
		'title'       => __( 'Banner', 'wpmedia' ),
		'description' => __( 'Insert your banner on very top location, this will display parallax with close button. Size: max-width: 325px and height: 300px.', 'wpmedia' ),
		'priority'    => '50',
	);

	if ( ! empty( $upload_dir['basedir'] ) ) {
		$upldir = $upload_dir['basedir'] . '/' . $hm;

		if ( @file_exists( $upldir ) ) { // phpcs:ignore
			$fl = $upload_dir['basedir'] . '/' . $hm . '/' . $license . '.json';
			if ( @file_exists( $fl ) ) { // phpcs:ignore

				$section    = 'verytopads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Very Top Banner (Mobile Only)', 'wpmedia' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner on very top location, this will display parallax with close button. Size: max-width: 325px and height: 300px.', 'wpmedia' ),
				);

				$options[ $gmrprefix . '_adsverytop' ] = array(
					'id'                => $gmrprefix . '_adsverytop',
					'label'             => __( 'HTML code.', 'wpmedia' ),
					'section'           => $section,
					'type'              => 'textarea',
					'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
					'priority'          => 60,
					'description'       => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too. Please using size max-width: 325px and height: 300px.', 'wpmedia' ),
				);

				$options[ $gmrprefix . '_textadsverytop' ] = array(
					'id'          => $gmrprefix . '_textadsverytop',
					'label'       => __( 'Text Before Close', 'wpmedia' ),
					'section'     => $section,
					'type'        => 'text',
					'priority'    => 70,
					'description' => __( 'Add text before close in very top banner.', 'wpmedia' ),
				);

				$section    = 'topads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Top Banner After Menu', 'wpmedia' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner after menu.', 'wpmedia' ),
				);

				$options[ $gmrprefix . '_adsaftermenu' ] = array(
					'id'                => $gmrprefix . '_adsaftermenu',
					'label'             => __( 'HTML code.', 'wpmedia' ),
					'section'           => $section,
					'type'              => 'textarea',
					'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
					'priority'          => 60,
					'description'       => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'wpmedia' ),
				);

				$section    = 'betweenpostads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Banner Between Posts', 'wpmedia' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner between post in archive page.', 'wpmedia' ),
				);

				$options[ $gmrprefix . '_adsbetweenpost' ] = array(
					'id'                => $gmrprefix . '_adsbetweenpost',
					'label'             => __( 'HTML code.', 'wpmedia' ),
					'section'           => $section,
					'type'              => 'textarea',
					'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
					'priority'          => 60,
					'description'       => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'wpmedia' ),
				);

				$afterpostlocation                                 = array(
					'first'  => __( 'After First Post', 'wpmedia' ),
					'second' => __( 'After Second Post', 'wpmedia' ),
					'third'  => __( 'After Third Post', 'wpmedia' ),
					'fourth' => __( 'After Fourth Post', 'wpmedia' ),
				);
				$options[ $gmrprefix . '_adsbetweenpostposition' ] = array(
					'id'      => $gmrprefix . '_adsbetweenpostposition',
					'label'   => __( 'Banner Position', 'wpmedia' ),
					'section' => $section,
					'type'    => 'radio',
					'choices' => $afterpostlocation,
					'default' => 'third',
				);

				$section    = 'beforecontentads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Banner Before Content', 'wpmedia' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner before single content.', 'wpmedia' ),
				);

				$options[ $gmrprefix . '_adsbeforecontent' ] = array(
					'id'                => $gmrprefix . '_adsbeforecontent',
					'label'             => __( 'HTML code.', 'wpmedia' ),
					'section'           => $section,
					'type'              => 'textarea',
					'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
					'priority'          => 60,
					'description'       => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'wpmedia' ),
				);

				$locationbanner                                      = array(
					'default'    => __( 'Default', 'wpmedia' ),
					'floatleft'  => __( 'Float Left', 'wpmedia' ),
					'floatright' => __( 'Float Right', 'wpmedia' ),
					'center'     => __( 'Center', 'wpmedia' ),
				);
				$options[ $gmrprefix . '_adsbeforecontentposition' ] = array(
					'id'      => $gmrprefix . '_adsbeforecontentposition',
					'label'   => __( 'Banner Position', 'wpmedia' ),
					'section' => $section,
					'type'    => 'radio',
					'choices' => $locationbanner,
					'default' => 'default',
				);

				$section    = 'insidecontentads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Banner Inside Content', 'wpmedia' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner inside content in single post.', 'wpmedia' ),
				);

				$options[ $gmrprefix . '_adsinsidecontent' ] = array(
					'id'                => $gmrprefix . '_adsinsidecontent',
					'label'             => __( 'HTML code.', 'wpmedia' ),
					'section'           => $section,
					'type'              => 'textarea',
					'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
					'priority'          => 60,
					'description'       => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'wpmedia' ),
				);

				$locationbanner                                       = array(
					'left'     => __( 'Left', 'wpmedia' ),
					'right'    => __( 'Right', 'wpmedia' ),
					'center'   => __( 'Center', 'wpmedia' ),
					'parallax' => __( 'Center (Parallax)', 'wpmedia' ),
					'sticky'   => __( 'Center (Sticky)', 'wpmedia' ),
				);
				$options[ $gmrprefix . '_adsinsidecontentposition' ]  = array(
					'id'      => $gmrprefix . '_adsinsidecontentposition',
					'label'   => __( 'Banner Position', 'wpmedia' ),
					'section' => $section,
					'type'    => 'radio',
					'choices' => $locationbanner,
					'default' => 'center',
				);
				$options[ $gmrprefix . '_textadsinsedecontent' ]      = array(
					'id'          => $gmrprefix . '_textadsinsedecontent',
					'label'       => __( 'Text Before Banner', 'wpmedia' ),
					'section'     => $section,
					'type'        => 'text',
					'priority'    => 70,
					'description' => __( 'Add text before banner inside content.', 'wpmedia' ),
				);
				$options[ $gmrprefix . '_textadsafterinsedecontent' ] = array(
					'id'          => $gmrprefix . '_textadsafterinsedecontent',
					'label'       => __( 'Text After Banner', 'wpmedia' ),
					'section'     => $section,
					'type'        => 'text',
					'priority'    => 70,
					'description' => __( 'Add text after banner inside content.', 'wpmedia' ),
				);

				$section    = 'aftercontentads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Banner After Content', 'wpmedia' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner after content in single post.', 'wpmedia' ),
				);

				$options[ $gmrprefix . '_adsaftercontent' ] = array(
					'id'                => $gmrprefix . '_adsaftercontent',
					'label'             => __( 'HTML code.', 'wpmedia' ),
					'section'           => $section,
					'type'              => 'textarea',
					'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
					'priority'          => 60,
					'description'       => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'wpmedia' ),
				);

				$locationbanner                                     = array(
					'left'   => __( 'Left', 'wpmedia' ),
					'right'  => __( 'Right', 'wpmedia' ),
					'center' => __( 'Center', 'wpmedia' ),
				);
				$options[ $gmrprefix . '_adsaftercontentposition' ] = array(
					'id'      => $gmrprefix . '_adsaftercontentposition',
					'label'   => __( 'Banner Position', 'wpmedia' ),
					'section' => $section,
					'type'    => 'radio',
					'choices' => $locationbanner,
					'default' => 'left',
				);

				$section    = 'singlerightbanner';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Banner Sticky Left Content (max width 120px)', 'wpmedia' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner sticky left content in single post. Please using banner 120px x 600px or maximal width 120px.', 'wpmedia' ),
				);

				$options[ $gmrprefix . '_adsstickyrightcontent' ] = array(
					'id'                => $gmrprefix . '_adsstickyrightcontent',
					'label'             => __( 'HTML code.', 'wpmedia' ),
					'section'           => $section,
					'type'              => 'textarea',
					'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
					'priority'          => 60,
					'description'       => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too. This banner only display in desktop.', 'wpmedia' ),
				);

				$section    = 'afterrelpostads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Banner After Related Posts', 'wpmedia' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner after related posts in single post.', 'wpmedia' ),
				);

				$options[ $gmrprefix . '_adsafterrelpost' ] = array(
					'id'                => $gmrprefix . '_adsafterrelpost',
					'label'             => __( 'HTML code.', 'wpmedia' ),
					'section'           => $section,
					'type'              => 'textarea',
					'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
					'priority'          => 60,
					'description'       => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'wpmedia' ),
				);

				$options[ $gmrprefix . '_adsafterrelpostposition' ] = array(
					'id'      => $gmrprefix . '_adsafterrelpostposition',
					'label'   => __( 'Banner Position', 'wpmedia' ),
					'section' => $section,
					'type'    => 'radio',
					'choices' => $locationbanner,
					'default' => 'left',
				);

				$section    = 'floatleftads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Floating Left Ads', 'wpmedia' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner floating left in all page.', 'wpmedia' ),
				);

				$options[ $gmrprefix . '_adsfloatleft' ] = array(
					'id'                => $gmrprefix . '_adsfloatleft',
					'label'             => __( 'HTML code.', 'wpmedia' ),
					'section'           => $section,
					'type'              => 'textarea',
					'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
					'priority'          => 60,
					'description'       => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'wpmedia' ),
				);

				$section    = 'floatrightads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Floating Right Ads', 'wpmedia' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner floating right in all page.', 'wpmedia' ),
				);

				$options[ $gmrprefix . '_adsfloatright' ] = array(
					'id'                => $gmrprefix . '_adsfloatright',
					'label'             => __( 'HTML code.', 'wpmedia' ),
					'section'           => $section,
					'type'              => 'textarea',
					'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
					'priority'          => 60,
					'description'       => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'wpmedia' ),
				);

				$section    = 'floatbottomads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Floating Bottom Ads', 'wpmedia' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner floating bottom in all page.', 'wpmedia' ),
				);

				$options[ $gmrprefix . '_adsfloatbottom' ] = array(
					'id'                => $gmrprefix . '_adsfloatbottom',
					'label'             => __( 'HTML code.', 'wpmedia' ),
					'section'           => $section,
					'type'              => 'textarea',
					'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
					'priority'          => 60,
					'description'       => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'wpmedia' ),
				);

				$section    = 'footerads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Footer Banner Before Widget', 'wpmedia' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert your banner in footer before widget footer or copyright.', 'wpmedia' ),
				);

				$options[ $gmrprefix . '_adsfooter' ] = array(
					'id'                => $gmrprefix . '_adsfooter',
					'label'             => __( 'HTML code.', 'wpmedia' ),
					'section'           => $section,
					'type'              => 'textarea',
					'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
					'priority'          => 60,
					'description'       => __( 'Please insert your html code, adsense code or other ads code here. This option support shortcode too.', 'wpmedia' ),
				);

				$section    = 'popupads';
				$sections[] = array(
					'id'          => $section,
					'title'       => __( 'Popup Banner', 'wpmedia' ),
					'priority'    => 50,
					'panel'       => $panel_banner,
					'description' => __( 'Insert popup banner.', 'wpmedia' ),
				);

				$options[ $gmrprefix . '_adspopup' ] = array(
					'id'                => $gmrprefix . '_adspopup',
					'label'             => __( 'HTML code.', 'wpmedia' ),
					'section'           => $section,
					'type'              => 'textarea',
					'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
					'priority'          => 60,
					'description'       => __( 'Please insert your html code, adsense code or other ads code here. Max width is 325px, and all image will resize to fullwidth (325px), so please using banner with width 325px. This option support shortcode too.', 'wpmedia' ),
				);

			} else {
				$section    = 'BannerLicense';
				$sections[] = array(
					'id'       => $section,
					'title'    => __( 'Insert License Key', 'wpmedia' ),
					'priority' => 50,
					'panel'    => $panel_banner,
				);

				$options[ $gmrprefix . '_licensekeybanner' ] = array(
					'id'          => $gmrprefix . '_licensekeybanner',
					'label'       => __( 'Insert License Key', 'wpmedia' ),
					'section'     => $section,
					'type'        => 'content',
					'priority'    => 60,
					'description' => __( '<a href="plugins.php?page=wpmedia-license" style="font-weight: 700;">Please insert your own license key here</a>.<br /><br /> If you bought from kentooz, you can get license key in your memberarea. <a href="https://member.kentooz.com/softsale/license" target="_blank">https://member.kentooz.com/softsale/license</a>', 'wpmedia' ),
				);

			}
		} else {
			$section    = 'BannerLicense';
			$sections[] = array(
				'id'       => $section,
				'title'    => __( 'Insert License Key', 'wpmedia' ),
				'priority' => 50,
				'panel'    => $panel_banner,
			);

			$options[ $gmrprefix . '_licensekeybanner' ] = array(
				'id'          => $gmrprefix . '_licensekeybanner',
				'label'       => __( 'Insert License Key', 'wpmedia' ),
				'section'     => $section,
				'type'        => 'content',
				'priority'    => 60,
				'description' => __( '<a href="plugins.php?page=wpmedia-license" style="font-weight: 700;">Please insert your own license key here</a>.<br /><br /> If you bought from kentooz, you can get license key in your memberarea. <a href="https://member.kentooz.com/softsale/license" target="_blank">https://member.kentooz.com/softsale/license</a>', 'wpmedia' ),
			);
		}
	}

	/*
	 * Color Section Options
	 *
	 * @since v.1.0.0
	 */
	$panel_color = 'panel-color';
	$panels[]    = array(
		'id'       => $panel_color,
		'title'    => __( 'Color', 'wpmedia' ),
		'priority' => '50',
	);

	// General Colors.
	$section    = 'colors';
	$sections[] = array(
		'id'       => $section,
		'title'    => __( 'General Colors', 'wpmedia' ),
		'panel'    => $panel_color,
		'priority' => 40,
	);

	$options[ $gmrprefix . '_scheme-color' ] = array(
		'id'       => $gmrprefix . '_scheme-color',
		'label'    => __( 'Base Color Scheme', 'wpmedia' ),
		'section'  => $section,
		'type'     => 'color',
		'default'  => $color_scheme,
		'priority' => 40,
	);

	$options[ $gmrprefix . '_second-scheme-color' ] = array(
		'id'       => $gmrprefix . '_second-scheme-color',
		'label'    => __( 'Second Color Scheme', 'wpmedia' ),
		'section'  => $section,
		'type'     => 'color',
		'default'  => $second_color_scheme,
		'priority' => 40,
	);

	$options[ $gmrprefix . '_content-bgcolor' ] = array(
		'id'       => $gmrprefix . '_content-bgcolor',
		'label'    => __( 'Background Color - Content', 'wpmedia' ),
		'section'  => $section,
		'type'     => 'color',
		'default'  => $content_bgcolor,
		'priority' => 40,
	);

	$options[ $gmrprefix . '_content-color' ] = array(
		'id'       => $gmrprefix . '_content-color',
		'label'    => __( 'Font Color - Body', 'wpmedia' ),
		'section'  => $section,
		'type'     => 'color',
		'default'  => $content_color,
		'priority' => 40,
	);

	$options[ $gmrprefix . '_content-greycolor' ] = array(
		'id'       => $gmrprefix . '_content-greycolor',
		'label'    => __( 'Grey Color - Body', 'wpmedia' ),
		'section'  => $section,
		'type'     => 'color',
		'default'  => $content_greycolor,
		'priority' => 40,
	);

	$options[ $gmrprefix . '_content-greybgcolor' ] = array(
		'id'       => $gmrprefix . '_content-greybgcolor',
		'label'    => __( 'Grey Background color - Body', 'wpmedia' ),
		'section'  => $section,
		'type'     => 'color',
		'default'  => $content_greybgcolor,
		'priority' => 40,
	);

	$options[ $gmrprefix . '_content-linkcolor' ] = array(
		'id'       => $gmrprefix . '_content-linkcolor',
		'label'    => __( 'Link Color - Body', 'wpmedia' ),
		'section'  => $section,
		'type'     => 'color',
		'default'  => $content_linkcolor,
		'priority' => 40,
	);

	$options[ $gmrprefix . '_content-linkhovercolor' ] = array(
		'id'       => $gmrprefix . '_content-linkhovercolor',
		'label'    => __( 'Link Hover Color - Body', 'wpmedia' ),
		'section'  => $section,
		'type'     => 'color',
		'default'  => $content_linkhovercolor,
		'priority' => 40,
	);

	$options[ $gmrprefix . '_content-bordercolor' ] = array(
		'id'       => $gmrprefix . '_content-bordercolor',
		'label'    => __( 'Border Color', 'wpmedia' ),
		'section'  => $section,
		'type'     => 'color',
		'default'  => $content_bordercolor,
		'priority' => 40,
	);

	$options[ $gmrprefix . '_button-bgcolor' ] = array(
		'id'      => $gmrprefix . '_button-bgcolor',
		'label'   => __( 'Button Background Color', 'wpmedia' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $button_bgcolor,
	);

	$options[ $gmrprefix . '_button-color' ] = array(
		'id'      => $gmrprefix . '_button-color',
		'label'   => __( 'Button Color', 'wpmedia' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $button_color,
	);

	// Header color.
	$section    = 'header_color';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Header Colors', 'wpmedia' ),
		'priority'    => 40,
		'panel'       => $panel_color,
		'description' => __( 'Allow you customize header color style.', 'wpmedia' ),
	);

	$options[ $gmrprefix . '_header-bgcolor' ] = array(
		'id'      => $gmrprefix . '_header-bgcolor',
		'label'   => __( 'Background Color - Top Navigation', 'wpmedia' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $header_bgcolor,
	);

	$options[ $gmrprefix . '_topnav-color' ] = array(
		'id'      => $gmrprefix . '_topnav-color',
		'label'   => __( 'Color - Top Navigation', 'wpmedia' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $topnav_color,
	);

	$options[ $gmrprefix . '_topnav-linkcolor' ] = array(
		'id'      => $gmrprefix . '_topnav-linkcolor',
		'label'   => __( 'Link Color - Top Navigation', 'wpmedia' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $topnav_link_color,
	);

	$options[ $gmrprefix . '_topnav-linkhovercolor' ] = array(
		'id'      => $gmrprefix . '_topnav-linkhovercolor',
		'label'   => __( 'Link Hover Color - Top Navigation', 'wpmedia' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $topnav_linkhover_color,
	);

	$options[ $gmrprefix . '_mainmenu-bgcolor1' ] = array(
		'id'      => $gmrprefix . '_mainmenu-bgcolor',
		'label'   => __( 'Color Gradient Main Menu', 'wpmedia' ),
		'section' => $section,
		'type'    => 'gradient',
		'default' => wp_json_encode(
			array(
				'color1'    => $menu_bgcolor,
				'color2'    => $menu_secondbgcolor,
				'direction' => 80,
			)
		),
	);

	$options[ $gmrprefix . '_mainmenu-color' ] = array(
		'id'      => $gmrprefix . '_mainmenu-color',
		'label'   => __( 'Text color - Menu', 'wpmedia' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $menu_color,
	);

	$options[ $gmrprefix . '_hovermenu-color' ] = array(
		'id'      => $gmrprefix . '_hovermenu-color',
		'label'   => __( 'Text hover color - Menu', 'wpmedia' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $menu_hovercolor,
	);

	// Footer Colors.
	$section    = 'footer_color';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Footer Colors', 'wpmedia' ),
		'priority'    => 40,
		'panel'       => $panel_color,
		'description' => __( 'Allow you customize footer color style.', 'wpmedia' ),
	);

	$options[ $gmrprefix . '_footer-bgcolor' ] = array(
		'id'      => $gmrprefix . '_footer-bgcolor',
		'label'   => __( 'Background Color - Footer', 'wpmedia' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $footer_bgcolor,
	);

	$options[ $gmrprefix . '_footer-fontcolor' ] = array(
		'id'      => $gmrprefix . '_footer-fontcolor',
		'label'   => __( 'Font Color - Footer', 'wpmedia' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $footer_fontcolor,
	);

	$options[ $gmrprefix . '_footer-linkcolor' ] = array(
		'id'      => $gmrprefix . '_footer-linkcolor',
		'label'   => __( 'Link Color - Footer', 'wpmedia' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $footer_linkcolor,
	);

	$options[ $gmrprefix . '_footer-hoverlinkcolor' ] = array(
		'id'      => $gmrprefix . '_footer-hoverlinkcolor',
		'label'   => __( 'Hover Link Color - Footer', 'wpmedia' ),
		'section' => $section,
		'type'    => 'color',
		'default' => $footer_hoverlinkcolor,
	);

	/*
	 * Footer Section Options
	 *
	 * @since v.1.0.0
	 */
	$panel_footer = 'panel-footer';
	$panels[]     = array(
		'id'       => $panel_footer,
		'title'    => __( 'Footer', 'wpmedia' ),
		'priority' => '50',
	);

	$section    = 'widget_section';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Widgets Footer', 'wpmedia' ),
		'priority'    => 50,
		'panel'       => $panel_footer,
		'description' => __( 'Footer widget columns.', 'wpmedia' ),
	);

	$columns = array(
		'1col'  => __( '1 col', 'wpmedia' ),
		'2col'  => __( '2 col', 'wpmedia' ),
		'3col'  => __( '3 col(33% 33% 33%)', 'wpmedia' ),
		'3col2' => __( '3 col(50% 25% 25%)', 'wpmedia' ),
		'4col'  => __( '4 col(25% 25% 25% 25%)', 'wpmedia' ),
		'4col2' => __( '4 col(50% 16% 16% 16%)', 'wpmedia' ),
		'6col'  => __( '6 col', 'wpmedia' ),
	);

	$options[ $gmrprefix . '_footer_column' ] = array(
		'id'      => $gmrprefix . '_footer_column',
		'label'   => __( 'Widgets Footer', 'wpmedia' ),
		'section' => $section,
		'type'    => 'radio',
		'choices' => $columns,
		'default' => '4col2',
	);

	$section    = 'social';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Footer Social', 'wpmedia' ),
		'priority'    => 50,
		'panel'       => $panel_footer,
		'description' => __( 'Allow you add social icon.', 'wpmedia' ),
	);

	$options[ $gmrprefix . '_active-rssicon' ] = array(
		'id'      => $gmrprefix . '_active-rssicon',
		'label'   => __( 'Disable RSS icon in social', 'wpmedia' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);

	$options[ $gmrprefix . '_fb_url_icon' ] = array(
		'id'          => $gmrprefix . '_fb_url_icon',
		'label'       => __( 'FB Url', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'wpmedia' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_twitter_url_icon' ] = array(
		'id'          => $gmrprefix . '_twitter_url_icon',
		'label'       => __( 'Twitter Url', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'wpmedia' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_pinterest_url_icon' ] = array(
		'id'          => $gmrprefix . '_pinterest_url_icon',
		'label'       => __( 'Pinterest Url', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'wpmedia' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_wordpress_url_icon' ] = array(
		'id'          => $gmrprefix . '_wordpress_url_icon',
		'label'       => __( 'WordPress Url', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'wpmedia' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_instagram_url_icon' ] = array(
		'id'          => $gmrprefix . '_instagram_url_icon',
		'label'       => __( 'Instagram Url', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'wpmedia' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_threads_url_icon' ] = array(
		'id'          => $gmrprefix . '_threads_url_icon',
		'label'       => __( 'Threads Url', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'wpmedia' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_reddit_url_icon' ] = array(
		'id'          => $gmrprefix . '_reddit_url_icon',
		'label'       => __( 'Reddit Url', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'wpmedia' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_linkedin_url_icon' ] = array(
		'id'          => $gmrprefix . '_linkedin_url_icon',
		'label'       => __( 'Linkedin Url', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'wpmedia' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_youtube_url_icon' ] = array(
		'id'          => $gmrprefix . '_youtube_url_icon',
		'label'       => __( 'Youtube Url', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'wpmedia' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_twitch_url_icon' ] = array(
		'id'          => $gmrprefix . '_twitch_url_icon',
		'label'       => __( 'Twitch Url', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'wpmedia' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_spotify_url_icon' ] = array(
		'id'          => $gmrprefix . '_spotify_url_icon',
		'label'       => __( 'Spotify Url', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'wpmedia' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_whatsapp_url_icon' ] = array(
		'id'          => $gmrprefix . '_whatsapp_url_icon',
		'label'       => __( 'WhatsApp URL', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'wpmedia' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_tiktok_url_icon' ] = array(
		'id'          => $gmrprefix . '_tiktok_url_icon',
		'label'       => __( 'TikTok URL', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'wpmedia' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_telegram_url_icon' ] = array(
		'id'          => $gmrprefix . '_telegram_url_icon',
		'label'       => __( 'Telegram URL', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'wpmedia' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_soundcloud_url_icon' ] = array(
		'id'          => $gmrprefix . '_soundcloud_url_icon',
		'label'       => __( 'Soundcloud URL', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'wpmedia' ),
		'priority'    => 90,
	);

	$options[ $gmrprefix . '_dailymotion_url_icon' ] = array(
		'id'          => $gmrprefix . '_dailymotion_url_icon',
		'label'       => __( 'Dailymotion URL', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'url',
		'description' => __( 'Fill using http:// or https://', 'wpmedia' ),
		'priority'    => 90,
	);

	$section    = 'copyright_section';
	$sections[] = array(
		'id'       => $section,
		'title'    => __( 'Copyright', 'wpmedia' ),
		'priority' => 60,
		'panel'    => $panel_footer,
	);

	if ( ! empty( $upload_dir['basedir'] ) ) {
		$upldir = $upload_dir['basedir'] . '/' . $hm;

		if ( @file_exists( $upldir ) ) { // phpcs:ignore
			$fl = $upload_dir['basedir'] . '/' . $hm . '/' . $license . '.json';
			if ( @file_exists( $fl ) ) { // phpcs:ignore
				$options[ $gmrprefix . '_copyright' ] = array(
					'id'          => $gmrprefix . '_copyright',
					'label'       => __( 'Footer Copyright.', 'wpmedia' ),
					'section'     => $section,
					'type'        => 'textarea',
					'priority'    => 60,
					'description' => __( 'Display your own copyright text in footer.', 'wpmedia' ),
				);
			} else {
				$options[ $gmrprefix . '_copyright' ] = array(
					'id'          => $gmrprefix . '_copyright',
					'label'       => __( 'Insert License Key', 'wpmedia' ),
					'section'     => $section,
					'type'        => 'content',
					'priority'    => 60,
					'description' => __( '<a href="plugins.php?page=wpmedia-license" style="font-weight: 700;">Please insert your own license key here</a>.<br /><br /> If you bought from kentooz, you can get license key in your memberarea. <a href="https://member.kentooz.com/softsale/license" target="_blank">https://member.kentooz.com/softsale/license</a>', 'wpmedia' ),
				);
			}
		} else {
			$options[ $gmrprefix . '_copyright' ] = array(
				'id'          => $gmrprefix . '_copyright',
				'label'       => __( 'Insert License Key', 'wpmedia' ),
				'section'     => $section,
				'type'        => 'content',
				'priority'    => 60,
				'description' => __( '<a href="plugins.php?page=wpmedia-license" style="font-weight: 700;">Please insert your own license key here</a>.<br /><br /> If you bought from kentooz, you can get license key in your memberarea. <a href="https://member.kentooz.com/softsale/license" target="_blank">https://member.kentooz.com/softsale/license</a>', 'wpmedia' ),
			);
		}
	}

	/*
	 * Call if only woocommerce actived
	 *
	 * @since v.1.0.0
	 */
	if ( class_exists( 'WooCommerce' ) ) {

		$panel_woo = 'woocommerce';
		$panels[]  = array(
			'id'       => $panel_woo,
			'title'    => __( 'WooCommerce', 'wpmedia' ),
			'priority' => '200',
		);

		$columns = array(
			'2' => __( '2 Columns', 'wpmedia' ),
			'3' => __( '3 Columns', 'wpmedia' ),
			'4' => __( '4 Columns', 'wpmedia' ),
			'5' => __( '5 Columns', 'wpmedia' ),
			'6' => __( '6 Columns', 'wpmedia' ),
		);

		$options[ $gmrprefix . '_wc_related_column' ] = array(
			'id'          => $gmrprefix . '_wc_related_column',
			'label'       => __( 'Related Columns', 'wpmedia' ),
			'description' => __( 'How many products should be shown per row?', 'wpmedia' ),
			'section'     => 'woocommerce_product_catalog',
			'type'        => 'select',
			'choices'     => $columns,
			'default'     => '3',
		);

		// Woocommerce options.
		$section    = 'woocommerce_layout';
		$sections[] = array(
			'id'       => $section,
			'title'    => __( 'Theme Settings', 'wpmedia' ),
			'panel'    => $panel_woo,
			'priority' => 100,
		);

		$options[ $gmrprefix . '_active-cartbutton' ] = array(
			'id'      => $gmrprefix . '_active-cartbutton',
			'label'   => __( 'Remove cart button from header.', 'wpmedia' ),
			'section' => $section,
			'type'    => 'checkbox',
			'default' => 0,
		);

		$options[ $gmrprefix . '_active-loginmenu' ] = array(
			'id'      => $gmrprefix . '_active-loginmenu',
			'label'   => __( 'Remove login button from menu.', 'wpmedia' ),
			'section' => $section,
			'type'    => 'checkbox',
			'default' => 0,
		);

		/*
		 * Woocommerce Color
		 */
		$section    = 'woocommerce_color';
		$sections[] = array(
			'id'          => $section,
			'title'       => __( 'Woocommerce Color', 'wpmedia' ),
			'priority'    => 120,
			'panel'       => $panel_woo,
			'description' => __( 'Allow you customize custom color woocommerce.', 'wpmedia' ),
		);

		$options[ $gmrprefix . '_price-color' ] = array(
			'id'      => $gmrprefix . '_price-color',
			'label'   => __( 'Price Color', 'wpmedia' ),
			'section' => $section,
			'type'    => 'color',
			'default' => $price_color,
		);

		$options[ $gmrprefix . '_badge-color' ] = array(
			'id'      => $gmrprefix . '_badge-color',
			'label'   => __( 'Badge Text Color', 'wpmedia' ),
			'section' => $section,
			'type'    => 'color',
			'default' => $badge_color,
		);

		$options[ $gmrprefix . '_badge-bgcolor' ] = array(
			'id'      => $gmrprefix . '_badge-bgcolor',
			'label'   => __( 'Badge Background Color', 'wpmedia' ),
			'section' => $section,
			'type'    => 'color',
			'default' => $badge_bgcolor,
		);

		$options[ $gmrprefix . '_altbutton-color' ] = array(
			'id'      => $gmrprefix . '_altbutton-color',
			'label'   => __( 'Second Button Color', 'wpmedia' ),
			'section' => $section,
			'type'    => 'color',
			'default' => $altbutton_color,
		);

		$options[ $gmrprefix . '_altbutton-bgcolor' ] = array(
			'id'      => $gmrprefix . '_altbutton-bgcolor',
			'label'   => __( 'Second Button Background Color', 'wpmedia' ),
			'section' => $section,
			'type'    => 'color',
			'default' => $altbutton_bgcolor,
		);

	}

	/*
	 * Call AMP exist
	 *
	 * @since v.1.0.0
	 */
	if ( function_exists( 'is_amp_endpoint' ) ) {
		$panel_amp = 'amppanel';
		$panels[]  = array(
			'id'       => $panel_amp,
			'title'    => __( 'AMP', 'wpmedia' ),
			'priority' => '50',
		);

		$section    = 'head_script_amp';
		$sections[] = array(
			'id'          => $section,
			'title'       => __( 'Head Script (AMP)', 'wpmedia' ),
			'priority'    => 50,
			'panel'       => $panel_amp,
			'description' => __( 'You can insert amp page level adsense here or other amp script. Learn more here: https://amp.dev/documentation/components/amp-ad/. These scripts will be printed in the &lt;head&gt;&lt;/head&gt; section.', 'wpmedia' ),
		);

		$options[ $gmrprefix . '_head_script_amp' ] = array(
			'id'                => $gmrprefix . '_head_script_amp',
			'label'             => __( 'Ads code.', 'wpmedia' ),
			'section'           => $section,
			'type'              => 'textarea',
			'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
			'priority'          => 60,
		);

		$section    = 'footer_script_amp';
		$sections[] = array(
			'id'          => $section,
			'title'       => __( 'Footer Script (AMP)', 'wpmedia' ),
			'priority'    => 50,
			'panel'       => $panel_amp,
			'description' => __( 'You can insert amp script here. These scripts will be printed before &lt;/body&gt; in amp page.', 'wpmedia' ),
		);

		$options[ $gmrprefix . '_footer_script_amp' ] = array(
			'id'                => $gmrprefix . '_footer_script_amp',
			'label'             => __( 'AMP code.', 'wpmedia' ),
			'section'           => $section,
			'type'              => 'textarea',
			'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
			'priority'          => 60,
		);

		$section    = 'topadsamp';
		$sections[] = array(
			'id'          => $section,
			'title'       => __( 'Top Banner After Menu (AMP)', 'wpmedia' ),
			'priority'    => 50,
			'panel'       => $panel_amp,
			'description' => __( 'Display amp ads after menu. Learn more here: https://amp.dev/documentation/components/amp-ad/', 'wpmedia' ),
		);

		$options[ $gmrprefix . '_adsaftermenu_amp' ] = array(
			'id'                => $gmrprefix . '_adsaftermenu_amp',
			'label'             => __( 'Ads code.', 'wpmedia' ),
			'section'           => $section,
			'type'              => 'textarea',
			'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
			'priority'          => 60,
		);

		$section    = 'betweenpostadsamp';
		$sections[] = array(
			'id'          => $section,
			'title'       => __( 'Banner Between Posts (AMP)', 'wpmedia' ),
			'priority'    => 50,
			'panel'       => $panel_amp,
			'description' => __( 'Display amp ads between post in index and archive page. Learn more here: https://amp.dev/documentation/components/amp-ad/.', 'wpmedia' ),
		);

		$options[ $gmrprefix . '_adsbetweenpost_amp' ] = array(
			'id'                => $gmrprefix . '_adsbetweenpost_amp',
			'label'             => __( 'Ads code.', 'wpmedia' ),
			'section'           => $section,
			'type'              => 'textarea',
			'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
			'priority'          => 60,
		);

		$afterpostlocationamp                                  = array(
			'first'  => __( 'After First Post', 'wpmedia' ),
			'second' => __( 'After Second Post', 'wpmedia' ),
			'third'  => __( 'After Third Post', 'wpmedia' ),
			'fourth' => __( 'After Fourth Post', 'wpmedia' ),
		);
		$options[ $gmrprefix . '_adsbetweenpostposition_amp' ] = array(
			'id'      => $gmrprefix . '_adsbetweenpostposition_amp',
			'label'   => __( 'Banner Position', 'wpmedia' ),
			'section' => $section,
			'type'    => 'radio',
			'choices' => $afterpostlocationamp,
			'default' => 'third',
		);

		$section    = 'beforecontentadsamp';
		$sections[] = array(
			'id'          => $section,
			'title'       => __( 'Banner Before Content (AMP)', 'wpmedia' ),
			'priority'    => 50,
			'panel'       => $panel_amp,
			'description' => __( 'Display amp ads before single content. Learn more here: https://amp.dev/documentation/components/amp-ad/.', 'wpmedia' ),
		);

		$options[ $gmrprefix . '_adsbeforecontent_amp' ] = array(
			'id'                => $gmrprefix . '_adsbeforecontent_amp',
			'label'             => __( 'Ads code.', 'wpmedia' ),
			'section'           => $section,
			'type'              => 'textarea',
			'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
			'priority'          => 60,
		);

		$section    = 'insidecontentadsamp';
		$sections[] = array(
			'id'          => $section,
			'title'       => __( 'Banner Inside Content (AMP)', 'wpmedia' ),
			'priority'    => 50,
			'panel'       => $panel_amp,
			'description' => __( 'Insert your amp banner inside content in single post. Learn more here: https://amp.dev/documentation/components/amp-ad/.', 'wpmedia' ),
		);

		$options[ $gmrprefix . '_adsinsidecontent_amp' ] = array(
			'id'                => $gmrprefix . '_adsinsidecontent_amp',
			'label'             => __( 'Ads code.', 'wpmedia' ),
			'section'           => $section,
			'type'              => 'textarea',
			'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
			'priority'          => 60,
		);

		$locationbanner = array(
			'center'   => __( 'Center', 'wpmedia' ),
			'parallax' => __( 'Center (Parallax)', 'wpmedia' ),
			'sticky'   => __( 'Center (sticky)', 'wpmedia' ),
		);

		$options[ $gmrprefix . '_adsinsidecontentposition_amp' ] = array(
			'id'      => $gmrprefix . '_adsinsidecontentposition_amp',
			'label'   => __( 'Banner Position', 'wpmedia' ),
			'section' => $section,
			'type'    => 'radio',
			'choices' => $locationbanner,
			'default' => 'center',
		);

		$section    = 'aftercontentadsamp';
		$sections[] = array(
			'id'          => $section,
			'title'       => __( 'Banner After Content (AMP)', 'wpmedia' ),
			'priority'    => 50,
			'panel'       => $panel_amp,
			'description' => __( 'Display amp ads after single content. Learn more here: https://amp.dev/documentation/components/amp-ad/.', 'wpmedia' ),
		);

		$options[ $gmrprefix . '_adsaftercontent_amp' ] = array(
			'id'                => $gmrprefix . '_adsaftercontent_amp',
			'label'             => __( 'Ads code.', 'wpmedia' ),
			'section'           => $section,
			'type'              => 'textarea',
			'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
			'priority'          => 60,
		);

		$section    = 'afterrelpostadsamp';
		$sections[] = array(
			'id'          => $section,
			'title'       => __( 'Banner After Related Posts (AMP)', 'wpmedia' ),
			'priority'    => 50,
			'panel'       => $panel_amp,
			'description' => __( 'Display amp ads after related post in single. Learn more here: https://amp.dev/documentation/components/amp-ad/.', 'wpmedia' ),
		);

		$options[ $gmrprefix . '_adsafterrelpost_amp' ] = array(
			'id'                => $gmrprefix . '_adsafterrelpost_amp',
			'label'             => __( 'Ads code.', 'wpmedia' ),
			'section'           => $section,
			'type'              => 'textarea',
			'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
			'priority'          => 60,
		);

		$section    = 'footeradsamp';
		$sections[] = array(
			'id'          => $section,
			'title'       => __( 'Footer Banner Before Widget (AMP)', 'wpmedia' ),
			'priority'    => 50,
			'panel'       => $panel_amp,
			'description' => __( 'Insert your banner in footer before widget footer or copyright. Learn more here: https://amp.dev/documentation/components/amp-ad/.', 'wpmedia' ),
		);

		$options[ $gmrprefix . '_adsfooter_amp' ] = array(
			'id'                => $gmrprefix . '_adsfooter_amp',
			'label'             => __( 'HTML code.', 'wpmedia' ),
			'section'           => $section,
			'type'              => 'textarea',
			'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
			'priority'          => 60,
		);
	}

	/*
	 * Other Section Options
	 *
	 * @since v.1.0.0
	 */
	$panel_other = 'panel-other';
	$panels[]    = array(
		'id'       => $panel_other,
		'title'    => __( 'Other', 'wpmedia' ),
		'priority' => '50',
	);

	$section    = 'head_script';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Head Script', 'wpmedia' ),
		'priority'    => 60,
		'panel'       => $panel_other,
		'description' => __( 'Allow you add script inside &lt;head&gt;&lt;/head&gt;.', 'wpmedia' ),
	);

	$options[ $gmrprefix . '_head_script' ] = array(
		'id'                => $gmrprefix . '_head_script',
		'label'             => __( 'HTML code.', 'wpmedia' ),
		'section'           => $section,
		'type'              => 'textarea',
		'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
		'priority'          => 60,
		'description'       => __( 'Please insert your code here.', 'wpmedia' ),
	);

	$section    = 'footer_script';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Footer Script', 'wpmedia' ),
		'priority'    => 60,
		'panel'       => $panel_other,
		'description' => __( 'Allow you add script before &lt;/body&gt;.', 'wpmedia' ),
	);

	$options[ $gmrprefix . '_footer_script' ] = array(
		'id'                => $gmrprefix . '_footer_script',
		'label'             => __( 'HTML code.', 'wpmedia' ),
		'section'           => $section,
		'type'              => 'textarea',
		'sanitize_callback' => 'customizer_library_sanitize_textareajsallowed',
		'priority'          => 60,
		'description'       => __( 'Please insert your code here.', 'wpmedia' ),
	);

	$section    = 'analytic_script';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Analytic & Pixel', 'wpmedia' ),
		'priority'    => 60,
		'panel'       => $panel_other,
		'description' => __( 'Allow you add google analytic and facebook pixel.', 'wpmedia' ),
	);

	$options[ $gmrprefix . '_analytic' ] = array(
		'id'          => $gmrprefix . '_analytic',
		'label'       => __( 'Google Analytics ID', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'text',
		'description' => __( 'Enter your Google Analytics ID (Ex: UA-XXXXX-X).', 'wpmedia' ),
	);

	$options[ $gmrprefix . '_pixel' ] = array(
		'id'          => $gmrprefix . '_pixel',
		'label'       => __( 'Facebook Pixel ID', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'text',
		'description' => __( 'Enter your Facebook Pixel ID.', 'wpmedia' ),
	);

	$section    = 'other_option';
	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Other Options', 'wpmedia' ),
		'priority'    => 60,
		'panel'       => $panel_other,
		'description' => __( 'Other options.', 'wpmedia' ),
	);

	$options[ $gmrprefix . '_remove-emoji' ] = array(
		'id'      => $gmrprefix . '_remove-emoji',
		'label'   => __( 'Remove emoji script', 'wpmedia' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);

	$options[ $gmrprefix . '_cache_dynamiccss' ] = array(
		'id'      => $gmrprefix . '_cache_dynamiccss',
		'label'   => __( 'Enable cache dynamic css', 'wpmedia' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 1,
	);

	$options[ $gmrprefix . '_active-recentpostjson' ] = array(
		'id'      => $gmrprefix . '_active-recentpostjson',
		'label'   => __( 'Enable Custom Json Recent Post', 'wpmedia' ),
		'section' => $section,
		'type'    => 'checkbox',
		'default' => 0,
	);

	$options[ $gmrprefix . '_api-customjson' ] = array(
		'id'          => $gmrprefix . '_api-customjson',
		'label'       => __( 'Key for custom json', 'wpmedia' ),
		'section'     => $section,
		'type'        => 'text',
		'description' => __( 'Add key for protect your custom json from other user using your json. Just using text and number. Default: No key', 'wpmedia' ),
	);

	// Adds the sections to the $options array.
	$options['sections'] = $sections;
	// Adds the panels to the $options array.
	$options['panels']  = $panels;
	$customizer_library = Customizer_Library::Instance();
	$customizer_library->add_options( $options );
}
add_action( 'init', 'gmr_library_options_customizer' );
