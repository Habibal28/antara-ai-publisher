<?php
/**
 * Get CSS.
 *
 * @package wpmedia
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Idtheme_Css_Utils' ) ) {
	/**
	 * CSS Utilities
	 */
	class Idtheme_Css_Utils {

		/**
		 * An array on instances of this object.
		 *
		 * We use multiple instances because some styles may belong in the <head>,
		 * other styles may belong inside <body>, or secondary styles may even be
		 * in the footer and anywhere in between.
		 *
		 * @static
		 * @access private
		 * @since 1.0
		 * @var array
		 */
		private static $instances = []; // phpcs:ignore WordPress.Arrays.ArrayDeclarationSpacing, Generic.Arrays.DisallowShortArraySyntax

		/**
		 * An array of styles
		 *
		 * Array format:
		 * [
		 *     media-query => [
		 *         element => [
		 *              property => value
		 *         ]
		 *     ]
		 * ]
		 *
		 * @access private
		 * @since 1.0
		 * @var array
		 */
		private $css_array = []; // phpcs:ignore WordPress.Arrays.ArrayDeclarationSpacing, Generic.Arrays.DisallowShortArraySyntax

		/**
		 * Get - or create an instance.
		 *
		 * @static
		 * @access public
		 * @since 1.0
		 * @param string $instance_id The instance ID.
		 * @return CSS                Returns an instance of this class.
		 */
		public static function get_instance( $instance_id = 'global' ) {
			if ( ! isset( self::$instances[ $instance_id ] ) ) {
				self::$instances[ $instance_id ] = new self( $instance_id );
			}
			return self::$instances[ $instance_id ];
		}

		/**
		 * Add a style to the array.
		 * [
		 *     'query'    => '',
		 *     'element'  => '',
		 *     'properties' => '',
		 * ]
		 *
		 * @access public
		 * @since 1.0
		 * @param array $params The parameters we want to add.
		 * @return void
		 */
		public function add_item( $params ) {
			$params = wp_parse_args(
				$params,
				[ // phpcs:ignore WordPress.Arrays.ArrayDeclarationSpacing, Generic.Arrays.DisallowShortArraySyntax
					'query'      => 'global',
					'element'    => '',
					'properties' => '',
				]
			);
			if ( ! isset( $this->css_array[ $params['query'] ] ) ) {
				$this->css_array[ $params['query'] ] = []; // phpcs:ignore WordPress.Arrays.ArrayDeclarationSpacing, Generic.Arrays.DisallowShortArraySyntax
			}
			if ( ! isset( $this->css_array[ $params['query'] ][ $params['element'] ] ) ) {
				$this->css_array[ $params['query'] ][ $params['element'] ] = []; // phpcs:ignore WordPress.Arrays.ArrayDeclarationSpacing, Generic.Arrays.DisallowShortArraySyntax
			}
			$this->css_array[ $params['query'] ][ $params['element'] ] = $params['properties'];
		}

		/**
		 * Get styles from array.
		 * [media-query][element][property][values]
		 *
		 * @static
		 * @access public
		 * @since 1.0
		 *
		 * @return string
		 */
		public function generate() {
			$final_css = '';

			if ( ! is_array( $this->css_array ) || empty( $this->css_array ) ) {
				return '';
			}

			foreach ( $this->css_array as $media_query => $styles ) {

				$stringcss = array();
				foreach ( $styles as $element => $properties ) {
					$css_for_style = '';

					foreach ( $properties as $property ) {
						if ( isset( $property['property'] ) ) {
							// Kondisi false lewati.
							if ( isset( $property['condition'] ) && false === $property['condition'] ) {
								continue;
							}

							if ( isset( $property['value'] ) && ! empty( $property['value'] ) ) {
								$css_for_style .= $property['property'] . ':' . $property['value'] . ';';
							}

							if ( isset( $property['arrayvalue'] ) && is_array( $property['arrayvalue'] ) ) {
								$val = $property['arrayvalue'];

								$left   = ( isset( $val['left'] ) && ! empty( $val['left'] ) ) ? $val['left'] : '0px';
								$right  = ( isset( $val['right'] ) && ! empty( $val['right'] ) ) ? $val['right'] : '0px';
								$top    = ( isset( $val['top'] ) && ! empty( $val['top'] ) ) ? $val['top'] : '0px';
								$bottom = ( isset( $val['bottom'] ) && ! empty( $val['bottom'] ) ) ? $val['bottom'] : '0px';

								$css_for_style .= $property['property'] . ':' . $top . ' ' . $right . ' ' . $bottom . ' ' . $left . ' !important;';
							}

							if ( isset( $property['pattern'] ) && isset( $property['pattern_values'] ) ) {
								$pattern = $property['pattern'];

								foreach ( $property['pattern_values'] as $value_key => $pattern_value ) {
									if ( isset( $pattern_value['value'] ) && ! empty( $pattern_value['value'] ) ) {
										$value = $pattern_value['value'];

										$pattern = preg_replace( '/\b' . $value_key . '\b/', $value, $pattern );
									}
								}

								$css_for_style .= $property['property'] . ':' . $pattern . ';';
							}
						}
					}

					if ( ! empty( $css_for_style ) ) {
						$stringcss[] = $element . '{' . $css_for_style . '}';
					}
				}

				if ( is_array( $stringcss ) && ! empty( $stringcss ) ) {
					$final_css .= ( 'global' !== $media_query ) ? $media_query . '{' : '';
					$final_css .= implode( '', $stringcss );
					$final_css .= ( 'global' !== $media_query ) ? '}' : '';
				}
			}
			return $final_css;
		}

	}
	new Idtheme_Css_Utils();

}
