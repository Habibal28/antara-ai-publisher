<?php
/**
 * Customizer Utility Functions
 *
 * @package Customizer_Library
 */

if ( ! class_exists( 'WP_Customize_Control' ) ) {
	return null;
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 *
 * @since v.1.0.0
 */
function customizer_library_customize_preview_js() {

	$path = str_replace( wp_normalize_path( WP_CONTENT_DIR ), WP_CONTENT_URL, wp_normalize_path( dirname( dirname( __FILE__ ) ) ) );

	wp_enqueue_script( 'customizer_library_customizer', $path . '/js/customizer.js', array( 'customize-preview' ), '1.0.0', true );

}
add_action( 'customize_preview_init', 'customizer_library_customize_preview_js' );

/**
 * Enqueue script for custom customize control.
 */
function customizer_library_enqueue_script_all() {
	$path = str_replace( wp_normalize_path( WP_CONTENT_DIR ), WP_CONTENT_URL, wp_normalize_path( dirname( dirname( __FILE__ ) ) ) );

	wp_enqueue_script( 'wpmedia-select2-js', $path . '/js/select2.full.min.js', array( 'jquery' ), '4.0.13', true );
	wp_enqueue_script( 'wpmedia-custom-controls-js', $path . '/js/customizer-options.js', array( 'jquery', 'wpmedia-select2-js', 'wp-color-picker' ), '1.0', true );
	wp_localize_script(
		'wpmedia-custom-controls-js',
		'gmrobj',
		array(
			'booluri' => apply_filters( 'wpmedia_jsn_url_filter', 'failed' ),
		)
	);
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_style( 'wpmedia-custom-controls-css', $path . '/css/custom.css', array(), '1.1', 'all' );
	wp_enqueue_style( 'wpmedia-select2-css', $path . '/css/select2.min.css', array(), '4.0.13', 'all' );
}
add_action( 'customize_controls_enqueue_scripts', 'customizer_library_enqueue_script_all' );

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @since v.1.0.0
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function customizer_library_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport        = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';
}
add_action( 'customize_register', 'customizer_library_customize_register' );
