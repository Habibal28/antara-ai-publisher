<?php
/**
 * WooCommerce Compatibility File
 *
 * @link https://woocommerce.com/
 *
 * @package wpmedia
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WooCommerce setup function.
 *
 * @link https://docs.woocommerce.com/document/third-party-custom-theme-compatibility/
 * @link https://github.com/woocommerce/woocommerce/wiki/Enabling-product-gallery-features-(zoom,-swipe,-lightbox)
 * @link https://github.com/woocommerce/woocommerce/wiki/Declaring-WooCommerce-support-in-themes
 *
 * @return void
 */
function wpmedia_woocommerce_setup() {
	add_theme_support(
		'woocommerce',
		array(
			'thumbnail_image_width' => 300,
			'single_image_width'    => 300,
			'product_grid'          => array(
				'default_rows'    => 3,
				'min_rows'        => 1,
				'default_columns' => 2,
				'min_columns'     => 1,
				'max_columns'     => 6,
			),
		)
	);
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
}
add_action( 'after_setup_theme', 'wpmedia_woocommerce_setup' );

/**
 * WooCommerce specific scripts & stylesheets.
 *
 * @return void
 */
function wpmedia_woocommerce_scripts() {
	wp_enqueue_style( 'wpmedia-woocommerce-style', get_template_directory_uri() . '/woocommerce.css', array(), WPMEDIA_VERSION );
	wp_style_add_data( 'wpmedia-woocommerce-style', 'rtl', 'replace' );

	$font_path   = WC()->plugin_url() . '/assets/fonts/';
	$inline_font = '@font-face {
			font-family: "star";
			src: url("' . $font_path . 'star.eot");
			src: url("' . $font_path . 'star.eot?#iefix") format("embedded-opentype"),
				url("' . $font_path . 'star.woff") format("woff"),
				url("' . $font_path . 'star.ttf") format("truetype"),
				url("' . $font_path . 'star.svg#star") format("svg");
			font-weight: normal;
			font-style: normal;
		}
		@font-face {
			font-family: "WooCommerce";
			src: url("' . $font_path . 'WooCommerce.eot");
			src: url("' . $font_path . 'WooCommerce.eot?#iefix") format("embedded-opentype"),
				url("' . $font_path . 'WooCommerce.woff") format("woff"),
				url("' . $font_path . 'WooCommerce.ttf") format("truetype"),
				url("' . $font_path . 'WooCommerce.svg#WooCommerce") format("svg");
			font-weight: normal;
			font-style: normal;
		}';

	wp_add_inline_style( 'wpmedia-woocommerce-style', $inline_font );
}
add_action( 'wp_enqueue_scripts', 'wpmedia_woocommerce_scripts' );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function wpmedia_woocommerce_widgets_init() {
	// Sidebar widget areas.
	register_sidebar(
		array(
			'name'          => esc_html__( 'Woocommerce Archive Sidebar', 'wpmedia' ),
			'id'            => 'sidebar-woo',
			'description'   => esc_html__( 'Add widgets here.', 'wpmedia' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);
	register_sidebar(
		array(
			'name'          => esc_html__( 'Woocommerce Single Sidebar', 'wpmedia' ),
			'id'            => 'sidebar-woo-single',
			'description'   => esc_html__( 'Add widgets here.', 'wpmedia' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);
}
add_action( 'widgets_init', 'wpmedia_woocommerce_widgets_init', 15 );

/**
 * Disable the default WooCommerce stylesheet.
 *
 * Removing the default WooCommerce stylesheet and enqueing your own will
 * protect you during WooCommerce core updates.
 *
 * @param string $enqueue_styles Enqueue style.
 * @link https://docs.woocommerce.com/document/disable-the-default-stylesheet/
 */
function wpmedia_dequeue_styles( $enqueue_styles ) {
	unset( $enqueue_styles['woocommerce-general'] );
	unset( $enqueue_styles['woocommerce-layout'] ); // Remove the layout.
	unset( $enqueue_styles['woocommerce-smallscreen'] ); // Remove the smallscreen optimisation.
	return $enqueue_styles;
}
add_filter( 'woocommerce_enqueue_styles', 'wpmedia_dequeue_styles' );

/**
 * Add 'woocommerce-active' class to the body tag.
 *
 * @param  array $classes CSS classes applied to the body tag.
 * @return array $classes modified to include 'woocommerce-active' class.
 */
function wpmedia_woocommerce_active_body_class( $classes ) {
	$classes[] = 'woocommerce-active';

	return $classes;
}
add_filter( 'body_class', 'wpmedia_woocommerce_active_body_class' );

/**
 * Related Products Args.
 *
 * @param array $args related products args.
 * @return array $args related products args.
 */
function wpmedia_woocommerce_related_products_args( $args ) {
	$columns = get_theme_mod( 'gmr_wc_related_column', 3 );
	$columns = absint( $columns );

	$defaults = array(
		'posts_per_page' => $columns,
		'columns'        => $columns,
	);

	$args = wp_parse_args( $defaults, $args );

	return $args;
}
add_filter( 'woocommerce_output_related_products_args', 'wpmedia_woocommerce_related_products_args' );

// remove sidebar.
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );

/**
 * Remove default WooCommerce wrapper.
 */
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );

if ( ! function_exists( 'wpmedia_woocommerce_wrapper_before' ) ) {
	/**
	 * Before Content.
	 *
	 * Wraps all WooCommerce content in wrappers which match the theme markup.
	 *
	 * @return void
	 */
	function wpmedia_woocommerce_wrapper_before() {
		if ( is_singular( 'product' ) ) {
			if ( is_active_sidebar( 'sidebar-woo-single' ) ) {
				echo '<main id="primary" class="site-main col-md-8">';
			} else {
				echo '<main id="primary" class="site-main col-md-12">';
			}
		} else {
			if ( is_active_sidebar( 'sidebar-woo' ) ) {
				echo '<main id="primary" class="site-main col-md-8">';
			} else {
				echo '<main id="primary" class="site-main col-md-12">';
			}
		}
	}
}
add_action( 'woocommerce_before_main_content', 'wpmedia_woocommerce_wrapper_before' );

if ( ! function_exists( 'wpmedia_woocommerce_wrapper_after' ) ) {
	/**
	 * After Content.
	 *
	 * Closes the wrapping divs.
	 *
	 * @return void
	 */
	function wpmedia_woocommerce_wrapper_after() {
		if ( is_singular( 'product' ) ) {
			if ( is_active_sidebar( 'sidebar-woo-single' ) ) {
				echo '</main>';
				get_sidebar( 'shop-single' );
			} else {
				echo '</main>';
			}
		} else {
			if ( is_active_sidebar( 'sidebar-woo' ) ) {
				echo '</main>';
				get_sidebar( 'shop' );
			} else {
				echo '</main>';
			}
		}
	}
}
add_action( 'woocommerce_after_main_content', 'wpmedia_woocommerce_wrapper_after' );

/**
 * Sample implementation of the WooCommerce Mini Cart.
 *
 * You can add the WooCommerce Mini Cart to header.php like so ...
 *
	<?php
		if ( function_exists( 'wpmedia_woocommerce_header_cart' ) ) {
			wpmedia_woocommerce_header_cart();
		}
	?>
 */

if ( ! function_exists( 'wpmedia_woocommerce_cart_link_fragment' ) ) {
	/**
	 * Cart Fragments.
	 *
	 * Ensure cart contents update when products are added to the cart via AJAX.
	 *
	 * @param array $fragments Fragments to refresh via AJAX.
	 * @return array Fragments to refresh via AJAX.
	 */
	function wpmedia_woocommerce_cart_link_fragment( $fragments ) {
		ob_start();
		wpmedia_woocommerce_cart_count();
		$fragments['span.update-carts'] = ob_get_clean();

		return $fragments;
	}
}
add_filter( 'woocommerce_add_to_cart_fragments', 'wpmedia_woocommerce_cart_link_fragment' );

if ( ! function_exists( 'wpmedia_woocommerce_cart_count' ) ) {
	/**
	 * Cart Link.
	 *
	 * Displayed a link to the cart including the number of items present and the cart total.
	 *
	 * @return void
	 */
	function wpmedia_woocommerce_cart_count() {
		?>
		<?php
		$item_count_text = sprintf(
			WC()->cart->get_cart_contents_count()
		);
		?>
		<span class="count update-carts"><?php echo esc_html( $item_count_text ); ?></span>
		<?php
	}
}

if ( ! function_exists( 'wpmedia_woocommerce_header_cart' ) ) {
	/**
	 * Display Header Cart.
	 *
	 * @return void
	 */
	function wpmedia_woocommerce_header_cart() {
		if ( wpmedia_is_amp() ) {
			return;
		}
		$opsicart = get_theme_mod( 'gmr_active-cartbutton', 0 );
		if ( 0 === $opsicart ) :
			?>
			<div class="wrap-woo-headermenu gmr-menugrid-btn gmrclick-container">
				<a id="menugrid-button" class="topnav-button gmrbtnclick" href="#" rel="nofollow">
					<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M15.55 13c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.37-.66-.11-1.48-.87-1.48H5.21l-.94-2H1v2h2l3.6 7.59-1.35 2.44C4.52 15.37 5.48 17 7 17h12v-2H7l1.1-2h7.45zM6.16 6h12.15l-2.76 5H8.53L6.16 6zM7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zm10 0c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z"/></svg>
					<?php wpmedia_woocommerce_cart_count(); ?>
				</a>
				<div id="dropdown-container" class="gmr-woo-dropdown gmr-dropdown">
					<?php
					$instance = array(
						'title' => '',
					);

					the_widget( 'WC_Widget_Cart', $instance );
					?>
				</div>
			</div>
			<?php
		endif;
	}
}
add_action( 'wpmedia_topnav_icon', 'wpmedia_woocommerce_header_cart', 15 );

if ( ! function_exists( 'wpmedia_filter_woocommerce_widget_cart_is_hidden' ) ) :
	/**
	 * This function display cart in all page, default is hidden in cart and checkout page
	 *
	 * @since 1.0.0
	 * @param boolean $is_cart Cart true or false.
	 *
	 * @return boolean
	 */
	function wpmedia_filter_woocommerce_widget_cart_is_hidden( $is_cart ) {
		return false;
	};
endif; // endif wpmedia_filter_woocommerce_widget_cart_is_hidden.
add_filter( 'woocommerce_widget_cart_is_hidden', 'wpmedia_filter_woocommerce_widget_cart_is_hidden', 10, 1 );

// Remove woocommerce default Breadcrumb.
remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );

/**
 * Change and remove default woocommerce pagination
 *
 * @since 1.0.0
 *
 * @return void
 */
function woocommerce_pagination() {
	the_posts_pagination(
		array(
			'mid_size'  => 1,
			'prev_text' => '&laquo; ' . esc_html__( 'Back', 'wpmedia' ),
			'next_text' => esc_html__( 'Next', 'wpmedia' ) . ' &raquo;',
		)
	);
}
remove_action( 'woocommerce_pagination', 'woocommerce_catalog_ordering', 20 );
remove_action( 'woocommerce_pagination', 'woocommerce_pagination', 10 );
remove_action( 'woocommerce_pagination', 'woocommerceframework_pagination', 10 );
remove_action( 'woocommerce_pagination', 'woocommerce_pagination_wrap_open', 5 );
remove_action( 'woocommerce_pagination', 'woocommerce_pagination_wrap_close', 25 );
add_action( 'woocommerce_pagination', 'woocommerce_pagination', 10 );

remove_action( 'wp_footer', 'woocommerce_demo_store' );
if ( ! function_exists( 'wpmedia_woocommerce_demo_store' ) ) {
	/**
	 * Adds a demo store banner to the site if enabled.
	 */
	function wpmedia_woocommerce_demo_store() {
		if ( ! is_store_notice_showing() ) {
			return;
		}
		$url_notice = get_theme_mod( 'gmr_storenotice_url' );
		if ( ! empty( $url_notice ) ) {
			$text_btn = get_theme_mod( 'gmr_storenotice_btntext' );
			if ( ! empty( $text_btn ) ) {
				$btntext = $text_btn;
			} else {
				$btntext = __( 'Click Here!', 'wpmedia' );
			}
			$buttonnotice = '<a href="' . esc_url( $url_notice ) . '" class="readmore-woonotice">' . esc_attr( $btntext ) . '</a>';
		} else {
			$buttonnotice = '';
		}
		$notice = get_option( 'woocommerce_demo_store_notice' ) . $buttonnotice;
		if ( empty( $notice ) ) {
			$notice = __( 'This is a demo store for testing purposes &mdash; no orders shall be fulfilled.', 'wpmedia' );
		}
		echo apply_filters( 'woocommerce_demo_store', '<p class="woocommerce-store-notice demo_store">' . wp_kses_post( $notice ) . ' <a href="#" class="woocommerce-store-notice__dismiss-link"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="vertical-align: -0.125em;-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveAspectRatio="xMidYMid meet" viewBox="0 0 32 32"><path d="M16 2C8.2 2 2 8.2 2 16s6.2 14 14 14s14-6.2 14-14S23.8 2 16 2zm0 26C9.4 28 4 22.6 4 16S9.4 4 16 4s12 5.4 12 12s-5.4 12-12 12z" fill="#888888"/><path d="M21.4 23L16 17.6L10.6 23L9 21.4l5.4-5.4L9 10.6L10.6 9l5.4 5.4L21.4 9l1.6 1.6l-5.4 5.4l5.4 5.4z" fill="#888888"/><rect x="0" y="0" width="32" height="32" fill="rgba(0, 0, 0, 0)" /></svg></a></p>', $notice ); // phpcs:ignore WordPress.Security
	}
}
add_action( 'wpmedia_woocommerce_demo_store', 'wpmedia_woocommerce_demo_store' );

if ( ! function_exists( 'wpmedia_nav_custom_menu_login' ) ) :
	/**
	 * This function add close button in mobile menu.
	 *
	 * @since 1.0.0
	 *
	 * @param string $items Item Menu.
	 * @param array  $args Argument Menu.
	 * @param bool   $ajax default false.
	 * @return string
	 */
	function wpmedia_nav_custom_menu_login( $items, $args, $ajax = false ) {
		$opsilogin = get_theme_mod( 'gmr_active-loginmenu', 0 );
		// Woocommerce Menu.
		if ( ( isset( $ajax ) && $ajax ) || ( property_exists( $args, 'theme_location' ) && 'menu-1' === $args->theme_location ) && 0 === $opsilogin ) {
			global $current_user;
			$css_class           = 'menu-item menu-item-type-cart menu-item-type-woocommerce-cart gmr-menu-woocommerce pull-right';
			$css_class_has_child = 'menu-item-has-children menu-item menu-item-type-cart menu-item-type-woocommerce-cart gmr-menu-woocommerce pull-right';
			// Name to display.
			$current_user = wp_get_current_user(); //phpcs:ignore
			if ( is_user_logged_in() ) {
				$items .= '<li class="' . esc_attr( $css_class_has_child ) . '">';
				$items .= '<a class="gmr-menu-account" href=" ' . esc_url( get_permalink( wc_get_page_id( 'myaccount' ) ) ) . ' ">';
				if ( $current_user->display_name ) {
					$items .= __( 'Hi', 'wpmedia' ) . ', ' . esc_html( $current_user->display_name );
				} else {
					$items .= __( 'Welcome!', 'wpmedia' );
				}
				$items .= '</a>';
				$items .= '<ul class="sub-menu gmr-submenu-account">';
				$items .= '<li><a href="' . esc_url( get_permalink( wc_get_page_id( 'myaccount' ) ) ) . '" title="' . esc_html__( 'My Account', 'wpmedia' ) . '">' . esc_html__( 'My Account', 'wpmedia' ) . '</a></li>';
				$items .= '<li><a href="' . esc_url( wc_get_endpoint_url( 'orders', '', get_permalink( wc_get_page_id( 'myaccount' ) ) ) ) . '" title="' . esc_html__( 'Orders', 'wpmedia' ) . '">' . esc_html__( 'Orders', 'wpmedia' ) . '</a></li>';
				$items .= '<li><a href="' . esc_url( wc_get_endpoint_url( 'edit-address', '', get_permalink( wc_get_page_id( 'myaccount' ) ) ) ) . '" title="' . esc_html__( 'Addresses', 'wpmedia' ) . '">' . esc_html__( 'Addresses', 'wpmedia' ) . '</a></li>';
				if ( class_exists( 'YITH_WCWL' ) ) {
					$items .= '<li><a href="' . esc_url( YITH_WCWL()->get_wishlist_url() ) . '" title="' . esc_html__( 'Wishlist', 'wpmedia' ) . '">' . esc_html__( 'Wishlist', 'wpmedia' ) . '</a></li>';
				}
				$items .= '<li><a href="' . esc_url( wp_logout_url( get_permalink( wc_get_page_id( 'myaccount' ) ) ) ) . '" title="' . esc_html__( 'Log out', 'wpmedia' ) . '">' . esc_html__( 'Log out', 'wpmedia' ) . '</a></li>';
				$items .= '</ul>';
				$items .= '</li>';
			} else {
				$items .= '<li class="' . esc_attr( $css_class ) . '">';
				$items .= '<a class="gmr-menu-account" href="' . esc_url( get_permalink( wc_get_page_id( 'myaccount' ) ) ) . '" title="' . esc_html__( 'Register or Login', 'wpmedia' ) . '">';
				$items .= esc_html__( 'Register - Login', 'wpmedia' );
				$items .= '</a>';
				$items .= '</li>';
			}
		}
		return apply_filters( 'gmr_nav_close_mobile_filter', $items );
	}
endif; /* endif wpmedia_nav_custom_menu_login */
add_filter( 'wp_nav_menu_items', 'wpmedia_nav_custom_menu_login', 10, 2 );
