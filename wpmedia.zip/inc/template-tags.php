<?php
/**
 * Custom template tags for this theme
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package wpmedia
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'wpmedia_posted_on' ) ) :
	/**
	 * Prints HTML with meta information for the current post-date/time.
	 *
	 * @param boolean $echo Echo.
	 */
	function wpmedia_posted_on( $echo = true ) {
		$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
		if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
			$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
		}

		$time_string = sprintf(
			$time_string,
			esc_attr( get_the_date( DATE_W3C ) ),
			esc_html( get_the_date() ),
			esc_attr( get_the_modified_date( DATE_W3C ) ),
			esc_html( get_the_modified_date() )
		);

		$posted_on = sprintf(
			'%s',
			$time_string
		);
		if ( false === $echo ) {
			return '<span class="posted-on">' . $posted_on . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} else {
			echo '<span class="posted-on">' . $posted_on . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

	}
endif;

if ( ! function_exists( 'wpmedia_category' ) ) :
	/**
	 * Prints HTML with meta information for the current category.
	 *
	 * @since 1.0.0
	 *
	 * @param integer $postid Post ID.
	 * @param boolean $echo Echo.
	 * @param boolean $multiple Multiple.
	 */
	function wpmedia_category( $postid = '', $echo = true, $multiple = false ) {
		$categories = get_the_category( ! empty( $postid ) ? absint( $postid ) : '' );

		$content = '';
		if ( ! empty( $categories ) ) {
			$content .= '<span class="cat-links-content">';
			if ( true === $multiple ) {
				foreach ( $categories as $category ) {
					$color = get_term_meta( $category->term_id, '_idt_category_color', true );

					$addcolor = '';
					if ( ! empty( $color ) ) {
						$addcolor = ' style="background:' . esc_attr( $color ) . ';"';
					}
					/* translators: %s: category name */
					$content .= '<a href="' . esc_url( get_category_link( $category->term_id ) ) . '" title="' . esc_attr( sprintf( esc_html__( 'View all posts in %s', 'wpmedia' ), $category->name ) ) . '"' . wp_kses_post( $addcolor ) . '>' . esc_html( $category->cat_name ) . '</a>';
				}
			} else {
				if ( $categories[0] ) {
					$color = get_term_meta( $categories[0]->term_id, '_idt_category_color', true );

					$addcolor = '';
					if ( ! empty( $color ) ) {
						$addcolor = ' style="background:' . esc_attr( $color ) . ';"';
					}
					/* translators: %s: category name */
					$content .= '<a href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '" title="' . esc_attr( sprintf( esc_html__( 'View all posts in %s', 'wpmedia' ), $categories[0]->name ) ) . '"' . wp_kses_post( $addcolor ) . '>' . esc_html( $categories[0]->cat_name ) . '</a>';
				}
			}
			$content .= '</span>';
		}
		if ( false === $echo ) {
			return $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} else {
			echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}
endif;

if ( ! function_exists( 'wpmedia_posted_by' ) ) :
	/**
	 * Prints HTML with meta information for the current author.
	 */
	function wpmedia_posted_by() {
		$byline = sprintf(
			/* translators: %s: post author. */
			'%s',
			'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '" title="' . esc_html( get_the_author() ) . '">' . esc_html( get_the_author() ) . '</a></span>'
		);
		echo '<div class="posted-by"> ' . $byline . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
endif;

if ( ! function_exists( 'wpmedia_entry_footer' ) ) :
	/**
	 * Prints HTML with meta information for the categories, tags and comments.
	 *
	 * @since 1.0.0
	 *
	 * @param integer $postid Post ID.
	 */
	function wpmedia_entry_footer( $postid = '' ) {
		global $post;
		// Hide category and tag text for pages.
		if ( 'post' === get_post_type() || 'attachment' === get_post_type() ) {
			/* translators: used between list items, there is a space after the comma */
			$tags_list = get_the_tag_list( sprintf( '<span class="idt-tagtitle">%s:</span> ', __( 'Tags', 'wpmedia' ) ), ' ', '', ! empty( $postid ) ? absint( $postid ) : '' );
			if ( $tags_list && ! is_wp_error( $tags_list ) ) {
				/* translators: 1: list of tags. */
				printf( '<span class="tags-links">%1$s</span>', $tags_list ); // phpcs:ignore
			}
		}

		$pid = ! empty( $postid ) ? absint( $postid ) : $post->ID;

		if ( ! is_wp_error( get_the_term_list( $pid, 'newstopic' ) ) ) {
			$termlist = get_the_term_list( $pid, 'newstopic' );
			if ( ! empty( $termlist ) ) {
				echo '<span class="tags-links gmr-metatopic">';
				echo get_the_term_list( $pid, 'newstopic', sprintf( '<span class="idt-tagtitle">%s:</span> ', __( 'Topics', 'wpmedia' ) ), ' ', '' );
				echo '</span>';
			}
		}
	}
endif;

if ( ! function_exists( 'wpmedia_postformat_thumbnails' ) ) :
	/**
	 * Prints HTML with meta information for the current post-date/time.
	 *
	 * @param boolean $echo Echo.
	 */
	function wpmedia_postformat_thumbnails( $echo = true ) {
		$postid = get_the_ID();

		$content = '';
		if ( has_post_format( 'video' ) ) {
			$content .= '<div class="svg-format gmr-format-video"></div>';
				$hour = get_post_meta( absint( $postid ), '_durh', true );
				$min  = get_post_meta( absint( $postid ), '_durm', true );
				$sec  = get_post_meta( absint( $postid ), '_durs', true );
			if ( ! empty( $hour ) || ! empty( $min ) || ! empty( $sec ) ) {
				$content .= '<div class="gmr-format gmr-format-video">';
				$content .= '<span class="duration">';
				if ( ! empty( $hour ) && 0 !== $hour ) {
					$content .= esc_html( str_pad( absint( $hour ), 2, '0', STR_PAD_LEFT ) . ':' );
				}
				if ( ! empty( $min ) ) {
					$content .= esc_html( str_pad( absint( $min ), 2, '0', STR_PAD_LEFT ) . ':' );
				} else {
					$content .= '00';
				}
				if ( ! empty( $sec ) ) {
					$content .= esc_html( str_pad( absint( $sec ), 2, '0', STR_PAD_LEFT ) );
				} else {
					$content .= '00';
				}
				$content .= '</span>';
				$content .= '</div>';
			}
		} elseif ( has_post_format( 'gallery' ) ) {
			$content    .= '<div class="svg-format gmr-format-gallery"></div>';
			$attachments = get_children(
				array(
					'post_status'    => 'inherit',
					'post_type'      => 'attachment',
					'post_parent'    => intval( $postid ),
					'post_mime_type' => 'image',
					'order'          => 'ASC',
					'orderby'        => 'menu_order ID',
				)
			);

			if ( $attachments ) {
				$count    = count( (array) $attachments );
				$content .= '<div class="gmr-format gmr-format-gallery"><span class="duration">' . absint( $count ) . ' ' . esc_html__( 'Pics', 'wpmedia' ) . '</span></div>';
			}
		}
		if ( false === $echo ) {
			return $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} else {
			echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}
endif;

if ( ! function_exists( 'wpmedia_logo' ) ) :
	/**
	 * Prints HTML with meta information for the current post-date/time.
	 */
	function wpmedia_logo() {
		if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
			$custom_logo_id = get_theme_mod( 'custom_logo' );
			$logo           = wp_get_attachment_image_src( $custom_logo_id, 'full' );
			$desc           = get_bloginfo( 'name', 'display' );
			$logo_url       = ! empty( $logo[0] ) ? $logo[0] : '';
			$logo_width     = ! empty( $logo[1] ) ? $logo[1] : '';
			$logo_height    = ! empty( $logo[2] ) ? $logo[2] : '';
			if ( ! empty( $logo_url ) ) {
				echo '<a class="custom-logo-link" href="' . esc_url( home_url( '/' ) ) . '" title="' . esc_html( $desc ) . '" rel="home">';
				echo '<img class="custom-logo" src="' . esc_url( $logo_url ) . '" width="' . (int) $logo_width . '" height="' . (int) $logo_height . '" alt="' . esc_html( $desc ) . '" loading="lazy" />';
				echo '</a>';
			} else {
				?>
				<div class="site-title logolink"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php bloginfo( 'name' ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></div>
				<?php
				$wpmedia_description = get_bloginfo( 'description', 'display' );
				if ( $wpmedia_description || is_customize_preview() ) :
					?>
					<span class="site-description screen-reader-text"><?php echo esc_html( $wpmedia_description ); ?></span>
				<?php endif; ?>
				<?php
			}
		} else {
			?>
				<div class="site-title logolink"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php bloginfo( 'name' ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></div>
				<?php
				$wpmedia_description = get_bloginfo( 'description', 'display' );
				if ( $wpmedia_description || is_customize_preview() ) :
					?>
					<span class="site-description screen-reader-text"><?php echo esc_html( $wpmedia_description ); ?></span>
				<?php endif; ?>
			<?php
		}
	}
endif;
add_action( 'wpmedia_logo', 'wpmedia_logo' );

if ( ! function_exists( 'wpmedia_social_share' ) ) :
	/**
	 * Prints social share
	 *
	 * @since 1.0.0
	 *
	 * @param boolean $pinterest Pinterest active or not.
	 */
	function wpmedia_social_share( $pinterest = false ) {
		global $post;

		echo '<ul class="gmr-socialicon-share">';
		echo '<li class="facebook">';
			echo '<a href="https://www.facebook.com/sharer/sharer.php?u=' . rawurlencode( esc_url( get_the_permalink() ) ) . '" target="_blank" rel="nofollow" data-title="' . esc_html__( 'Facebook', 'wpmedia' ) . '" title="' . esc_html__( 'Facebook', 'wpmedia' ) . '">';
				echo '<svg xmlns="http://www.w3.org/2000/svg" width="0.63em" height="1em" viewBox="0 0 320 512"><path fill="currentColor" d="m279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"/></svg>';
			echo '</a>';
		echo '</li>';
		echo '<li class="twitter">';
			echo '<a href="https://twitter.com/intent/tweet?url=' . rawurlencode( esc_url( get_the_permalink() ) ) . '&amp;text=' . rawurlencode( wp_strip_all_tags( get_the_title() ) ) . '" target="_blank" rel="nofollow" data-title="' . esc_html__( 'Twitter', 'wpmedia' ) . '" title="' . esc_html__( 'Twitter', 'wpmedia' ) . '">';
				echo '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="M18.205 2.25h3.308l-7.227 8.26l8.502 11.24H16.13l-5.214-6.817L4.95 21.75H1.64l7.73-8.835L1.215 2.25H8.04l4.713 6.231l5.45-6.231Zm-1.161 17.52h1.833L7.045 4.126H5.078L17.044 19.77Z"/></svg>';
			echo '</a>';
		echo '</li>';
		echo '<li class="telegram">';
			echo '<a href="https://t.me/share/url?url=' . rawurlencode( esc_url( get_the_permalink() ) ) . '&amp;text=' . rawurlencode( wp_strip_all_tags( get_the_title() ) ) . '" target="_blank" rel="nofollow" data-title="' . esc_html__( 'Telegram', 'wpmedia' ) . '" title="' . esc_html__( 'Telegram', 'wpmedia' ) . '">';
				echo '<svg xmlns="http://www.w3.org/2000/svg" width="0.88em" height="1em" viewBox="0 0 448 512"><path fill="currentColor" d="m446.7 98.6l-67.6 318.8c-5.1 22.5-18.4 28.1-37.3 17.5l-103-75.9l-49.7 47.8c-5.5 5.5-10.1 10.1-20.7 10.1l7.4-104.9l190.9-172.5c8.3-7.4-1.8-11.5-12.9-4.1L117.8 284L16.2 252.2c-22.1-6.9-22.5-22.1 4.6-32.7L418.2 66.4c18.4-6.9 34.5 4.1 28.5 32.2z"/></svg>';
			echo '</a>';
		echo '</li>';
		if ( true === $pinterest ) {
			echo '<li class="pinterest">';
			$thumbnail = get_the_post_thumbnail_url( $post->ID, 'full' );
			if ( $thumbnail ) {
				$img = $thumbnail;
			} else {
				$img = '';
			}
				echo '<a href="https://pinterest.com/pin/create/button/?url=' . rawurlencode( esc_url( get_the_permalink() ) ) . '&amp;desciption=' . rawurlencode( wp_strip_all_tags( get_the_title() ) ) . '&amp;media=' . rawurlencode( esc_url( $img ) ) . '" target="_blank" rel="nofollow" data-title="' . esc_html__( 'Pin', 'wpmedia' ) . '" title="' . esc_html__( 'Pin', 'wpmedia' ) . '">';
					echo '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="-4.5 -2 24 24"><path fill="currentColor" d="M6.17 13.097c-.506 2.726-1.122 5.34-2.95 6.705c-.563-4.12.829-7.215 1.475-10.5c-1.102-1.91.133-5.755 2.457-4.808c2.86 1.166-2.477 7.102 1.106 7.844c3.741.774 5.269-6.683 2.949-9.109C7.855-.272 1.45 3.15 2.238 8.163c.192 1.226 1.421 1.598.491 3.29C.584 10.962-.056 9.22.027 6.897C.159 3.097 3.344.435 6.538.067c4.04-.466 7.831 1.527 8.354 5.44c.59 4.416-1.823 9.2-6.142 8.855c-1.171-.093-1.663-.69-2.58-1.265z"/></svg>';
				echo '</a>';
			echo '</li>';
		}
		echo '<li class="whatsapp">';
			echo '<a href="https://api.whatsapp.com/send?text=' . rawurlencode( wp_strip_all_tags( get_the_title() ) ) . ' ' . rawurlencode( esc_url( get_permalink() ) ) . '" target="_blank" rel="nofollow" data-title="' . esc_html__( 'WhatsApp', 'wpmedia' ) . '" title="' . esc_html__( 'WhatsApp', 'wpmedia' ) . '">';
				echo '<svg xmlns="http://www.w3.org/2000/svg" width="0.88em" height="1em" viewBox="0 0 448 512"><path fill="currentColor" d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222c0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222c0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4l-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2c0-101.7 82.8-184.5 184.6-184.5c49.3 0 95.6 19.2 130.4 54.1c34.8 34.9 56.2 81.2 56.1 130.5c0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18c-5.1-1.9-8.8-2.8-12.5 2.8c-3.7 5.6-14.3 18-17.6 21.8c-3.2 3.7-6.5 4.2-12 1.4c-32.6-16.3-54-29.1-75.5-66c-5.7-9.8 5.7-9.1 16.3-30.3c1.8-3.7.9-6.9-.5-9.7c-1.4-2.8-12.5-30.1-17.1-41.2c-4.5-10.8-9.1-9.3-12.5-9.5c-3.2-.2-6.9-.2-10.6-.2c-3.7 0-9.7 1.4-14.8 6.9c-5.1 5.6-19.4 19-19.4 46.3c0 27.3 19.9 53.7 22.6 57.4c2.8 3.7 39.1 59.7 94.8 83.8c35.2 15.2 49 16.5 66.6 13.9c10.7-1.6 32.8-13.4 37.4-26.4c4.6-13 4.6-24.1 3.2-26.4c-1.3-2.5-5-3.9-10.5-6.6z"/></svg>';
			echo '</a>';
		echo '</li>';
		echo '</ul>';
	}
endif;
add_action( 'wpmedia_social_share', 'wpmedia_social_share', 10, 2 );

if ( ! function_exists( 'wpmedia_comment_icon' ) ) :
	/**
	 * Prints HTML with the comment count for the current post.
	 */
	function wpmedia_comment_icon() {
		global $post;
		if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
			echo '<div class="gmr-iconnotif">';
			$svg = '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M15 4v7H5.17L4 12.17V4h11m1-2H3c-.55 0-1 .45-1 1v14l4-4h10c.55 0 1-.45 1-1V3c0-.55-.45-1-1-1zm5 4h-2v9H6v2c0 .55.45 1 1 1h11l4 4V7c0-.55-.45-1-1-1z"/></svg>';
			comments_popup_link(
				$svg, // No comment.
				$svg . '<span class="notif-number">1</span>', // 1 comment.
				$svg . '<span class="notif-number">%</span>', // More than 1 comments.
				'', // Class.
				$svg . '<span class="notif-number">' . __( 'Closed', 'wpmedia' ) . '</span>'
			);

			echo '</div>';
		}
	}
endif;
add_action( 'wpmedia_comment_icon', 'wpmedia_comment_icon', 10, 2 );

if ( ! function_exists( 'wpmedia_social_popup' ) ) :
	/**
	 * Prints HTML with the comment count for the current post.
	 */
	function wpmedia_social_popup() {
		if ( ! wpmedia_is_amp() ) {
			echo '<button id="share-modal" data-modal="gmr-popupwrap" aria-label="' . esc_html__( 'Share', 'wpmedia' ) . '">';
			echo '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92c0-1.61-1.31-2.92-2.92-2.92zM18 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zM6 13c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm12 7.02c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1z"/></svg>';
			echo '</button>';
			echo '<div id="gmr-popupwrap" class="gmr-share-popup">';
		} else {
			echo '<button id="share-modal" on="tap:gmr-popupwrap" aria-label="' . esc_html__( 'Share', 'wpmedia' ) . '">';
			echo '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92c0-1.61-1.31-2.92-2.92-2.92zM18 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zM6 13c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm12 7.02c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1z"/></svg>';
			echo '</button>';
			echo '<amp-lightbox id="gmr-popupwrap" class="gmr-share-popup" layout="nodisplay">';
		}
		if ( wpmedia_is_amp() ) {
			$tap = ' on="tap:gmr-popupwrap.close" role="button" aria-label="' . esc_html__( 'Share', 'wpmedia' ) . '" tabindex="0"';
		} else {
			$tap = '';
		}
			echo '<div class="gmr-modalbg close-modal"' . $tap . '></div>'; // phpcs:ignore
			echo '<div class="gmr-in-popup clearfix">';
				echo '<span class="idt-xclose close-modal"' . $tap . '>&times;</span>'; // phpcs:ignore
				echo '<h4 class="main-textshare">' . esc_html( get_the_title() ) . '</h4>';
				echo '<div class="content-share">';
					echo '<div class="second-textshare">' . esc_html__( 'Share this article', 'wpmedia' ) . '</div>';
						do_action( 'wpmedia_social_share', $pinterest = true );
					echo '</div>';
			echo '</div>';

		if ( ! wpmedia_is_amp() ) {
			echo '</div>';
		} else {
			echo '</amp-lightbox>';
		}
	}
endif;
add_action( 'wpmedia_social_popup', 'wpmedia_social_popup' );

if ( ! function_exists( 'wpmedia_post_thumbnail' ) ) :
	/**
	 * Displays an optional post thumbnail.
	 *
	 * Wraps the post thumbnail in an anchor element on index views, or a div
	 * element when on single views.
	 */
	function wpmedia_post_thumbnail() {
		if ( post_password_required() || is_attachment() || ! has_post_thumbnail() ) {
			return;
		}

		if ( is_singular() ) :
			?>

			<div class="post-thumbnail">
				<?php the_post_thumbnail(); ?>
			</div><!-- .post-thumbnail -->

		<?php else : ?>

			<a class="post-thumbnail" href="<?php the_permalink(); ?>">
				<?php
					the_post_thumbnail(
						'medium',
						array(
							'alt' => the_title_attribute(
								array(
									'echo' => false,
								)
							),
						)
					);
				?>
			</a>

			<?php
		endif; // End is_singular().
	}
endif;

if ( ! function_exists( 'wp_body_open' ) ) :
	/**
	 * Shim for sites older than 5.2.
	 *
	 * @link https://core.trac.wordpress.org/ticket/12563
	 */
	function wp_body_open() {
		do_action( 'wp_body_open' );
	}
endif;

if ( ! function_exists( 'wpmedia_reading_time' ) ) :
	/**
	 * Estimated Reading Time
	 *
	 * @since 1.0.0
	 */
	function wpmedia_reading_time() {
		global $post;
		$content          = get_post_field( 'post_content', $post->ID );
		$word_count       = str_word_count( wp_strip_all_tags( $content ) );
		$readingtime      = ceil( $word_count / 200 ); // 200 huruf per menit membaca.
		$totalreadingtime = $readingtime . esc_html__( ' min read', 'wpmedia' );
		echo '<span class="count-text"><svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 24 24" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><g><rect fill="none" height="24" width="24" x="0"/></g><g><path d="M22.47,5.2C22,4.96,21.51,4.76,21,4.59v12.03C19.86,16.21,18.69,16,17.5,16c-1.9,0-3.78,0.54-5.5,1.58V5.48 C10.38,4.55,8.51,4,6.5,4C4.71,4,3.02,4.44,1.53,5.2C1.2,5.36,1,5.71,1,6.08v12.08c0,0.58,0.47,0.99,1,0.99 c0.16,0,0.32-0.04,0.48-0.12C3.69,18.4,5.05,18,6.5,18c2.07,0,3.98,0.82,5.5,2c1.52-1.18,3.43-2,5.5-2c1.45,0,2.81,0.4,4.02,1.04 c0.16,0.08,0.32,0.12,0.48,0.12c0.52,0,1-0.41,1-0.99V6.08C23,5.71,22.8,5.36,22.47,5.2z M10,16.62C8.86,16.21,7.69,16,6.5,16 c-1.19,0-2.36,0.21-3.5,0.62V6.71C4.11,6.24,5.28,6,6.5,6C7.7,6,8.89,6.25,10,6.72V16.62z M19,0.5l-5,5V15l5-4.5V0.5z"/></g></svg><span class="in-count-text">' . esc_html( $totalreadingtime ) . '</span></span>';
	}
endif;

if ( ! function_exists( 'gmr_add_prevnext_post_navigation' ) ) :
	/**
	 * Add prev and next links to a numbered link list
	 *
	 * @since 1.0.0
	 *
	 * @param array $args Argument.
	 * @return array $args
	 */
	function gmr_add_prevnext_post_navigation( $args ) {
		global $page, $numpages, $more, $pagenow;

		if ( 'next_and_number' !== $args['next_or_number'] ) {
			return $args; // exit early.
		}

		$args['next_or_number'] = 'number'; // keep numbering for the main part.
		if ( ! $more ) {
			return $args; // exit early.
		}

		if ( $page - 1 ) { // There is a previous page.
			$args['before'] .= _wp_link_page( $page - 1 ) . $args['link_before'] . $args['previouspagelink'] . $args['link_after'] . '</a>';
		}

		if ( $page < $numpages ) { // there is a next page.
			$args['after'] = _wp_link_page( $page + 1 ) . $args['link_before'] . $args['nextpagelink'] . $args['link_after'] . '</a>' . $args['after'];
		}

		return $args;
	}
endif; // endif gmr_add_prevnext_post_navigation.
add_filter( 'wp_link_pages_args', 'gmr_add_prevnext_post_navigation', 2 );

if ( ! function_exists( 'wpmedia_next_posts_nav' ) ) :
	/**
	 * Add next posts
	 *
	 * @since 1.0.0
	 */
	function wpmedia_next_posts_nav() {
		$next_post = get_next_post();

		if ( $next_post ) :
			if ( ! empty( $next_post ) ) :
				?>
				<div class="gmr-nextposts-button">
					<a href="<?php echo esc_url( get_permalink( $next_post->ID ) ); ?>" class="nextposts-content-link" title="<?php echo wp_kses_post( get_the_title( $next_post->ID ) ); ?>">
						<?php
						if ( has_post_thumbnail( $next_post->ID ) ) {
							?>
							<div class="post-thumbnail">
								<?php
									echo get_the_post_thumbnail( $next_post->ID, 'thumbnail' ); // phpcs:ignore
								?>
							</div>
							<?php
						}
						?>
						<div class="nextposts-content">
							<div class="recent-title"><?php echo wp_kses_post( get_the_title( $next_post->ID ) ); ?></div>
						</div>
						<div class="nextposts-icon">
							<svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 24 24" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><g><path d="M0,0h24v24H0V0z" fill="none"/></g><g><polygon points="6.23,20.23 8,22 18,12 8,2 6.23,3.77 14.46,12"/></g></svg>
						</div>
					</a>
				</div>
				<?php
			endif;
		endif;
	}
endif; // endif wpmedia_next_posts_nav.
add_action( 'wpmedia_next_posts_nav', 'wpmedia_next_posts_nav', 10 );

if ( ! function_exists( 'wpmedia_related_post' ) ) {
	/**
	 * Adding the related post to the end of your single post
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function wpmedia_related_post() {
		global $post;

		$relatedposts = get_theme_mod( 'gmr_active-relpost', 0 );

		if ( is_singular( 'attachment' ) ) {
			$postids = $post->post_parent;
		} else {
			$postids = $post->ID;
		}
		if ( 0 === $relatedposts ) {
			$numberposts = get_theme_mod( 'gmr_relpost_number', '6' );
			$taxonomy    = get_theme_mod( 'gmr_relpost_taxonomy', 'gmr-category' );

			if ( 'gmr-tags' === $taxonomy ) {
				$tags = wp_get_post_tags( absint( $postids ) );
				if ( $tags ) {
					$tag_ids = array();
					foreach ( $tags as $individual_tag ) {
						$tag_ids[] = $individual_tag->term_id;
					}
					$args = array(
						'tag__in'             => $tag_ids,
						'post__not_in'        => array( absint( $postids ) ),
						'posts_per_page'      => absint( $numberposts ), // phpcs:ignore
						'ignore_sticky_posts' => true,
						'fields'              => 'ids',
					);
				}
			} elseif ( 'gmr-topics' === $taxonomy ) {
				$topics = wp_get_object_terms( absint( $postids ), 'newstopic', array( 'fields' => 'ids' ) );
				if ( $topics ) {
					$args = array(
						'post__not_in'        => array( absint( $postids ) ),
						'posts_per_page'      => absint( $numberposts ), // phpcs:ignore
						'tax_query'           => array( // phpcs:ignore
							array(
								'taxonomy' => 'newstopic',
								'field'    => 'id',
								'terms'    => $topics,
							),
						),
						'ignore_sticky_posts' => true,
						'fields'              => 'ids',
					);
				}
			} else {
				$categories = get_the_category( absint( $postids ) );
				if ( $categories ) {
					$category_ids = array();
					foreach ( $categories as $individual_category ) {
						$category_ids[] = $individual_category->term_id;
					}
					$args = array(
						'category__in'        => $category_ids,
						'post__not_in'        => array( absint( $postids ) ),
						'posts_per_page'      => absint( $numberposts ), // phpcs:ignore
						'ignore_sticky_posts' => true,
						'fields'              => 'ids',
					);
				}
			}
			if ( ! isset( $args ) ) {
				$args = '';
			}
			$wpmedia_query = new WP_Query( $args );

			if ( $wpmedia_query->have_posts() ) {
				$textrelpost = get_theme_mod( 'gmr_textrelpost' );
				$title       = ! empty( $textrelpost ) ? esc_html( $textrelpost ) : esc_attr__( 'Related Posts', 'wpmedia' );
				echo '<div class="gmr-related-post">';
				echo '<h3 class="related-text sub-title">' . esc_html( $title ) . '</h3>';
				echo '<div class="wpmedia-list-gallery related-gallery">';
				while ( $wpmedia_query->have_posts() ) :

					$wpmedia_query->the_post();
					$featured_image_url = wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) );

					echo '<div class="list-gallery">';

					if ( ! empty( $featured_image_url ) ) :
						echo '<div class="module-smallthumb">';
						echo '<a href="' . esc_url( get_permalink() ) . '" class="post-thumbnail" title="' . the_title_attribute(
							array(
								'before' => '',
								'after'  => '',
								'echo'   => false,
							)
						) . '" rel="bookmark">';
						echo get_the_post_thumbnail( get_the_ID(), 'medium_large' );
						wpmedia_postformat_thumbnails();
						echo '</a>';
						wpmedia_category();
						echo '</div>';
					endif;

						echo '<div class="list-gallery-title">';
						echo '<a href="' . esc_url( get_permalink() ) . '" class="recent-title heading-text" title="' . the_title_attribute(
							array(
								'before' => '',
								'after'  => '',
								'echo'   => false,
							)
						) . '" rel="bookmark">' . wp_kses_post( get_the_title() ) . '</a>';
						echo '</div>';
					echo '</div>';

				endwhile;
				wp_reset_postdata();
				echo '</div>';
				echo '</div>';
			}
		}
	}
}
add_action( 'wpmedia_related_post', 'wpmedia_related_post', 10 );

if ( ! function_exists( 'wpmedia_related_post_second' ) ) {
	/**
	 * Adding the related post to the end of your single post
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function wpmedia_related_post_second() {
		global $post;

		$relatedposts = get_theme_mod( 'gmr_active-relpostsecond', 0 );

		if ( is_singular( 'attachment' ) ) {
			$postids = $post->post_parent;
		} else {
			$postids = $post->ID;
		}

		if ( 0 === $relatedposts ) {
			$numberposts = get_theme_mod( 'gmr_relpostsecond_number', '6' );
			$taxonomy    = get_theme_mod( 'gmr_relpostsecond_taxonomy', 'gmr-category' );

			if ( 'gmr-tags' === $taxonomy ) {
				$tags = wp_get_post_tags( absint( $postids ) );
				if ( $tags ) {
					$tag_ids = array();
					foreach ( $tags as $individual_tag ) {
						$tag_ids[] = $individual_tag->term_id;
					}
					$args = array(
						'tag__in'             => $tag_ids,
						'post__not_in'        => array( absint( $postids ) ),
						'posts_per_page'      => absint( $numberposts ), // phpcs:ignore
						'ignore_sticky_posts' => true,
						'fields'              => 'ids',
					);
				}
			} elseif ( 'gmr-topics' === $taxonomy ) {
				$topics = wp_get_object_terms( absint( $postids ), 'newstopic', array( 'fields' => 'ids' ) );
				if ( $topics ) {
					$args = array(
						'post__not_in'        => array( absint( $postids ) ),
						'posts_per_page'      => absint( $numberposts ), // phpcs:ignore
						'tax_query'           => array( // phpcs:ignore WordPress.WP.TaxQuery.tax_query
							array(
								'taxonomy' => 'newstopic',
								'field'    => 'id',
								'terms'    => $topics,
							),
						),
						'ignore_sticky_posts' => true,
						'fields'              => 'ids',
					);
				}
			} else {
				$categories = get_the_category( absint( $postids ) );
				if ( $categories ) {
					$category_ids = array();
					foreach ( $categories as $individual_category ) {
						$category_ids[] = $individual_category->term_id;
					}
					$args = array(
						'category__in'        => $category_ids,
						'post__not_in'        => array( absint( $postids ) ),
						'posts_per_page'      => absint( $numberposts ), // phpcs:ignore
						'ignore_sticky_posts' => 1,
					);
				}
			}
			if ( ! isset( $args ) ) {
				$args = '';
			}
			$wpmedia_query = new WP_Query( $args );

			if ( $wpmedia_query->have_posts() ) {
				$textrelpostsecond = get_theme_mod( 'gmr_textrelpostsecond' );
				$title             = ! empty( $textrelpostsecond ) ? esc_html( $textrelpostsecond ) : esc_attr__( 'Read Also', 'wpmedia' );
				echo '<div class="gmr-related-post">';
				echo '<h3 class="related-text sub-title">' . esc_html( $title ) . '</h3>';
				while ( $wpmedia_query->have_posts() ) :
					$wpmedia_query->the_post();

					$focus_display = get_post_meta( absint( get_the_ID() ), '_gmr_focus_key', true );

					$focus = '';
					if ( $focus_display ) {
						$focus = ' gmr-focus-news';
					}

					$focusthumb = 'medium';
					if ( $focus_display ) {
						$focusthumb = 'medium_large';
					}
					$featured_image_url = wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) );

					echo '<article class="post type-post">';
					echo '<div class="box-item' . esc_html( $focus ) . '">';

					if ( ! empty( $featured_image_url ) ) :
						echo '<a href="' . esc_url( get_permalink() ) . '" class="post-thumbnail" title="' . the_title_attribute(
							array(
								'before' => '',
								'after'  => '',
								'echo'   => false,
							)
						) . '" rel="bookmark">';
						echo get_the_post_thumbnail( get_the_ID(), esc_html( $focusthumb ) );
						wpmedia_postformat_thumbnails();
						echo '</a>';
					endif;

					echo '<div class="box-content">';
					echo '<div class="reltitle">';
					echo '<a href="' . esc_url( get_permalink() ) . '" title="' . the_title_attribute(
						array(
							'before' => '',
							'after'  => '',
							'echo'   => false,
						)
					) . '" rel="bookmark">' . wp_kses_post( get_the_title() ) . '</a>';
					echo '</div>';
					echo '<div class="gmr-meta-topic">';
						echo '<span class="meta-content">';
						wpmedia_category();
						wpmedia_posted_on();
						echo '</span>';
					echo '</div>';

					$excerpt_opsi = get_theme_mod( 'gmr_active-excerpt', 0 );
					if ( 0 === $excerpt_opsi ) :
						echo '<div class="entry-content entry-content-archive">';
						the_excerpt();
						echo '</div>';
					endif;
					echo '</div>';
					echo '</div>';
					echo '</article>';

				endwhile;
				wp_reset_postdata();
				echo '</div>';
			}
		}
	}
}
add_action( 'wpmedia_related_post_second', 'wpmedia_related_post_second', 10 );

if ( ! function_exists( 'wpmedia_list_social' ) ) :
	/**
	 * This function add social icon.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function wpmedia_list_social() {
		$fb_url = get_theme_mod( 'gmr_fb_url_icon' );
		if ( $fb_url ) :
			echo '<li><a href="' . esc_url( $fb_url ) . '" title="' . esc_html__( 'Facebook', 'wpmedia' ) . '" class="facebook" target="_blank" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="vertical-align: -0.125em;-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><path d="M13 9h4.5l-.5 2h-4v9h-2v-9H7V9h4V7.128c0-1.783.186-2.43.534-3.082a3.635 3.635 0 0 1 1.512-1.512C13.698 2.186 14.345 2 16.128 2c.522 0 .98.05 1.372.15V4h-1.372c-1.324 0-1.727.078-2.138.298c-.304.162-.53.388-.692.692c-.22.411-.298.814-.298 2.138V9z" fill="#888888"/><rect x="0" y="0" width="24" height="24" fill="rgba(0, 0, 0, 0)" /></svg></a></li>';
		endif;

		$twitter_url = get_theme_mod( 'gmr_twitter_url_icon' );
		if ( $twitter_url ) :
			echo '<li><a href="' . esc_url( $twitter_url ) . '" title="' . esc_html__( 'Twitter', 'wpmedia' ) . '" class="twitter" target="_blank" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="M18.205 2.25h3.308l-7.227 8.26l8.502 11.24H16.13l-5.214-6.817L4.95 21.75H1.64l7.73-8.835L1.215 2.25H8.04l4.713 6.231l5.45-6.231Zm-1.161 17.52h1.833L7.045 4.126H5.078L17.044 19.77Z"/></svg></a></li>';
		endif;

		$pinterest_url = get_theme_mod( 'gmr_pinterest_url_icon' );
		if ( $pinterest_url ) :
			echo '<li><a href="' . esc_url( $pinterest_url ) . '" title="' . esc_html__( 'Pinterest', 'wpmedia' ) . '" class="pinterest" target="_blank" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="vertical-align: -0.125em;-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveAspectRatio="xMidYMid meet" viewBox="0 0 32 32"><path d="M16.094 4C11.017 4 6 7.383 6 12.861c0 3.483 1.958 5.463 3.146 5.463c.49 0 .774-1.366.774-1.752c0-.46-1.174-1.44-1.174-3.355c0-3.978 3.028-6.797 6.947-6.797c3.37 0 5.864 1.914 5.864 5.432c0 2.627-1.055 7.554-4.47 7.554c-1.231 0-2.284-.89-2.284-2.166c0-1.87 1.197-3.681 1.197-5.611c0-3.276-4.537-2.682-4.537 1.277c0 .831.104 1.751.475 2.508C11.255 18.354 10 23.037 10 26.066c0 .935.134 1.855.223 2.791c.168.188.084.169.341.075c2.494-3.414 2.263-4.388 3.391-8.856c.61 1.158 2.183 1.781 3.43 1.781c5.255 0 7.615-5.12 7.615-9.738C25 7.206 20.755 4 16.094 4z" fill="#888888"/><rect x="0" y="0" width="32" height="32" fill="rgba(0, 0, 0, 0)" /></svg></a></li>';
		endif;

		$wordpress_url = get_theme_mod( 'gmr_wordpress_url_icon' );
		if ( $wordpress_url ) :
			echo '<li><a href="' . esc_url( $wordpress_url ) . '" title="' . esc_html__( 'WordPress', 'wpmedia' ) . '" class="wp" target="_blank" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="vertical-align: -0.125em;-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveAspectRatio="xMidYMid meet" viewBox="0 0 32 32"><path d="M16 3C8.828 3 3 8.828 3 16s5.828 13 13 13s13-5.828 13-13S23.172 3 16 3zm0 2.168c2.825 0 5.382 1.079 7.307 2.838c-.042-.001-.083-.012-.135-.012c-1.062 0-1.754.93-1.754 1.928c0 .899.453 1.648 1.006 2.547c.41.715.889 1.646.889 2.978c0 .932-.348 2.004-.825 3.51l-1.07 3.607l-4.066-12.527a23.51 23.51 0 0 0 1.234-.098c.585-.065.52-.931-.065-.898c0 0-1.754.14-2.892.14c-1.061 0-2.85-.14-2.85-.14c-.585-.033-.65.866-.064.898c0 0 .552.065 1.137.098l1.824 5.508l-2.364 7.107L9.215 10.04a23.408 23.408 0 0 0 1.246-.098c.585-.065.51-.931-.065-.898c0 0-1.681.133-2.82.139A10.795 10.795 0 0 1 16 5.168zm9.512 5.633A10.815 10.815 0 0 1 26.832 16a10.796 10.796 0 0 1-5.383 9.36l3.305-9.565c.617-1.538.822-2.774.822-3.879c0-.401-.02-.76-.062-1.105c-.002-.003-.001-.007-.002-.01zm-19.309.584l5.063 14.355A10.797 10.797 0 0 1 5.168 16c0-1.655.377-3.215 1.035-4.615zm9.98 5.558l3.338 9.131a.595.595 0 0 0 .075.139c-1.126.394-2.332.619-3.596.619c-1.067 0-2.094-.159-3.066-.443l3.25-9.446zm-4.787 8.86a10.74 10.74 0 0 1 0 0zm9.02.09zm-7.855.378a10.713 10.713 0 0 1 0 0z" fill="#888888"/><rect x="0" y="0" width="32" height="32" fill="rgba(0, 0, 0, 0)" /></svg></a></li>';
		endif;

		$instagram_url = get_theme_mod( 'gmr_instagram_url_icon' );
		if ( $instagram_url ) :
			echo '<li><a href="' . esc_url( $instagram_url ) . '" title="' . esc_html__( 'Instagram', 'wpmedia' ) . '" class="instagram" target="_blank" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="vertical-align: -0.125em;-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveAspectRatio="xMidYMid meet" viewBox="0 0 256 256"><path d="M128 80a48 48 0 1 0 48 48a48.054 48.054 0 0 0-48-48zm0 80a32 32 0 1 1 32-32a32.036 32.036 0 0 1-32 32zm44-132H84a56.064 56.064 0 0 0-56 56v88a56.064 56.064 0 0 0 56 56h88a56.064 56.064 0 0 0 56-56V84a56.064 56.064 0 0 0-56-56zm40 144a40.045 40.045 0 0 1-40 40H84a40.045 40.045 0 0 1-40-40V84a40.045 40.045 0 0 1 40-40h88a40.045 40.045 0 0 1 40 40zm-20-96a12 12 0 1 1-12-12a12 12 0 0 1 12 12z" fill="#888888"/><rect x="0" y="0" width="256" height="256" fill="rgba(0, 0, 0, 0)" /></svg></a></li>';
		endif;

		$reddit_url = get_theme_mod( 'gmr_reddit_url_icon' );
		if ( $reddit_url ) :
			echo '<li><a href="' . esc_url( $reddit_url ) . '" title="' . esc_html__( 'Reddit', 'wpmedia' ) . '" class="reddit" target="_blank" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="vertical-align: -0.125em;-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveAspectRatio="xMidYMid meet" viewBox="0 0 32 32"><path d="M18.656 4C16.56 4 15 5.707 15 7.656v3.375c-2.758.145-5.258.875-7.281 2.031C6.945 12.316 5.914 12 4.906 12c-1.09 0-2.199.355-2.968 1.219v.031l-.032.031c-.738.922-1.039 2.153-.843 3.375a4.444 4.444 0 0 0 1.968 3C3.023 19.77 3 19.883 3 20c0 2.605 1.574 4.887 3.938 6.469C9.3 28.05 12.488 29 16 29c3.512 0 6.7-.95 9.063-2.531C27.425 24.887 29 22.605 29 20c0-.117-.023-.23-.031-.344a4.444 4.444 0 0 0 1.968-3c.196-1.222-.105-2.453-.843-3.375l-.032-.031c-.769-.863-1.878-1.25-2.968-1.25c-1.008 0-2.04.316-2.813 1.063c-2.023-1.157-4.523-1.887-7.281-2.032V7.656C17 6.676 17.559 6 18.656 6c.52 0 1.164.246 2.157.594c.843.297 1.937.625 3.343.718C24.496 8.29 25.414 9 26.5 9C27.875 9 29 7.875 29 6.5S27.875 4 26.5 4c-.945 0-1.762.535-2.188 1.313c-1.199-.07-2.066-.32-2.843-.594C20.566 4.402 19.734 4 18.656 4zM16 13c3.152 0 5.965.867 7.938 2.188C25.91 16.508 27 18.203 27 20c0 1.797-1.09 3.492-3.063 4.813C21.965 26.133 19.152 27 16 27s-5.965-.867-7.938-2.188C6.09 23.492 5 21.797 5 20c0-1.797 1.09-3.492 3.063-4.813C10.034 13.867 12.848 13 16 13zM4.906 14c.38 0 .754.094 1.063.25c-1.086.91-1.93 1.992-2.438 3.188a2.356 2.356 0 0 1-.469-1.094c-.109-.672.086-1.367.407-1.782c.004-.007-.004-.023 0-.03c.304-.321.844-.532 1.437-.532zm22.188 0c.593 0 1.133.21 1.437.531c.004.004-.004.028 0 .031c.32.415.516 1.11.407 1.782c-.063.39-.215.773-.47 1.093c-.507-1.195-1.35-2.277-2.437-3.187c.309-.156.684-.25 1.063-.25zM11 16a1.999 1.999 0 1 0 0 4a1.999 1.999 0 1 0 0-4zm10 0a1.999 1.999 0 1 0 0 4a1.999 1.999 0 1 0 0-4zm.25 5.531c-1.148 1.067-3.078 1.75-5.25 1.75s-4.102-.691-5.25-1.625C11.39 23.391 13.445 25 16 25s4.61-1.602 5.25-3.469z" fill="#888888"/><rect x="0" y="0" width="32" height="32" fill="rgba(0, 0, 0, 0)" /></svg></a></li>';
		endif;

		$linkedin_url = get_theme_mod( 'gmr_linkedin_url_icon' );
		if ( $linkedin_url ) :
			echo '<li><a href="' . esc_url( $linkedin_url ) . '" title="' . esc_html__( 'Linkedin', 'wpmedia' ) . '" class="linkedin" target="_blank" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="vertical-align: -0.125em;-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><path d="M12 9.55C12.917 8.613 14.111 8 15.5 8a5.5 5.5 0 0 1 5.5 5.5V21h-2v-7.5a3.5 3.5 0 0 0-7 0V21h-2V8.5h2v1.05zM5 6.5a1.5 1.5 0 1 1 0-3a1.5 1.5 0 0 1 0 3zm-1 2h2V21H4V8.5z" fill="#888888"/><rect x="0" y="0" width="24" height="24" fill="rgba(0, 0, 0, 0)" /></svg></a></li>';
		endif;

		$youtube_url = get_theme_mod( 'gmr_youtube_url_icon' );
		if ( $youtube_url ) :
			echo '<li><a href="' . esc_url( $youtube_url ) . '" title="' . esc_html__( 'Youtube', 'wpmedia' ) . '" class="youtube" target="_blank" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="vertical-align: -0.125em;-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><path d="M19.606 6.995c-.076-.298-.292-.523-.539-.592C18.63 6.28 16.5 6 12 6s-6.628.28-7.069.403c-.244.068-.46.293-.537.592C4.285 7.419 4 9.196 4 12s.285 4.58.394 5.006c.076.297.292.522.538.59C5.372 17.72 7.5 18 12 18s6.629-.28 7.069-.403c.244-.068.46-.293.537-.592C19.715 16.581 20 14.8 20 12s-.285-4.58-.394-5.005zm1.937-.497C22 8.28 22 12 22 12s0 3.72-.457 5.502c-.254.985-.997 1.76-1.938 2.022C17.896 20 12 20 12 20s-5.893 0-7.605-.476c-.945-.266-1.687-1.04-1.938-2.022C2 15.72 2 12 2 12s0-3.72.457-5.502c.254-.985.997-1.76 1.938-2.022C6.107 4 12 4 12 4s5.896 0 7.605.476c.945.266 1.687 1.04 1.938 2.022zM10 15.5v-7l6 3.5l-6 3.5z" fill="#888888"/><rect x="0" y="0" width="24" height="24" fill="rgba(0, 0, 0, 0)" /></svg></a></li>';
		endif;

		$threads_url = get_theme_mod( 'gmr_threads_url_icon' );
		if ( $threads_url ) :
			echo '<li><a href="' . esc_url( $threads_url ) . '" title="' . esc_html__( 'Threads', 'wpmedia' ) . '" class="threads" target="_blank" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="M12.184 1.41h-.002C9.09 1.432 6.7 2.473 5.094 4.516c-1.428 1.815-2.16 4.348-2.184 7.49v.002c.025 3.143.756 5.662 2.184 7.477c1.606 2.042 4.009 3.084 7.1 3.105h.002c2.748-.019 4.697-.74 6.303-2.344c2.104-2.103 2.042-4.741 1.347-6.363c-.53-1.234-1.575-2.221-2.976-2.835c-.18-2.985-1.86-4.726-4.62-4.744c-1.63-.01-3.102.72-4.003 2.087l1.655 1.136c.533-.809 1.377-1.199 2.335-1.19c1.387.009 2.3.774 2.555 2.117a11.7 11.7 0 0 0-2.484-.105c-2.64.152-4.368 1.712-4.253 3.875c.12 2.262 2.312 3.495 4.393 3.381c2.492-.137 3.973-1.976 4.324-4.321c.577.373 1.003.85 1.244 1.413c.44 1.025.468 2.716-.915 4.098c-1.217 1.216-2.68 1.746-4.912 1.762c-2.475-.018-4.332-.811-5.537-2.343C5.52 16.774 4.928 14.688 4.906 12c.022-2.688.614-4.775 1.746-6.213c1.205-1.533 3.062-2.325 5.537-2.344c2.493.019 4.384.815 5.636 2.356c.691.85 1.124 1.866 1.413 2.915l1.94-.517c-.363-1.338-.937-2.613-1.815-3.694c-1.653-2.034-4.081-3.071-7.18-3.093m.236 10.968a9.4 9.4 0 0 1 2.432.156c-.14 1.578-.793 2.947-2.512 3.041c-1.112.063-2.237-.434-2.292-1.461c-.04-.764.525-1.63 2.372-1.736" /></svg></a></li>';
		endif;

		$twitch_url = get_theme_mod( 'gmr_twitch_url_icon' );
		if ( $twitch_url ) :
			echo '<li><a href="' . esc_url( $twitch_url ) . '" title="' . esc_html__( 'Twitch', 'wpmedia' ) . '" class="twitch" target="_blank" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="vertical-align: -0.125em;-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><path d="M4.3 3H21v11.7l-4.7 4.7h-3.9l-2.5 2.4H7v-2.4H3V6.2L4.3 3zM5 17.4h4v2.4h.095l2.5-2.4h3.877L19 13.872V5H5v12.4zM15 8h2v4.7h-2V8zm0 0h2v4.7h-2V8zm-5 0h2v4.7h-2V8z" fill="#888888"/><rect x="0" y="0" width="24" height="24" fill="rgba(0, 0, 0, 0)" /></svg></a></li>';
		endif;

		$spotify_url = get_theme_mod( 'gmr_spotify_url_icon' );
		if ( $spotify_url ) :
			echo '<li><a href="' . esc_url( $spotify_url ) . '" title="' . esc_html__( 'Spotify', 'wpmedia' ) . '" class="spotify" target="_blank" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="vertical-align: -0.062em;-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 1024"><path d="M418 311q123 3 214 20.5T802 389q15 7 26 15.5t15 18.5t2 26.5t-10 21.5q-5 4-12.5 6.5t-15 4t-15 .5t-13.5-3q-156-81-360-73q-53 2-151 21q-56 11-68-31q-5-16 .5-29t17-19.5T245 338q18-4 173-27zm23 152q87 6 164 25.5T750 547q4 2 9 6t9 9t7.5 10.5t5.5 11t2 10.5q2 22-19 28.5t-48-7.5q-176-93-390-57q-3 0-20 5.5t-25 3.5q-3-1-6.5-2t-6.5-2.5l-6-3l-6-3.5l-6.5-4l-6-3.5l-6-3.5l-6.5-3q3-5 9-17.5t11.5-20T263 496q26-7 54-12t68.5-11.5T441 463zm-21 153q170 3 278 64q10 5 15.5 9.5t11.5 11t5 14.5t-8 16q-5 8-24 9t-29-5q-131-70-317-47q-7 1-17.5 3.5T315 696t-17 1t-15.5-4t-18-8.5T250 677q2-4 6-9t6.5-9.5t6-9t7.5-7.5t7-4q24-5 49.5-9.5t54.5-8t33-4.5zm604-104q0 212-150 362t-362 150t-362-150T0 512t150-362q25-25 51.5-46t55-37.5t59-29t62-21T443 4t69-4q212 0 362 150t150 362zm-64 0q0-186-131-317T512 64T195 195T64 512t131 318t317 132t317-132t131-318z" fill="#888888"/><rect x="0" y="0" width="1024" height="1024" fill="rgba(0, 0, 0, 0)" /></svg></a></li>';
		endif;

		$whatsapp_url = get_theme_mod( 'gmr_whatsapp_url_icon' );
		if ( $whatsapp_url ) :
			echo '<li><a href="' . esc_url( $whatsapp_url ) . '" title="' . esc_html__( 'WhatsApp', 'wpmedia' ) . '" class="whatsapp" target="_blank" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="vertical-align: -0.125em;-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveAspectRatio="xMidYMid meet" viewBox="0 0 512 512"><path d="M414.73 97.1A222.14 222.14 0 0 0 256.94 32C134 32 33.92 131.58 33.87 254a220.61 220.61 0 0 0 29.78 111L32 480l118.25-30.87a223.63 223.63 0 0 0 106.6 27h.09c122.93 0 223-99.59 223.06-222A220.18 220.18 0 0 0 414.73 97.1zM256.94 438.66h-.08a185.75 185.75 0 0 1-94.36-25.72l-6.77-4l-70.17 18.32l18.73-68.09l-4.41-7A183.46 183.46 0 0 1 71.53 254c0-101.73 83.21-184.5 185.48-184.5a185 185 0 0 1 185.33 184.64c-.04 101.74-83.21 184.52-185.4 184.52zm101.69-138.19c-5.57-2.78-33-16.2-38.08-18.05s-8.83-2.78-12.54 2.78s-14.4 18-17.65 21.75s-6.5 4.16-12.07 1.38s-23.54-8.63-44.83-27.53c-16.57-14.71-27.75-32.87-31-38.42s-.35-8.56 2.44-11.32c2.51-2.49 5.57-6.48 8.36-9.72s3.72-5.56 5.57-9.26s.93-6.94-.46-9.71s-12.54-30.08-17.18-41.19c-4.53-10.82-9.12-9.35-12.54-9.52c-3.25-.16-7-.2-10.69-.2a20.53 20.53 0 0 0-14.86 6.94c-5.11 5.56-19.51 19-19.51 46.28s20 53.68 22.76 57.38s39.3 59.73 95.21 83.76a323.11 323.11 0 0 0 31.78 11.68c13.35 4.22 25.5 3.63 35.1 2.2c10.71-1.59 33-13.42 37.63-26.38s4.64-24.06 3.25-26.37s-5.11-3.71-10.69-6.48z" fill-rule="evenodd" fill="#888888"/><rect x="0" y="0" width="512" height="512" fill="rgba(0, 0, 0, 0)" /></svg></a></li>';
		endif;

		$tiktok_url = get_theme_mod( 'gmr_tiktok_url_icon' );
		if ( $tiktok_url ) :
			echo '<li><a href="' . esc_url( $tiktok_url ) . '" title="' . esc_html__( 'TikTok', 'wpmedia' ) . '" class="tiktok" target="_blank" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><path d="M16.6 5.82s.51.5 0 0A4.278 4.278 0 0 1 15.54 3h-3.09v12.4a2.592 2.592 0 0 1-2.59 2.5c-1.42 0-2.6-1.16-2.6-2.6c0-1.72 1.66-3.01 3.37-2.48V9.66c-3.45-.46-6.47 2.22-6.47 5.64c0 3.33 2.76 5.7 5.69 5.7c3.14 0 5.69-2.55 5.69-5.7V9.01a7.35 7.35 0 0 0 4.3 1.38V7.3s-1.88.09-3.24-1.48z" fill="currentColor"/></svg></a></li>';
		endif;

		$telegram_url = get_theme_mod( 'gmr_telegram_url_icon' );
		if ( $telegram_url ) :
			echo '<li><a href="' . esc_url( $telegram_url ) . '" title="' . esc_html__( 'Telegram', 'wpmedia' ) . '" class="telegram" target="_blank" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 256 256"><path d="M231.256 31.736a15.964 15.964 0 0 0-16.29-2.767L30.409 101.474a16 16 0 0 0 2.712 30.58L80 141.432v58.553a15.994 15.994 0 0 0 27.313 11.314l25.944-25.943l39.376 34.65a15.869 15.869 0 0 0 10.517 4.004a16.154 16.154 0 0 0 4.963-.787a15.865 15.865 0 0 0 10.685-11.654l37.614-164.132a15.96 15.96 0 0 0-5.156-15.7zm-145.11 94.607l-49.885-9.977L175.942 61.49zM96 199.977v-47.408l25.22 22.193zm87.202 8.017l-82.392-72.506l118.645-85.687z" fill="currentColor"/></svg></a></li>';
		endif;

		$soundcloud_url = get_theme_mod( 'gmr_soundcloud_url_icon' );
		if ( $soundcloud_url ) :
			echo '<li><a href="' . esc_url( $soundcloud_url ) . '" title="' . esc_html__( 'Soundcloud', 'wpmedia' ) . '" class="soundcloud" target="_blank" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1.15em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 896"><path d="M1022 514q0 66-47 112.5T862 673h-63q-14 0-23-9t-9-23q0-3 .5-5.5t1.5-5t2.5-5t3-4.5t3.5-4t4.5-3l5-2l5.5-1.5l6-.5h63q26 0 48-13t35-35t13-48q0-16-5-30.5t-13.5-26T919 437t-26.5-14t-30.5-5q-20 0-38.5-8T792 388t-20-33v-1q-13-34-37-62t-57.5-44.5T606 228q-9 0-15.5 4.5T580 244t-4 15v382q0 7-2.5 12.5t-7 10t-10.5 7t-12 2.5q-13 0-22.5-9.5T512 641V259q0-15 5-29.5t13.5-26t20-20.5t26-14t30.5-5q77 4 138 50.5T831 332l1 1q7 22 30 22h7q64 2 108.5 48.5T1022 514zM416.5 673q-13.5 0-22.5-9t-9-23V291q0-13 9-22.5t22.5-9.5t22.5 9.5t9 22.5v350q0 13-9 22.5t-22.5 9.5zM289 673q-13 0-22.5-9t-9.5-23V275q0-13 9.5-22.5T289 243q8 0 15.5 4t12 11.5T321 275v366q0 13-9.5 22.5T289 673zm-128 0q-5 0-10-1.5t-8.5-4.5t-6.5-7t-4.5-8.5T130 641V386q0-4 1-8t3-7.5t5-6.5t6.5-5t7.5-3t8-1q14 0 23 9t9 22v255q0 13-9 22.5t-23 9.5zM34 609q-13 0-22.5-9T2 578V450q0-13 9.5-22.5T34 418q9 0 16 4.5t11.5 12T66 450v128q0 13-9.5 22T34 609zm637 0q13 0 22.5 9.5T703 641t-9.5 22.5T671 673q-8 0-15.5-4.5t-12-11.5t-4.5-15.5t4.5-16t12-12T671 609z" fill="currentColor"/></svg></a></li>';
		endif;

		$dailymotion_url = get_theme_mod( 'gmr_dailymotion_url_icon' );
		if ( $dailymotion_url ) :
			echo '<li><a href="' . esc_url( $dailymotion_url ) . '" title="' . esc_html__( 'Dailymotion', 'wpmedia' ) . '" class="dailymotion" target="_blank" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><path fill="currentColor" d="M14.068 11.313h-.023a3.1 3.1 0 1 0 .183 6.195h-.024a2.969 2.969 0 0 0 2.926-2.968l-.001-.076v.004l.002-.103a3.054 3.054 0 0 0-3.054-3.054h-.01h.001z"/><path fill="currentColor" d="M0 0v24h24V0zm20.693 20.807h-3.576V19.4a4.837 4.837 0 0 1-3.727 1.47h.011l-.104.001a5.646 5.646 0 0 1-3.83-1.49l.004.004A6.357 6.357 0 0 1 7.27 14.57l.001-.127v-.03a6.34 6.34 0 0 1 2.007-4.635l.003-.003a5.815 5.815 0 0 1 4.147-1.73h.041h-.002a4.186 4.186 0 0 1 3.526 1.578l.007.009V4.157l3.693-.765z"/></svg></a></li>';
		endif;

		// Disable rss icon via customizer.
		$rssicon = get_theme_mod( 'gmr_active-rssicon', 0 );
		if ( 0 === $rssicon ) :
			echo '<li><a href="' . esc_url( get_bloginfo( 'rss2_url' ) ) . '" title="' . esc_html__( 'RSS', 'wpmedia' ) . '" class="rss" target="_blank" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="vertical-align: -0.125em;-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><path d="M5.996 19.97a1.996 1.996 0 1 1 0-3.992a1.996 1.996 0 0 1 0 3.992zm-.876-7.993a.998.998 0 0 1-.247-1.98a8.103 8.103 0 0 1 9.108 8.04v.935a.998.998 0 1 1-1.996 0v-.934a6.108 6.108 0 0 0-6.865-6.06zM4 5.065a.998.998 0 0 1 .93-1.063c7.787-.519 14.518 5.372 15.037 13.158c.042.626.042 1.254 0 1.88a.998.998 0 1 1-1.992-.133c.036-.538.036-1.077 0-1.614c-.445-6.686-6.225-11.745-12.91-11.299A.998.998 0 0 1 4 5.064z" fill="#888888"/><rect x="0" y="0" width="24" height="24" fill="rgba(0, 0, 0, 0)" /></svg></a></li>';
		endif;
	}
endif; /* endif wpmedia_list_social */
add_action( 'social_icon', 'wpmedia_list_social', 5 );

if ( ! function_exists( 'wpmedia_topnav_icon' ) ) :
	/**
	 * This function add dark menu icon and other icon.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function wpmedia_topnav_icon() {
		// Option remove search button.
		$setting    = 'gmr_active-searchbutton';
		$mod_search = get_theme_mod( $setting, customizer_library_get_default( $setting ) );
		if ( 0 === $mod_search ) {
			echo '<div class="gmr-search desktop-only">
				<form method="get" class="gmr-searchform searchform" action="' . esc_url( home_url( '/' ) ) . '">
					<input type="text" name="s" id="s" placeholder="' . esc_html__( 'Search', 'wpmedia' ) . '" />
					<input type="hidden" name="post_type[]" value="post" />
					<button type="submit" role="button" class="gmr-search-submit gmr-search-icon" aria-label="' . esc_html__( 'Submit', 'wpmedia' ) . '">
						<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M20.94 11c-.46-4.17-3.77-7.48-7.94-7.94V1h-2v2.06C6.83 3.52 3.52 6.83 3.06 11H1v2h2.06c.46 4.17 3.77 7.48 7.94 7.94V23h2v-2.06c4.17-.46 7.48-3.77 7.94-7.94H23v-2h-2.06zM12 19c-3.87 0-7-3.13-7-7s3.13-7 7-7 7 3.13 7 7-3.13 7-7 7z"/></svg>
					</button>
				</form>
			</div>';
		}
		if ( ! wpmedia_is_amp() ) {
			// Dark Mode.
			$darkmodebuttondisable = get_theme_mod( 'gmr_active-darkmode', 0 );
			if ( 0 === $darkmodebuttondisable ) {
				echo '<button role="button" class="darkmode-button topnav-button" aria-label="' . esc_html__( 'Dark Mode', 'wpmedia' ) . '">';
				echo '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M20 8.69V4h-4.69L12 .69 8.69 4H4v4.69L.69 12 4 15.31V20h4.69L12 23.31 15.31 20H20v-4.69L23.31 12 20 8.69zm-2 5.79V18h-3.52L12 20.48 9.52 18H6v-3.52L3.52 12 6 9.52V6h3.52L12 3.52 14.48 6H18v3.52L20.48 12 18 14.48zM12.29 7c-.74 0-1.45.17-2.08.46 1.72.79 2.92 2.53 2.92 4.54s-1.2 3.75-2.92 4.54c.63.29 1.34.46 2.08.46 2.76 0 5-2.24 5-5s-2.24-5-5-5z"/></svg>';
				echo '</button>';
			}
		}
		if ( has_nav_menu( 'menu-2' ) ) {
			$mod       = get_theme_mod( 'gmr_secondmenu_layout', 'col-1' );
			$addlayout = '';
			if ( 'col-2' === $mod ) {
				$addlayout = ' col-2';
			}
			echo '<div class="gmr-menugrid-btn gmrclick-container">';
			if ( wpmedia_is_amp() ) {
				echo '<amp-state id="navMenuSecondExpanded">
					<script type="application/json">false</script>
				</amp-state>
				<button id="search-menu-button" role="button" class="topnav-button gmrbtnclick" on="tap:AMP.setState( { navMenuSecondExpanded: ! navMenuSecondExpanded } )" [class]="\'topnav-button\' + ( navMenuSecondExpanded ? \' toggled-on\' : \'\' )" aria-label="' . esc_html__( 'Submit', 'wpmedia' ) . '" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 24 24" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><g><rect fill="none" height="24" width="24"/></g><g><g><path d="M5,11h4c1.1,0,2-0.9,2-2V5c0-1.1-0.9-2-2-2H5C3.9,3,3,3.9,3,5v4C3,10.1,3.9,11,5,11z"/><path d="M5,21h4c1.1,0,2-0.9,2-2v-4c0-1.1-0.9-2-2-2H5c-1.1,0-2,0.9-2,2v4C3,20.1,3.9,21,5,21z"/><path d="M13,5v4c0,1.1,0.9,2,2,2h4c1.1,0,2-0.9,2-2V5c0-1.1-0.9-2-2-2h-4C13.9,3,13,3.9,13,5z"/><path d="M15,21h4c1.1,0,2-0.9,2-2v-4c0-1.1-0.9-2-2-2h-4c-1.1,0-2,0.9-2,2v4C13,20.1,13.9,21,15,21z"/></g></g></svg></button>
				<div [class]="\'hidesearch gmr-secondmenu-dropdown gmr-dropdown' . esc_html( $addlayout ) . '\' + ( navMenuSecondExpanded ? \' toggled-on\' : \'\' )" id="dropdown-container" class="hidesearch gmr-secondmenu-dropdown gmr-dropdown' . esc_html( $addlayout ) . '">';
					wp_nav_menu(
						array(
							'theme_location' => 'menu-2',
							'container'      => 'ul',
							'menu_id'        => 'secondary-menu',
							'depth'          => 1,
						)
					);
				echo '</div>';
			} else {
				echo '<button id="menugrid-button" class="topnav-button gmrbtnclick" aria-label="' . esc_html__( 'Open Menu', 'wpmedia' ) . '"><svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 24 24" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><g><rect fill="none" height="24" width="24"/></g><g><g><path d="M5,11h4c1.1,0,2-0.9,2-2V5c0-1.1-0.9-2-2-2H5C3.9,3,3,3.9,3,5v4C3,10.1,3.9,11,5,11z"/><path d="M5,21h4c1.1,0,2-0.9,2-2v-4c0-1.1-0.9-2-2-2H5c-1.1,0-2,0.9-2,2v4C3,20.1,3.9,21,5,21z"/><path d="M13,5v4c0,1.1,0.9,2,2,2h4c1.1,0,2-0.9,2-2V5c0-1.1-0.9-2-2-2h-4C13.9,3,13,3.9,13,5z"/><path d="M15,21h4c1.1,0,2-0.9,2-2v-4c0-1.1-0.9-2-2-2h-4c-1.1,0-2,0.9-2,2v4C13,20.1,13.9,21,15,21z"/></g></g></svg></button>';
				echo '<div id="dropdown-container" class="gmr-secondmenu-dropdown gmr-dropdown' . esc_html( $addlayout ) . '">';
					wp_nav_menu(
						array(
							'theme_location' => 'menu-2',
							'container'      => 'ul',
							'menu_id'        => 'secondary-menu',
							'depth'          => 1,
						)
					);
				echo '</div>';
			}
			echo '</div>';
		}
	}
endif; /* endif wpmedia_topnav_icon */
add_action( 'wpmedia_topnav_icon', 'wpmedia_topnav_icon', 10 );
