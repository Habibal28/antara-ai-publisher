<?php
/**
 * Add functionally oembed metaboxes
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Wpmedia
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register a meta box using a class.
 *
 * @since 1.0.0
 */
class Wpmedia_Category_Options {
	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'admin_footer', array( $this, 'wpmedia_admin_add_scripts' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'wpmedia_admin_enqueue_scripts' ) );
		add_action( 'category_add_form_fields', array( $this, 'wpmedia_field_add_new_category' ) );
		add_action( 'category_edit_form_fields', array( $this, 'wpmedia_field_edit_category' ) );
		add_action( 'created_category', array( $this, 'wpmedia_save_termmeta' ) );
		add_action( 'edited_category', array( $this, 'wpmedia_save_termmeta' ) );
	}

	/**
	 * Register the JavaScript.
	 */
	public function wpmedia_admin_enqueue_scripts() {
		$screen = get_current_screen();
		if ( null !== $screen && 'edit-category' !== $screen->id ) {
			return;
		}
		// Colorpicker Scripts.
		wp_enqueue_script( 'wp-color-picker' );

		// Colorpicker Styles.
		wp_enqueue_style( 'wp-color-picker' );
	}

	/**
	 * Register the JavaScript.
	 */
	public function wpmedia_admin_add_scripts() {
		$screen = get_current_screen();
		if ( null !== $screen && 'edit-category' !== $screen->id ) {
			return;
		}
		?>
		<script type="text/javascript">
			(function( $ ) {
				'use strict';
				/**
				 * From this point every thing related to metabox
				 */
				$('document').ready(function(){
					$( '.colorpicker' ).wpColorPicker();
				});
			})( jQuery );
		</script>
		<?php
	}

	/**
	 * Add new colorpicker field to "Add new Category" screen
	 * https://developer.wordpress.org/reference/hooks/taxonomy_add_form_fields/
	 *
	 * @param string $taxonomy taxonomy.
	 *
	 * @return void
	 */
	public function wpmedia_field_add_new_category( $taxonomy ) {
		?>
		<div class="form-field term-colorpicker-wrap">
			<label for="term-colorpicker"><?php echo esc_attr__( 'Category Color', 'wpmedia' ); ?></label>
			<?php wp_nonce_field( 'idt-colorcat', 'idt-colorcat-nonce' ); ?>
			<input name="_idt_category_color" value="" class="colorpicker" id="idt-category-color" />
			<p><?php echo esc_attr__( 'Add color to category button', 'wpmedia' ); ?></p>
		</div>
		<?php
	}

	/**
	 * Add new colopicker field to "Edit Category" screen
	 * - https://developer.wordpress.org/reference/hooks/taxonomy_add_form_fields/
	 *
	 * @param WP_Term_Object $term Term.
	 *
	 * @return void
	 */
	public function wpmedia_field_edit_category( $term ) {
		$color = get_term_meta( $term->term_id, '_idt_category_color', true );
		$color = ( ! empty( $color ) ) ? esc_attr( $color ) : '';
		?>
		<tr class="form-field term-colorpicker-wrap">
			<th scope="row"><label for="term-colorpicker"><?php echo esc_attr__( 'Category Color', 'wpmedia' ); ?></label></th>
			<td>
				<?php wp_nonce_field( 'idt-colorcat', 'idt-colorcat-nonce' ); ?>
				<input name="_idt_category_color" value="<?php echo esc_attr( $color ); ?>" class="colorpicker" id="idt-category-color" />
				<p class="desciption"><?php echo esc_attr__( 'Add color to category button', 'wpmedia' ); ?></p>
			</td>
		</tr>
		<?php
	}
	/**
	 * Term Metadata - Save Created and Edited Term Metadata
	 * - https://developer.wordpress.org/reference/hooks/created_taxonomy/
	 * - https://developer.wordpress.org/reference/hooks/edited_taxonomy/
	 *
	 * @param integer $term_id term id.
	 *
	 * @return void
	 */
	public function wpmedia_save_termmeta( $term_id ) {

		if ( ! isset( $_POST['idt-colorcat-nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['idt-colorcat-nonce'] ), 'idt-colorcat' ) ) {
			return;
		}

		// Save term color if possible.
		if ( isset( $_POST['_idt_category_color'] ) && ! empty( $_POST['_idt_category_color'] ) ) {
			update_term_meta( $term_id, '_idt_category_color', sanitize_hex_color( wp_unslash( $_POST['_idt_category_color'] ) ) );
		} else {
			delete_term_meta( $term_id, '_idt_category_color' );
		}

	}

}

/* Load only if dashboard */
if ( is_admin() ) {
	new Wpmedia_Category_Options();
}
