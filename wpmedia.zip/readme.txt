=== WPMEDIA ===

Contributors: automattic, gianmr
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready


Theme called wpmedia.

== Description ==

Modern theme for indonesian media sites.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.0 - May 12 2015 =
* Initial release

== Credits ==

* Based on Underscores https://underscores.me/, (C) 2012-2020 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
