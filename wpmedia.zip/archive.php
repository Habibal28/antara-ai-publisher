<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package wpmedia
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$pg = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

?>

	<main id="primary" class="site-main col-md-8">

		<?php
		if ( have_posts() ) {
			?>
			<header class="page-header">
				<?php
				the_archive_title( '<h1 class="page-title sub-title">', '</h1>' );
				the_archive_description( '<div class="archive-description">', '</div>' );
				?>
			</header><!-- .page-header -->

			<?php
			/* display only on category, tag or taxonomy newstopic */
			if ( 1 === $pg ) {
				echo '<div class="idt-contentbig">';
				$counttop = 0;
				/* Start the Loop */
				while ( have_posts() ) :
					the_post();
					$counttop++;
					if ( $counttop > 0 && $counttop <= 1 ) {
						/**
						 * Include the Post-Type-specific template for the content.
						 * If you want to override this in a child theme, then include a file
						 * called content-___.php (where ___ is the Post Type name) and that will be used instead.
						 */
						get_template_part( 'template-parts/content-big', get_post_type() );

						do_action( 'wpmedia_banner_between_posts' );
					}
				endwhile;
				echo '</div>';
			}
			?>

			<?php

			echo '<div id="infinite-container">';
			/* Start the Loop */
			$countbottom = 0;
			while ( have_posts() ) :
				the_post();
				$countbottom++;
				if ( $countbottom > 1 ) {
					/*
						* Include the Post-Type-specific template for the content.
						* If you want to override this in a child theme, then include a file
						* called content-___.php (where ___ is the Post Type name) and that will be used instead.
						*/
					get_template_part( 'template-parts/content', get_post_format() );

					do_action( 'wpmedia_banner_between_posts' );

					if ( ! wpmedia_is_amp() && is_category() ) {
						if ( 6 === $countbottom && 1 === $pg ) {
							/* Home module */
							if ( is_active_sidebar( 'module-1' ) ) {
								echo '<div class="module-widget">';
								dynamic_sidebar( 'module-1' );
								echo '</div>';
							}
						}

						if ( 9 === $countbottom && 1 === $pg ) {
							/* Home module */
							if ( is_active_sidebar( 'module-2' ) ) {
								echo '<div class="module-widget">';
								dynamic_sidebar( 'module-2' );
								echo '</div>';
							}
						}
					}
				}

			endwhile;
			echo '</div>';

			$loadmore = get_theme_mod( 'gmr_blog_pagination', 'gmr-more' );
			if ( ( 'gmr-infinite' === $loadmore || 'gmr-more' === $loadmore ) && ! wpmedia_is_amp() ) {
				$class = 'inf-pagination';
			} else {
				$class = 'pagination';
			}

			the_posts_pagination(
				array(
					'class'     => esc_html( $class ),
					'mid_size'  => 1,
					'prev_text' => '&laquo; ' . esc_html__( 'Back', 'wpmedia' ),
					'next_text' => esc_html__( 'Next', 'wpmedia' ) . ' &raquo;',
				)
			);

			if ( ( 'gmr-infinite' === $loadmore || 'gmr-more' === $loadmore ) && ! wpmedia_is_amp() ) {
				echo '
				<div class="text-center">
					<div class="page-load-status">
						<div class="loader-ellips infinite-scroll-request gmr-ajax-load-wrapper gmr-loader">
							<div class="gmr-loaderwrap">
								<div class="gmr-ajax-loader">
									<div class="gmr-loader1"></div>
									<div class="gmr-loader2"></div>
									<div class="gmr-loader3"></div>
									<div class="gmr-loader4"></div>
								</div>
							</div>
						</div>
						<p class="infinite-scroll-last">' . esc_attr__( 'No More Posts Available.', 'wpmedia' ) . '</p>
						<p class="infinite-scroll-error">' . esc_attr__( 'No more pages to load.', 'wpmedia' ) . '</p>
					</div>';
				if ( 'gmr-more' === $loadmore ) {
					echo '<p><button class="view-more-button heading-text">' . esc_attr__( 'View More', 'wpmedia' ) . '</button></p>';
				}
				echo '</div>
				';
			}
		} else {
			get_template_part( 'template-parts/content', 'none' );

		}
		?>

	</main><!-- #main -->

<?php
get_sidebar();
get_footer();
