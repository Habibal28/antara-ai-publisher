<?php
/**
 * Template Name: Index Pages
 *
 * A WordPress template to list page titles by first letter.
 *
 * You should modify the CSS to suit your theme and place it in its proper file.
 * Be sure to set the $posts_per_row and $posts_per_page variables.
 *
 * @package wpmedia
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

global $paged;
$pg    = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
$today = getdate();
?>

<main id="primary" class="site-main col-md-8 page-index">

	<header class="page-header page-index">
		<?php the_title( '<h1 class="page-title">', '</h1>' ); ?>
	</header><!-- .entry-header -->
	<div class="gmr-filter-index clearfix">
		<form method="get" class="gmr-filterindex" action="<?php the_permalink(); ?>">
		<?php wp_dropdown_categories( 'show_option_none=Category&option_none_value=0' ); ?>
			<select id="dy" name="dy">
				<?php
				foreach ( range( 1, 31 ) as $number ) {
					echo '<option value="' . absint( $number ) . '">' . absint( $number ) . '</option>';
				}
				?>
			</select>
			<select id="mt" name="mt">
				<?php
				$months = array(
					1  => esc_html__( 'Jan.', 'wpmedia' ),
					2  => esc_html__( 'Feb.', 'wpmedia' ),
					3  => esc_html__( 'Mar.', 'wpmedia' ),
					4  => esc_html__( 'Apr.', 'wpmedia' ),
					5  => esc_html__( 'May', 'wpmedia' ),
					6  => esc_html__( 'Jun.', 'wpmedia' ),
					7  => esc_html__( 'Jul.', 'wpmedia' ),
					8  => esc_html__( 'Aug.', 'wpmedia' ),
					9  => esc_html__( 'Sep.', 'wpmedia' ),
					10 => esc_html__( 'Oct.', 'wpmedia' ),
					11 => esc_html__( 'Nov.', 'wpmedia' ),
					12 => esc_html__( 'Dec.', 'wpmedia' ),
				);
				foreach ( $months as $num => $name ) {
					echo '<option value="' . absint( $num ) . '">' . esc_html( $name ) . '</option>';
				}
				?>
			</select>
			<select id="yr" name="yr">
				<?php
				$curyear = date('Y'); // phpcs:ignore
				foreach ( range( $curyear, ( $curyear - 10 ) ) as $yr ) {
					echo '<option value="' . absint( $yr ) . '">' . absint( $yr ) . '</option>';
				}
				?>
			</select>
			<input type="submit" value="<?php echo esc_attr__( 'Filter', 'wpmedia' ); ?>" />
		</form>
	</div>
	<?php
	$default_posts_per_page = get_option( 'posts_per_page' );
	if ( isset( $_GET['cat'] ) && ! empty( $_GET['cat'] ) ) { /* phpcs:ignore */
		$cat = absint( $_GET['cat'] ); /* phpcs:ignore */
	} else {
		$cat = 0; /* phpcs:ignore */
	}
	$query_args = array(
		'post_type'      => 'post',
		'posts_per_page' => absint( $default_posts_per_page ), /* phpcs:ignore */
		'cat'            => absint( $cat ),
		'post_status'    => 'publish',
		'paged'          => absint( $paged ),
		'orderby'        => 'date',
	);
	/* Get date query */
	if ( isset( $_GET['dy'] ) && ! empty( $_GET['dy'] ) && isset( $_GET['mt'] ) && ! empty( $_GET['mt'] ) && isset( $_GET['yr'] ) && ! empty( $_GET['yr'] ) ) { /* phpcs:ignore */
		if ( isset( $_GET['dy'] ) && ! empty( $_GET['dy'] ) ) { /* phpcs:ignore */
			$qday = absint( $_GET['dy'] ); /* phpcs:ignore */
		} else {
			$qday = absint( date_i18n( 'd' ) );
		}
		if ( isset( $_GET['mt'] ) && ! empty( $_GET['mt'] ) ) { /* phpcs:ignore */
			$qmonth = absint( $_GET['mt'] ); /* phpcs:ignore */
		} else {
			$qmonth = absint( date_i18n( 'n' ) );
		}
		if ( isset( $_GET['yr'] ) && ! empty( $_GET['yr'] ) ) { /* phpcs:ignore */
			$qyear = absint( $_GET['yr'] ); /* phpcs:ignore */
		} else {
			$qyear = absint( date_i18n( 'Y' ) );
		}
		$query_args['date_query'] = array(
			array(
				'day'   => absint( $qday ),
				'month' => absint( $qmonth ),
				'year'  => absint( $qyear ),
			),
		);
	}
	$rp = new WP_Query( apply_filters( 'pageindex_posts_args', $query_args ) );
	global $wp_query;
	// Put default query object in a temp variable.
	$tmp_query = $wp_query;
	// Now wipe it out completely.
	$wp_query = null; /* phpcs:ignore */
	// Re-populate the global with our custom query.
	$wp_query = $rp; /* phpcs:ignore */
	if ( $rp->have_posts() ) {
		/* Start the Loop */
		echo '<div id="infinite-container">';
		while ( $rp->have_posts() ) :
			$rp->the_post();

			/*
				* Include the Post-Type-specific template for the content.
				* If you want to override this in a child theme, then include a file
				* called content-___.php (where ___ is the Post Type name) and that will be used instead.
				*/
			get_template_part( 'template-parts/content', get_post_format() );

			do_action( 'wpmedia_banner_between_posts' );

		endwhile;
		echo '</div>';

		$loadmore = get_theme_mod( 'gmr_blog_pagination', 'gmr-more' );
		if ( ( 'gmr-infinite' === $loadmore || 'gmr-more' === $loadmore ) && ! wpmedia_is_amp() ) {
			$class = 'inf-pagination';
		} else {
			$class = 'pagination';
		}

		the_posts_pagination(
			array(
				'class'     => esc_html( $class ),
				'mid_size'  => 1,
				'prev_text' => '&laquo; ' . esc_html__( 'Back', 'wpmedia' ),
				'next_text' => esc_html__( 'Next', 'wpmedia' ) . ' &raquo;',
			)
		);

		if ( ( 'gmr-infinite' === $loadmore || 'gmr-more' === $loadmore ) && ! wpmedia_is_amp() ) {
			echo '
			<div class="text-center">
				<div class="page-load-status">
					<div class="loader-ellips infinite-scroll-request gmr-ajax-load-wrapper gmr-loader">
						<div class="gmr-loaderwrap">
							<div class="gmr-ajax-loader">
								<div class="gmr-loader1"></div>
								<div class="gmr-loader2"></div>
								<div class="gmr-loader3"></div>
								<div class="gmr-loader4"></div>
							</div>
						</div>
					</div>
					<p class="infinite-scroll-last">' . esc_attr__( 'No More Posts Available.', 'wpmedia' ) . '</p>
					<p class="infinite-scroll-error">' . esc_attr__( 'No more pages to load.', 'wpmedia' ) . '</p>
				</div>';
			if ( 'gmr-more' === $loadmore ) {
				echo '<p><button class="view-more-button heading-text">' . esc_attr__( 'View More', 'wpmedia' ) . '</button></p>';
			}
			echo '</div>
			';
		}
		wp_reset_postdata();
	} else {
		?>
		<section class="no-results not-found">
			<header class="page-header">
				<h1 class="page-title"><?php esc_attr_e( 'Nothing Found', 'wpmedia' ); ?></h1>
			</header><!-- .page-header -->

			<div class="page-content">
				<p><?php esc_attr_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'wpmedia' ); ?></p>
			</div><!-- .page-content -->
		</section><!-- .no-results -->
		<?php
	}
	// Restore original query object.
	$wp_query = null; /* phpcs:ignore */
	$wp_query = $tmp_query; /* phpcs:ignore */
	?>
</main><!-- #main -->
<?php
get_sidebar();
get_footer();
