<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package wpmedia
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'wpmedia' ); ?></a>
	<?php do_action( 'wpmedia_topbanner_verytop' ); ?>
	<div id="page" class="site">
		<div id="topnavwrap" class="gmr-topnavwrap clearfix">
			<div class="container">
				<header id="masthead" class="list-flex site-header">
					<div class="row-flex gmr-navleft">
						<div class="site-branding">
							<?php
							echo '<div class="gmr-logo">';
								do_action( 'wpmedia_logo' );
							echo '</div>';
							?>
						</div><!-- .site-branding -->
					</div>

					<div class="row-flex gmr-navright">
						<?php
						$activedate = get_theme_mod( 'gmr_active-date', 0 );
						if ( 0 === $activedate ) {
							echo '<span class="gmr-top-date" data-lang="' . esc_html( get_bloginfo( 'language' ) ) . '"></span>';
						}
						do_action( 'wpmedia_topnav_icon' );

						if ( ! wpmedia_is_amp() ) {
							echo '<button id="gmr-responsive-menu" role="button" class="mobile-only" aria-label="' . esc_html__( 'Menus', 'wpmedia' ) . '" data-target="#gmr-sidemenu-id" data-toggle="onoffcanvas" aria-expanded="false" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="m19.31 18.9l3.08 3.1L21 23.39l-3.12-3.07c-.69.43-1.51.68-2.38.68c-2.5 0-4.5-2-4.5-4.5s2-4.5 4.5-4.5s4.5 2 4.5 4.5c0 .88-.25 1.71-.69 2.4m-3.81.1a2.5 2.5 0 0 0 0-5a2.5 2.5 0 0 0 0 5M21 4v2H3V4h18M3 16v-2h6v2H3m0-5V9h18v2h-2.03c-1.01-.63-2.2-1-3.47-1s-2.46.37-3.47 1H3Z"/></svg></button>';
						} else {
							echo '<amp-state id="navMenuExpanded">';
									echo '<script type="application/json">false</script>';
							echo '</amp-state>';
							echo '<button id="gmr-responsive-menu" role="button" class="menu-toggle" aria-label="' . esc_html__( 'Menus', 'wpmedia' ) . '" on="tap:AMP.setState( { navMenuExpanded: ! navMenuExpanded } )" [class]="\'menu-toggle\' + ( navMenuExpanded ? \' toggled-on\' : \'\' )" aria-expanded="false" [aria-expanded]="navMenuExpanded ? \'true\' : \'false\'"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="m19.31 18.9l3.08 3.1L21 23.39l-3.12-3.07c-.69.43-1.51.68-2.38.68c-2.5 0-4.5-2-4.5-4.5s2-4.5 4.5-4.5s4.5 2 4.5 4.5c0 .88-.25 1.71-.69 2.4m-3.81.1a2.5 2.5 0 0 0 0-5a2.5 2.5 0 0 0 0 5M21 4v2H3V4h18M3 16v-2h6v2H3m0-5V9h18v2h-2.03c-1.01-.63-2.2-1-3.47-1s-2.46.37-3.47 1H3Z"/></svg></button>';
						}
						?>
					</div>
				</header>
			</div><!-- .container -->
			<nav id="main-nav" class="main-navigation gmr-mainmenu">
				<div class="container">
					<?php
					wp_nav_menu(
						array(
							'theme_location' => 'menu-1',
							'container'      => 'ul',
							'menu_id'        => 'primary-menu',
							'link_before'    => '<span>',
							'link_after'     => '</span>',
						)
					);
					?>
				</div>
			</nav><!-- #main-nav -->
		</div><!-- #topnavwrap -->

		<?php do_action( 'wpmedia_floating_banner_left' ); ?>
		<?php do_action( 'wpmedia_floating_banner_right' ); ?>

		<?php
		$mod   = get_theme_mod( 'gmr_notif_marquee', 'recentpost' );
		$notif = get_theme_mod( 'gmr_textnotif' );

		if ( ! is_single() && ! is_page() && 'disable' !== $mod ) {
			?>
			<div class="container">
				<div class="gmr-topnotification">
					<div class="list-flex">
						<div class="row-flex text-marquee heading-text">
							<?php
							$textmarquee = get_theme_mod( 'gmr_textmarquee' );
							if ( $textmarquee ) :
								/* sanitize html output */
								echo esc_html( $textmarquee );
							else :
								echo esc_html__( 'Breaking News', 'wpmedia' );
							endif;
							?>
						</div>

						<div class="row-flex wrap-marquee">
							<div class="row-flex marquee">
							<?php
							if ( 'recentpost' === $mod ) {
								do_action( 'wpmedia_recentpost_marquee' );
							} else {
								if ( isset( $notif ) && ! empty( $notif ) ) {
									echo do_shortcode( $notif );
								}
							}
							?>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php
		}
		?>

		<?php do_action( 'wpmedia_topbanner_aftermenu' ); ?>

		<div id="content" class="gmr-content">
			<div class="container">
				<div class="row">
