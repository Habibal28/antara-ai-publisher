<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package wpmedia
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$pg = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

?>

	<main id="primary" class="site-main col-md-12">
		<div class="row">
			<div class="col-md-8">
			<?php
			/* Home module */
			if ( ! wpmedia_is_amp() ) {
				$modulehome = get_theme_mod( 'gmr_active-module-home', 0 );
				if ( 0 === $modulehome ) {
					if ( 1 === $pg ) {
						do_action( 'wpmedia_display_modulehome' );
					}
				}
			}
			if ( have_posts() ) {
				echo '<header class="page-header">';
				echo '<h3 class="page-title sub-title">';
				$textrecentnews = get_theme_mod( 'gmr_textrecentnews' );
				if ( $textrecentnews ) :
					/* sanitize html output */
					echo esc_html( $textrecentnews );
				else :
					echo esc_html__( 'Recent News', 'wpmedia' );
				endif;
				echo '</h3>';
				echo '</header>';
			}

			$counttop = 0;
			/* Start the Loop */
			while ( have_posts() ) :
				the_post();
				$counttop++;
				if ( $counttop > 0 && $counttop <= 3 ) {
					/**
					 * Include the Post-Type-specific template for the content.
					 * If you want to override this in a child theme, then include a file
					 * called content-___.php (where ___ is the Post Type name) and that will be used instead.
					 */
					get_template_part( 'template-parts/content', get_post_type() );

					do_action( 'wpmedia_banner_between_posts' );
				}
			endwhile;
			if ( is_home() && ! is_front_page() ) :
				?>
					<h1 class="page-title sub-title screen-reader-text"><?php single_post_title(); ?></h1>
				<?php
			endif;
			if ( is_front_page() && is_home() ) :
				?>
					<h1 class="page-title sub-title screen-reader-text"><?php bloginfo( 'name' ); ?></h1>
				<?php
			endif;
			if ( is_active_sidebar( 'sidebar-home' ) && 1 === $pg ) {
				?>
			</div>
				<?php get_sidebar( 'home' ); ?>
		</div>
				<?php
			}
				/* Home module */
			if ( is_active_sidebar( 'module-fullwidth' ) && 1 === $pg && ! wpmedia_is_amp() ) {
				echo '<div class="row">';
					echo '<div class="col-md-12">';
					dynamic_sidebar( 'module-fullwidth' );
					echo '</div>';
				echo '</div>';
			}
			if ( is_active_sidebar( 'sidebar-home' ) && 1 === $pg ) {
				?>
		<div class="row">
		<div class="col-md-8">
				<?php
			}
			if ( have_posts() ) {

				echo '<div id="infinite-container">';
				/* Start the Loop */
				$countbottom = 0;
				while ( have_posts() ) :
					the_post();
					$countbottom++;
					if ( $countbottom > 3 ) {
						/**
						 * Include the Post-Type-specific template for the content.
						 * If you want to override this in a child theme, then include a file
						 * called content-___.php (where ___ is the Post Type name) and that will be used instead.
						 */
						get_template_part( 'template-parts/content', get_post_type() );

						do_action( 'wpmedia_banner_between_posts' );

						if ( ! wpmedia_is_amp() ) {
							if ( 6 === $countbottom && 1 === $pg ) {
								/* Home module */
								if ( is_active_sidebar( 'module-1' ) ) {
									echo '<div class="module-widget">';
									dynamic_sidebar( 'module-1' );
									echo '</div>';
								}
							}

							if ( 9 === $countbottom && 1 === $pg ) {
								/* Home module */
								if ( is_active_sidebar( 'module-2' ) ) {
									echo '<div class="module-widget">';
									dynamic_sidebar( 'module-2' );
									echo '</div>';
								}
							}
						}
					}

				endwhile;
				echo '</div>';

				$loadmore = get_theme_mod( 'gmr_blog_pagination', 'gmr-more' );
				if ( ( 'gmr-infinite' === $loadmore || 'gmr-more' === $loadmore ) && ! wpmedia_is_amp() ) {
					$class = 'inf-pagination';
				} else {
					$class = 'pagination';
				}

				the_posts_pagination(
					array(
						'class'     => esc_html( $class ),
						'mid_size'  => 1,
						'prev_text' => '&laquo; ' . esc_html__( 'Back', 'wpmedia' ),
						'next_text' => esc_html__( 'Next', 'wpmedia' ) . ' &raquo;',
					)
				);

				if ( ( 'gmr-infinite' === $loadmore || 'gmr-more' === $loadmore ) && ! wpmedia_is_amp() ) {
					echo '
					<div class="text-center">
						<div class="page-load-status">
							<div class="loader-ellips infinite-scroll-request gmr-ajax-load-wrapper gmr-loader">
								<div class="gmr-loaderwrap">
									<div class="gmr-ajax-loader">
										<div class="gmr-loader1"></div>
										<div class="gmr-loader2"></div>
										<div class="gmr-loader3"></div>
										<div class="gmr-loader4"></div>
									</div>
								</div>
							</div>
							<p class="infinite-scroll-last">' . esc_attr__( 'No More Posts Available.', 'wpmedia' ) . '</p>
							<p class="infinite-scroll-error">' . esc_attr__( 'No more pages to load.', 'wpmedia' ) . '</p>
						</div>';
					if ( 'gmr-more' === $loadmore ) {
						echo '<p><button class="view-more-button heading-text">' . esc_attr__( 'View More', 'wpmedia' ) . '</button></p>';
					}
					echo '</div>
					';
				}
			} else {

				get_template_part( 'template-parts/content', 'none' );

			}
			?>
			</div>
			<?php get_sidebar(); ?>
		</div>
	</main><!-- #main -->

<?php
get_footer();
