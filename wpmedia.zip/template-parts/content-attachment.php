<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package wpmedia
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$postparentid = absint( $post->post_parent );

?>

<article id="post-attachment" class="post type-post hentry content-single">
<?php do_action( 'wpmedia_view_breadcrumbs' ); ?>
	<header class="entry-header entry-header-single">
		<?php
		wpmedia_category( $postparentid );
		the_title( '<h1 class="entry-title"><strong>', '</strong></h1>' );

		echo '<div class="list-flex clearfix">';

		echo '<div class="gmr-gravatar-metasingle">';
		$author_id = $post->post_author;
		echo '<a class="url" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '" title="' . esc_html__( 'Permalink to: ', 'wpmedia' ) . esc_html( get_the_author() ) . '">';
			echo get_avatar( get_the_author_meta( 'user_email', $author_id ), '40', '', '', array( 'class' => 'img-cicle' ) );
		echo '</a>';
		echo '</div>';

		echo '<div class="gmr-content-metasingle">';
		echo '<div class="meta-content">';
		$byline = sprintf(
			/* translators: %s: post author. */
			'%s',
			'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '" title="' . esc_html( get_the_author() ) . '">' . esc_html( get_the_author() ) . '</a></span>'
		);
		echo $byline; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		wpmedia_reading_time();
		echo '</div>';
		echo '<div class="meta-content">';
		wpmedia_posted_on();
		echo '</div>';
		echo '</div>';


		echo '<div class="gmr-content-share list-right">';
		if ( class_exists( 'WP_Widget_PostViews' ) ) {
			if ( function_exists( 'the_views' ) ) {
				$post_views = get_post_meta( absint( get_the_ID() ), 'views', true );
				echo '<div class="gmr-iconnotif">';
				echo '<div class="gmr-iconnotif-wrap">';
				echo '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M12 6c3.79 0 7.17 2.13 8.82 5.5C19.17 14.87 15.79 17 12 17s-7.17-2.13-8.82-5.5C4.83 8.13 8.21 6 12 6m0-2C7 4 2.73 7.11 1 11.5 2.73 15.89 7 19 12 19s9.27-3.11 11-7.5C21.27 7.11 17 4 12 4zm0 5c1.38 0 2.5 1.12 2.5 2.5S13.38 14 12 14s-2.5-1.12-2.5-2.5S10.62 9 12 9m0-2c-2.48 0-4.5 2.02-4.5 4.5S9.52 16 12 16s4.5-2.02 4.5-4.5S14.48 7 12 7z"/></svg>';
				echo '<span class="notif-number">' . absint( ! empty( $post_views ) ? $post_views : '0' ) . '</span>';
				echo '</div>';
				echo '</div>';
			}
		} elseif ( class_exists( 'Post_Views_Counter' ) ) {
			$number = pvc_get_post_views( absint( get_the_ID() ) );
			echo '<div class="gmr-iconnotif">';
			echo '<div class="gmr-iconnotif-wrap">';
			echo '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M12 6c3.79 0 7.17 2.13 8.82 5.5C19.17 14.87 15.79 17 12 17s-7.17-2.13-8.82-5.5C4.83 8.13 8.21 6 12 6m0-2C7 4 2.73 7.11 1 11.5 2.73 15.89 7 19 12 19s9.27-3.11 11-7.5C21.27 7.11 17 4 12 4zm0 5c1.38 0 2.5 1.12 2.5 2.5S13.38 14 12 14s-2.5-1.12-2.5-2.5S10.62 9 12 9m0-2c-2.48 0-4.5 2.02-4.5 4.5S9.52 16 12 16s4.5-2.02 4.5-4.5S14.48 7 12 7z"/></svg>';
			echo '<span class="notif-number">' . absint( pvc_get_post_views( absint( get_the_ID() ) ) ) . '</span>';
			echo '</div>';
			echo '</div>';
		}
		do_action( 'wpmedia_comment_icon' );
		do_action( 'wpmedia_social_popup' );
		echo '</div>';

		echo '</div>';
		if ( function_exists( 'the_subtitle' ) ) {
			the_subtitle( '<p class="subtitle">', '</p>' );
		} elseif ( class_exists( 'WPSubtitle' ) ) {
			do_action(
				'plugins/wp_subtitle/the_subtitle', //phpcs:ignore
				array(
					'before'        => '<p class="subtitle">',
					'after'         => '</p>',
					'post_id'       => get_the_ID(),
					'default_value' => '',
				)
			);
		}
		?>
	</header><!-- .entry-header -->
	<?php
	$thumb = wp_get_attachment_image( $post->ID, 'full' );

	if ( '' !== $thumb ) {
		?>
		<figure class="post-thumbnail gmr-thumbnail-single">
			<?php echo $thumb; // phpcs:ignore WordPress.Security.EscapeOutput ?>
		</figure>
		<?php
	}
	?>
	<?php
	if ( ! empty( $postparentid ) ) {
		do_action( 'wpmedia_get_attachment_gallery' );
	}
	?>

	<div class="single-wrap">
		<div class="entry-content entry-content-single clearfix">
			<?php
			$get_description = get_post( get_post_thumbnail_id( $post->ID ) )->post_content;
			if ( ! empty( $get_description ) ) :
				?>
				<div class="entry-content entry-content-single clearfix"><?php echo wp_kses_post( $get_description ); ?></div>
			<?php endif; ?>
			<footer class="entry-footer entry-footer-single">
				<?php
				wpmedia_entry_footer( $postparentid );
				do_action( 'wpmedia_next_posts_nav' );
				?>
			</footer><!-- .entry-footer -->
		</div><!-- .entry-content -->
	</div>
	<?php
		echo '<div class="list-flex">';
			do_action( 'wpmedia_comment_icon' );
			echo '<div class="gmr-content-share list-right">';
				do_action( 'wpmedia_social_share' );
			echo '</div>';
		echo '</div>';

		do_action( 'wpmedia_related_post' );
		do_action( 'wpmedia_banner_after_relpost' );
	?>

</article><!-- #post-<?php the_ID(); ?> -->
