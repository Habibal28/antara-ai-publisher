<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package wpmedia
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<article id="post-<?php the_ID(); ?>" class="post type-post idt-cbbox hentry">
	<div class="box-bigitem">
		<?php
		if ( has_post_thumbnail() ) {
			?>
			<a class="post-thumbnail" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
				<?php
					the_post_thumbnail(
						'large',
						array(
							'alt' => the_title_attribute(
								array(
									'echo' => false,
								)
							),
						)
					);
					wpmedia_postformat_thumbnails();
				?>
			</a>
			<?php
		}
		?>
		<div class="box-content">
			<?php wpmedia_category(); ?>
			<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" title="' . the_title_attribute( array( 'echo' => false ) ) . '" rel="bookmark">', '</a></h2>' ); ?>
			<?php
			echo '<div class="gmr-meta-topic">';
				echo '<span class="meta-content">';
				wpmedia_posted_on();
				echo '</span>';
			echo '</div>';
			?>
			<div class="entry-footer entry-footer-archive">
				<?php
					wpmedia_posted_by();
				?>
			</div><!-- .entry-footer -->
		</div>
	</div>
</article><!-- #post-<?php the_ID(); ?> -->
