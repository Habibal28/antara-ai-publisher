<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package wpmedia
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<article id="post-<?php the_ID(); ?>" class="post type-post hentry content-single">
	<?php do_action( 'wpmedia_view_breadcrumbs' ); ?>
	<header class="entry-header entry-header-single">
		<?php
		wpmedia_category( '', true, true );
		the_title( '<h1 class="entry-title"><strong>', '</strong></h1>' );
		
		/* Penulis dan Editor di bawah judul */
			$majpro_writer = get_post_meta( $post->ID, 'MAJPRO_Writer', true );
			$majpro_editor = get_post_meta( $post->ID, 'MAJPRO_Editor', true );

			if ( ! empty( $majpro_writer ) || ! empty( $majpro_editor ) ) {

				echo '<div class="writer-editor-top">';

				if ( ! empty( $majpro_writer ) ) {
					echo '<span><strong>Penulis:</strong> ' . esc_html( $majpro_writer ) . '</span>';
				}

				if ( ! empty( $majpro_editor ) ) {
					echo '<span><strong>Editor:</strong> ' . esc_html( $majpro_editor ) . '</span>';
				}

				echo '</div>';
			}


		echo '<div class="list-flex clearfix">';

		echo '<div class="gmr-gravatar-metasingle">';
		$author_id = $post->post_author;
		echo '<a class="url" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '" title="' . esc_html__( 'Permalink to: ', 'wpmedia' ) . esc_html( get_the_author() ) . '">';
			echo get_avatar( get_the_author_meta( 'user_email', $author_id ), '40', '', '', array( 'class' => 'img-cicle' ) );
		echo '</a>';
		echo '</div>';

		$authorcheck = get_the_author_meta( 'user_check', $author_id );

		$check = '';
		if ( $authorcheck ) {
			$check = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><g fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><path d="M0 0h24v24H0z"/><path fill="currentColor" d="M17 3.34a10 10 0 1 1-14.995 8.984L2 12l.005-.324A10 10 0 0 1 17 3.34zm-1.293 5.953a1 1 0 0 0-1.32-.083l-.094.083L11 12.585l-1.293-1.292l-.094-.083a1 1 0 0 0-1.403 1.403l.083.094l2 2l.094.083a1 1 0 0 0 1.226 0l.094-.083l4-4l.083-.094a1 1 0 0 0-.083-1.32z"/></g></svg>';
		}

		echo '<div class="gmr-content-metasingle">';
		echo '<div class="meta-content">';
		$byline = sprintf(
			/* translators: %s: post author. */
			'%s',
			'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '" title="' . esc_html( get_the_author() ) . '">' . esc_html( get_the_author() ) . '</a>' . $check . '</span>'
		);
		echo $byline; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		wpmedia_reading_time();
		echo '</div>';
		echo '<div class="meta-content">';
		wpmedia_posted_on();
		echo '</div>';
		echo '</div>';


		echo '<div class="gmr-content-share list-right">';
		$viewposts = get_theme_mod( 'gmr_active-viewsingle', 0 );

		if ( 0 === $viewposts ) {
			if ( class_exists( 'WP_Widget_PostViews' ) ) {
				if ( function_exists( 'the_views' ) ) {
					$post_views = get_post_meta( absint( get_the_ID() ), 'views', true );
					echo '<div class="gmr-iconnotif">';
					echo '<div class="gmr-iconnotif-wrap">';
					echo '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M12 6c3.79 0 7.17 2.13 8.82 5.5C19.17 14.87 15.79 17 12 17s-7.17-2.13-8.82-5.5C4.83 8.13 8.21 6 12 6m0-2C7 4 2.73 7.11 1 11.5 2.73 15.89 7 19 12 19s9.27-3.11 11-7.5C21.27 7.11 17 4 12 4zm0 5c1.38 0 2.5 1.12 2.5 2.5S13.38 14 12 14s-2.5-1.12-2.5-2.5S10.62 9 12 9m0-2c-2.48 0-4.5 2.02-4.5 4.5S9.52 16 12 16s4.5-2.02 4.5-4.5S14.48 7 12 7z"/></svg>';
					echo '<span class="notif-number">' . absint( ! empty( $post_views ) ? $post_views : '0' ) . '</span>';
					echo '</div>';
					echo '</div>';
				}
			} elseif ( class_exists( 'Post_Views_Counter' ) ) {
				$number = pvc_get_post_views( absint( get_the_ID() ) );
				echo '<div class="gmr-iconnotif">';
				echo '<div class="gmr-iconnotif-wrap">';
				echo '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M12 6c3.79 0 7.17 2.13 8.82 5.5C19.17 14.87 15.79 17 12 17s-7.17-2.13-8.82-5.5C4.83 8.13 8.21 6 12 6m0-2C7 4 2.73 7.11 1 11.5 2.73 15.89 7 19 12 19s9.27-3.11 11-7.5C21.27 7.11 17 4 12 4zm0 5c1.38 0 2.5 1.12 2.5 2.5S13.38 14 12 14s-2.5-1.12-2.5-2.5S10.62 9 12 9m0-2c-2.48 0-4.5 2.02-4.5 4.5S9.52 16 12 16s4.5-2.02 4.5-4.5S14.48 7 12 7z"/></svg>';
				echo '<span class="notif-number">' . absint( pvc_get_post_views( absint( get_the_ID() ) ) ) . '</span>';
				echo '</div>';
				echo '</div>';
			}
		}
		do_action( 'wpmedia_comment_icon' );
		do_action( 'wpmedia_social_popup' );
		echo '</div>';

		echo '</div>';
		if ( function_exists( 'the_subtitle' ) ) {
			the_subtitle( '<p class="subtitle">', '</p>' );
		} elseif ( class_exists( 'WPSubtitle' ) ) {
			do_action(
				'plugins/wp_subtitle/the_subtitle', //phpcs:ignore
				array(
					'before'        => '<p class="subtitle">',
					'after'         => '</p>',
					'post_id'       => get_the_ID(),
					'default_value' => '',
				)
			);
		}
		?>
	</header><!-- .entry-header -->
	<?php

	/* custom field using oembed https://codex.wordpress.org/Embeds */
	$oembed = get_post_meta( $post->ID, 'MAJPRO_Oembed', true );
	$iframe = get_post_meta( $post->ID, 'MAJPRO_Iframe', true );

	if ( ! empty( $oembed ) ) {
		echo '<div class="gmr-embed-responsive gmr-embed-responsive-16by9 single-thumbnail">';
		echo wp_oembed_get( $oembed );  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '</div>';

	} elseif ( ! empty( $iframe ) ) {
		echo '<div class="gmr-embed-responsive gmr-embed-responsive-16by9 single-thumbnail">';
		echo do_shortcode( $iframe );
		echo '</div>';

	} else {
		// Disable thumbnail options via customizer.
		$thumbnail = get_theme_mod( 'gmr_active-singlethumb', 0 );
		if ( 0 === $thumbnail && has_post_thumbnail() ) {
			?>
			<figure class="post-thumbnail gmr-thumbnail-single">
				<?php the_post_thumbnail(); ?>
				<?php
				$get_description = get_post( get_post_thumbnail_id( $post->ID ) )->post_excerpt;
				if ( ! empty( $get_description ) ) :
					?>
					<figcaption class="wp-caption-text"><?php echo esc_html( $get_description ); ?></figcaption>
				<?php endif; ?>
			</figure>
			<?php
		}
	}

	if ( has_post_format( 'gallery' ) ) {
		do_action( 'wpmedia_get_attachment_gallery' );
	}
	$banner   = get_theme_mod( 'gmr_adsstickyrightcontent' );
	$classads = '';
	if ( ! wpmedia_is_amp() ) {
		if ( isset( $banner ) && ! empty( $banner ) ) {
			$classads = ' have-stickybanner';
		}
	}
	?>

	<div class="single-wrap">
		<div class="entry-content entry-content-single clearfix<?php echo esc_html( $classads ); ?>">
			<?php
			do_action( 'wpmedia_banner_before_content' );
			the_content();

			/* next_and_number using own functions see function gmr_add_prevnext_post_navigation @inc/template-tags.php  */
			wp_link_pages(
				array(
					'before'           => '<div class="page-links">',
					'after'            => '</div>',
					'next_or_number'   => 'next_and_number',
					'nextpagelink'     => '&raquo;',
					'previouspagelink' => '&laquo;',
					'pagelink'         => '%',
					'echo'             => 1,
				)
			);
			?>

			<footer class="entry-footer entry-footer-single">
				<?php wpmedia_entry_footer(); ?>
				<?php

				$majpro_source = get_post_meta( $post->ID, 'MAJPRO_Source', true );
				$majpro_writer = get_post_meta( $post->ID, 'MAJPRO_Writer', true );
				$majpro_editor = get_post_meta( $post->ID, 'MAJPRO_Editor', true );
				if ( ! empty( $majpro_writer ) || ! empty( $majpro_editor ) || ! empty( $majpro_source ) ) {
					echo '<div class="gmr-cf-metacontent heading-text meta-content">';
					if ( ! empty( $majpro_writer ) ) {
						echo '<span>';
						echo esc_attr__( 'Writer: ', 'wpmedia' ) . esc_attr( $majpro_writer );
						echo '</span>';
					}
					if ( ! empty( $majpro_editor ) ) {
						echo '<span>';
						echo esc_attr__( 'Editor: ', 'wpmedia' ) . esc_attr( $majpro_editor );
						echo '</span>';
					}
					if ( ! empty( $majpro_source ) ) {
						echo '<span>';
						echo '<a href="' . esc_url( $majpro_source ) . '" target="_blank" rel="nofollow">' . esc_attr__( 'Source News', 'wpmedia' ) . '</a>';
						echo '</span>';
					}
					echo '</div>';
				}
				?>
				<?php do_action( 'wpmedia_next_posts_nav' ); ?>
			</footer><!-- .entry-footer -->
		</div><!-- .entry-content -->
		<?php do_action( 'wpmedia_banner_stickyright_content' ); ?>
	</div>
	<?php
		echo '<div class="list-flex">';
			do_action( 'wpmedia_comment_icon' );
			echo '<div class="gmr-content-share list-right">';
				do_action( 'wpmedia_social_share' );
			echo '</div>';
		echo '</div>';

		do_action( 'wpmedia_related_post' );
		do_action( 'wpmedia_banner_after_relpost' );
	?>

</article><!-- #post-<?php the_ID(); ?> -->
