<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package wpmedia
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$focus_display = get_post_meta( $post->ID, '_gmr_focus_key', true );

$focus = '';
if ( $focus_display ) {
	$focus = ' gmr-focus-news';
}

$focusthumb = 'medium';
if ( $focus_display ) {
	$focusthumb = 'medium_large';
}

?>

<article id="post-<?php the_ID(); ?>" class="post type-post hentry">
	<div class="box-item<?php echo esc_html( $focus ); ?>">
		<?php
		if ( has_post_thumbnail() ) {
			?>
			<a class="post-thumbnail" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
				<?php
					the_post_thumbnail(
						esc_html( $focusthumb ),
						array(
							'alt' => the_title_attribute(
								array(
									'echo' => false,
								)
							),
						)
					);
					wpmedia_postformat_thumbnails();
				?>
			</a>
			<?php
		}
		?>
		<div class="box-content">
			<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" title="' . the_title_attribute( array( 'echo' => false ) ) . '" rel="bookmark">', '</a></h2>' ); ?>
			<?php
			echo '<div class="gmr-meta-topic">';
				echo '<span class="meta-content">';
				wpmedia_category();
				wpmedia_posted_on();
				echo '</span>';
			echo '</div>';
			?>
			<div class="entry-footer entry-footer-archive">
				<?php
					wpmedia_posted_by();
				?>
			</div><!-- .entry-footer -->
			<?php
			$excerpt_opsi = get_theme_mod( 'gmr_active-excerpt', 1 );
			if ( 0 === $excerpt_opsi ) :
				?>
				<div class="entry-content entry-content-archive">
					<?php the_excerpt(); ?>
				</div><!-- .entry-content -->
				<?php
			endif;
			?>
		</div>
	</div>
</article><!-- #post-<?php the_ID(); ?> -->
