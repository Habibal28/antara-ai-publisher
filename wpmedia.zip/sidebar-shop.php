<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package wpmedia
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! is_active_sidebar( 'sidebar-woo' ) || wpmedia_is_amp() ) {
	return;
}
?>

<aside id="secondary" class="widget-area col-md-4 pos-sticky">
	<?php dynamic_sidebar( 'sidebar-woo' ); ?>
</aside><!-- #secondary -->
