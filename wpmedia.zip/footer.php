<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package wpmedia
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
			</div>
		</div>
		<?php do_action( 'wpmedia_footerbanner' ); ?>
	</div><!-- .gmr-content -->

	<footer id="colophon" class="site-footer">
		<?php
		$mod = get_theme_mod( 'gmr_footer_column', '4col2' );
		if ( '4col' === $mod ) {
			$firstclass = 'col-md-3';
			$class      = 'col-md-3';
		} elseif ( '1col' === $mod ) {
			$firstclass = 'col-md-12';
			$class      = 'col-md-12';
		} elseif ( '2col' === $mod ) {
			$firstclass = 'col-md-6';
			$class      = 'col-md-6';
		} elseif ( '6col' === $mod ) {
			$firstclass = 'col-md-4';
			$class      = 'col-md-4';
		} elseif ( '3col2' === $mod ) {
			$firstclass = 'col-md-6';
			$class      = 'col-md-3';
		} elseif ( '4col2' === $mod ) {
			$firstclass = 'col-md-6';
			$class      = 'col-md-2';
		} else {
			$firstclass = 'col-md-4';
			$class      = 'col-md-4';
		}

		if ( ( is_active_sidebar( 'footer-1' ) || is_active_sidebar( 'footer-2' ) || is_active_sidebar( 'footer-3' ) || is_active_sidebar( 'footer-4' ) || is_active_sidebar( 'footer-5' ) || is_active_sidebar( 'footer-6' ) ) && ! wpmedia_is_amp() ) :
			?>
			<div id="footer-sidebar" class="widget-footer" role="complementary">
				<div class="container">
					<div class="row">
						<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
							<div class="footer-column <?php echo esc_html( $firstclass ); ?>">
								<?php dynamic_sidebar( 'footer-1' ); ?>
							</div>
						<?php endif; ?>
						<?php if ( is_active_sidebar( 'footer-2' ) ) : ?>
							<div class="footer-column <?php echo esc_html( $class ); ?>">
								<?php dynamic_sidebar( 'footer-2' ); ?>
							</div>
						<?php endif; ?>
						<?php if ( is_active_sidebar( 'footer-3' ) ) : ?>
							<div class="footer-column <?php echo esc_html( $class ); ?>">
								<?php dynamic_sidebar( 'footer-3' ); ?>
							</div>
						<?php endif; ?>
						<?php if ( is_active_sidebar( 'footer-4' ) ) : ?>
							<div class="footer-column <?php echo esc_html( $class ); ?>">
								<?php dynamic_sidebar( 'footer-4' ); ?>
							</div>
						<?php endif; ?>
						<?php if ( is_active_sidebar( 'footer-5' ) ) : ?>
							<div class="footer-column <?php echo esc_html( $class ); ?>">
								<?php dynamic_sidebar( 'footer-5' ); ?>
							</div>
						<?php endif; ?>
						<?php if ( is_active_sidebar( 'footer-6' ) ) : ?>
							<div class="footer-column <?php echo esc_html( $class ); ?>">
								<?php dynamic_sidebar( 'footer-6' ); ?>
							</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		<?php endif; ?>
		<div class="container">
			<div class="site-info">
				<?php

				echo '<div class="gmr-social-icons">';
					echo '<ul class="social-icon">';
						do_action( 'social_icon' );
					echo '</ul>';
				echo '</div>';
				echo '</div><!-- .site-info -->';

				echo '<div class="heading-text">';
				if ( has_nav_menu( 'menu-4' ) ) {
					wp_nav_menu(
						array(
							'theme_location'  => 'menu-4',
							'container'       => 'div',
							'container_class' => 'footer-menu',
							'depth'           => 1,
						)
					);
				}

				$copyright = get_theme_mod( 'gmr_copyright' );
				if ( $copyright ) :
					// sanitize html output than convert it again using htmlspecialchars_decode.
					echo wp_kses_post( $copyright );
				else :
					?>
					<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'wpmedia' ) ); ?>"><?php printf( esc_html__( 'Powered by WordPress', 'wpmedia' ) ); ?></a>
					<span class="sep"> - </span>
					<?php printf( esc_html__( 'Theme: wpmedia.', 'wpmedia' ) ); ?>
				<?php endif; ?>

				<?php
				if ( wpmedia_is_amp() ) :
					/* Add Non AMP Version using div id="site-version-switcher" and id="version-switch-link" */
					$nonamp_link = amp_remove_endpoint( amp_get_current_url() );
					echo '<div id="site-version-switcher" class="text-center"><a id="version-switch-link" href="' . esc_url( $nonamp_link ) . '" class="amp-wp-canonical-link" title="' . esc_html__( 'Non AMP Version', 'wpmedia' ) . '" rel="noamphtml">' . esc_attr__( 'Non AMP Version', 'wpmedia' ) . '</a></div>';
				endif;
				?>
			</div><!-- .heading-text -->
		</div>
	</footer><!-- #colophon -->
</div><!-- #page -->
<?php do_action( 'wpmedia_woocommerce_demo_store' ); ?>

<?php

if ( wpmedia_is_amp() ) {
	echo '<div id="gmr-sidemenu-id" class="gmr-sidemenu onoffcanvas is-fixed is-left" [class]="\'gmr-sidemenu onoffcanvas is-fixed is-left\' + ( navMenuExpanded ? \' toggled-on\' : \'\' )" aria-expanded="false" [aria-expanded]="navMenuExpanded ? \'true\' : \'false\'">';
} else {
	echo '<div id="gmr-sidemenu-id" class="gmr-sidemenu onoffcanvas is-fixed is-left">';
}
?>
	<nav id="side-nav">
	<div class="gmr-logo">
		<?php
		do_action( 'wpmedia_logo' );
		if ( wpmedia_is_amp() ) {
			echo '<div class="close-topnavmenu-wrap"><button id="close-topnavmenu-button" role="button" aria-label="' . esc_html__( 'Close', 'wpmedia' ) . '" class="menu-toggle" on="tap:AMP.setState( { navMenuExpanded: ! navMenuExpanded } )" [class]="\'menu-toggle\' + ( navMenuExpanded ? \' toggled-on\' : \'\' )" aria-expanded="false" [aria-expanded]="navMenuExpanded ? \'true\' : \'false\'">&times;</button></div>';
		} else {
			echo '<div class="close-topnavmenu-wrap"><button id="close-topnavmenu-button" role="button" aria-label="' . esc_html__( 'Close', 'wpmedia' ) . '" data-target="#gmr-sidemenu-id" data-toggle="onoffcanvas" aria-expanded="false">&times;</button></div>';
		}
		?>
	</div>
	<?php


	echo '<div class="gmr-search">
	<form method="get" class="gmr-searchform searchform" action="' . esc_url( home_url( '/' ) ) . '">
		<input type="text" name="s" id="s-menu" placeholder="' . esc_html__( 'Search', 'wpmedia' ) . '" />
		<input type="hidden" name="post_type[]" value="post" />
		<button type="submit" role="button" class="gmr-search-submit gmr-search-icon" aria-label="' . esc_html__( 'Submit', 'wpmedia' ) . '">
			<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M20.94 11c-.46-4.17-3.77-7.48-7.94-7.94V1h-2v2.06C6.83 3.52 3.52 6.83 3.06 11H1v2h2.06c.46 4.17 3.77 7.48 7.94 7.94V23h2v-2.06c4.17-.46 7.48-3.77 7.94-7.94H23v-2h-2.06zM12 19c-3.87 0-7-3.13-7-7s3.13-7 7-7 7 3.13 7 7-3.13 7-7 7z"/></svg>
		</button>
	</form>
	</div>';

	wp_nav_menu(
		array(
			'theme_location' => 'menu-3',
			'container'      => 'ul',
			'menu_id'        => 'side-menu',
			'depth'          => 2,
		)
	);
	echo '</nav>';

	echo '<div class="gmr-social-icons">';
	echo '<ul class="social-icon">';
	do_action( 'social_icon' );
	echo '</ul>';
	echo '</div>';

	echo '</div>';

	do_action( 'wpmedia_floating_banner_footer' );
	if ( ! wpmedia_is_amp() ) {
		?>
	<div class="gmr-ontop gmr-hide">
		<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><g fill="none"><path d="M14.829 11.948l1.414-1.414L12 6.29l-4.243 4.243l1.415 1.414L11 10.12v7.537h2V10.12l1.829 1.828z" fill="currentColor"/><path fill-rule="evenodd" clip-rule="evenodd" d="M19.778 4.222c-4.296-4.296-11.26-4.296-15.556 0c-4.296 4.296-4.296 11.26 0 15.556c4.296 4.296 11.26 4.296 15.556 0c4.296-4.296 4.296-11.26 0-15.556zm-1.414 1.414A9 9 0 1 0 5.636 18.364A9 9 0 0 0 18.364 5.636z" fill="currentColor"/></g></svg>
	</div>
		<?php
	}
	do_action( 'wpmedia_popup_banner' );
	if ( wpmedia_is_amp() ) {
		echo '<div [class]="\'onoffcanvas-drawer\' + ( navMenuExpanded ? \' toggled-on\' : \'\' )" on="tap:AMP.setState( { navMenuExpanded: ! navMenuExpanded } )"></div>';
	}
	wp_footer();
	?>

</body>
</html>
